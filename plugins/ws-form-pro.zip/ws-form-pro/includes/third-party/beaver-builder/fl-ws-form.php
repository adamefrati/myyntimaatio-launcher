<?php

define( 'FL_WS_FORM_DIR', WS_FORM_PLUGIN_DIR_PATH . 'includes/third-party/beaver-builder/' );
define( 'FL_WS_FORM_URL', WS_FORM_PLUGIN_DIR_URL . 'includes/third-party/beaver-builder/' );

require_once FL_WS_FORM_DIR . 'classes/class-fl-ws-form-loader.php';