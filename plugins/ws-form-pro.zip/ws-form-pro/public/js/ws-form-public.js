(function($) {

	'use strict';

	// Set is_admin
	$.WS_Form.prototype.set_is_admin = function() { return false; }

	// One time init for admin page
	$.WS_Form.prototype.init = function() {

		// Build data cache
		this.data_cache_build();

		// Set global variables once for performance
		this.set_globals();
	}

	// Continue initialization after submit data retrieved
	$.WS_Form.prototype.init_after_get_submit = function(submit_retrieved) {

		// Debug
		if($.WS_Form.debug_rendered) {

			// Form data source debug
			if(this.submit_auto_populate !== false) { this.log('debug_action_get', this.submit_auto_populate['action_label']); }
			if(this.submit !== false) { this.log('debug_submit_loaded'); }
		}

		// Build form
		this.form_build();
	}

	// Set global variables once for performance
	$.WS_Form.prototype.set_globals = function() {

		// Get framework ID
		this.framework_id = $.WS_Form.settings_plugin.framework;

		// Get framework settings
		this.framework = $.WS_Form.frameworks.types[this.framework_id];

		// Get current framework
		this.framework_fields = this.framework['fields']['public'];

		// Get invalid_feedback placeholder mask
		this.invalid_feedback_mask_placeholder = '';
		if(typeof($.WS_Form.meta_keys['invalid_feedback']) !== 'undefined') {

			if(typeof($.WS_Form.meta_keys['invalid_feedback']['p']) !== 'undefined') {

				this.invalid_feedback_mask_placeholder = $.WS_Form.meta_keys['invalid_feedback']['p'];
			}
		}

		// Custom action URL
		this.form_action_custom = (this.form_obj.attr('action') != (ws_form_settings.url + 'submit'));

		// Get validated class
		var class_validated_array = (typeof(this.framework.fields.public.class_form_validated) !== 'undefined') ? this.framework.fields.public.class_form_validated : [];
		this.class_validated = class_validated_array.join(' ');

		// Render debug console
		if(typeof(this.debug) === 'function') { this.debug(); }

		// Hash
		if(
			ws_form_settings.wsf_hash &&
			(typeof(ws_form_settings.wsf_hash) === 'object')
		) {

			// Set hash from query string
			for(var hash_index in ws_form_settings.wsf_hash) {

				if(!ws_form_settings.wsf_hash.hasOwnProperty(hash_index)) { continue; }

				var wsf_hash = ws_form_settings.wsf_hash[hash_index];

				if(
					(typeof(wsf_hash.id) !== 'undefined') &&
					(typeof(wsf_hash.hash) !== 'undefined') &&
					(typeof(wsf_hash.token) !== 'undefined') &&
					(wsf_hash.id == this.form_id)
				) {

					this.hash_set(wsf_hash.hash, wsf_hash.token, true);
				}
			}

		} else {

			// Set hash from cookie
			this.hash_set(this.cookie_get('hash', ''), false, true);
		}

		// Visual editor?
		this.visual_editor = (typeof(this.form_canvas_obj.attr('data-visual-builder')) !== 'undefined');

		// Read submission data if hash is defined
		var ws_this = this;
		if(this.hash) {

			var url = 'submit/hash/' + this.hash + '/';
			if(this.token) { url += this.token + '/'; }

			// Call AJAX request
			$.WS_Form.this.api_call(url, 'GET', false, function(response) {

				if(typeof(response.data) !== 'undefined') {

					// Save the submissions data
					ws_this.submit = response.data;
				}

				// Initialize after getting submit
				ws_this.init_after_get_submit(true);

				// Finished with submit data
				ws_this.submit = false;

			}, function(response) {

				// Read auto populate data instead
				ws_this.read_json_populate();

				// Initialize after getting submit
				ws_this.init_after_get_submit(false);
			});

		} else {

			// Read auto populate data
			this.read_json_populate();

			// Initialize after getting submit
			this.init_after_get_submit(false);
		}
	}

	// Read auto populate data
	$.WS_Form.prototype.read_json_populate = function() {

		if(typeof(wsf_form_json_populate) !== 'undefined') {

			if(typeof(wsf_form_json_populate[this.form_id]) !== 'undefined') {

				this.submit_auto_populate = wsf_form_json_populate[this.form_id];
			}
		}
	}

	// Render a log message
	$.WS_Form.prototype.log = function(language_id, variable, log_class) {

		if(typeof(variable) == 'undefined') { variable = ''; }
		if(typeof(log_class) == 'undefined') { log_class = ''; }

		return ($.WS_Form.debug_rendered) ? this.debug_audit_add('log', this.language(language_id, variable, false).replace(/%s/g, variable), log_class) : false;
	}

	// Render an error message
	$.WS_Form.prototype.error = function(language_id, variable, error_class) {

		if(typeof(variable) == 'undefined') { variable = ''; }
		if(typeof(error_class) == 'undefined') { error_class = ''; }

		// Build error message
		var error_message = this.language(language_id, variable, false).replace(/%s/g, variable);

		// Show error message
		if(!this.visual_editor && this.get_object_meta_value(this.form, 'submit_show_errors', true)) {

			this.action_message(error_message);
		}

		return $.WS_Form.debug_rendered ? this.debug_audit_add('error', error_message, error_class) : false;
	}

	// Render any interface elements that rely on the form object
	$.WS_Form.prototype.form_render = function() {

		// Timer
		this.form_timer();

		// Get conditional actions
		if(
			(typeof(this.form.meta.action) !== 'undefined')
		) {

			for(var key in this.form.meta.action) {

				if(!this.form.meta.action.hasOwnProperty(key)) { continue; }

				// Get action
				var action = this.form.meta.action[key];

				// Get action ID
				var action_id = action.id.toString();

				// Actions - All
				this.conditional_actions_run_action.push(action_id);

				// Actions - Save
				if(action.save) {

					this.conditional_actions_run_save.push(action_id);
				}

				// Actions - Submit
				if(action.submit) {

					this.conditional_actions_run_submit.push(action_id);
				}
			}
		}

		// Reset arrays
		this.conditional_actions_changed = false;
		this.recaptchas = [];
		this.recaptchas_v2_default = [];
		this.recaptchas_v2_invisible = [];
		this.recaptchas_v3_default = [];
		this.recaptchas_conditions = [];
		this.signatures = [];
		this.signatures_by_name = [];

		// Initialize framework
		this.form_framework();

		// Form preview
		this.form_preview();

		// Groups - Tabs - Initialize
		this.form_tabs();

		// Repeatable sections
		this.form_section_repeatable();

		// Navigation
		this.form_navigation();

		// Analytics
		this.form_analytics();

		// Client side form validation
		this.form_validation();

		// Select all
		this.form_select_all();

		// Select min max
		this.form_select_min_max();

		// Select AJAX
		this.form_select_ajax();

		// Checkbox min max
		this.form_checkbox_min_max();

		// Text input and textarea character and word count
		this.form_character_word_count();

		// Dates
		this.form_date();

		// Colors
		this.form_color();

		// Signature
		this.form_signature();

		// reCAPTCHA
		this.form_recaptcha();

		// Legal
		this.form_legal();

		// Rating
		this.form_rating();

		// Google Map
		this.form_google_map();

		// E-Commerce
		this.form_ecommerce();

		// File inputs
		this.form_file();

		// Client side form conditions (Initial run = true)
		this.form_conditional(true);

		// Conversational
		if(typeof(this.form_conversational) === 'function') {

			this.form_conversational();
		}

		// Progress
		this.form_progress();

		// Range sliders
		this.form_input_range();

		// Text areas
		this.form_textarea();

		// Required
		this.form_required();

		// Input masks
		this.form_inputmask();

		// Spam protection
		this.form_spam_protection();

		// Tracking
		this.form_tracking();

		// Password visibility toggle
		this.form_password_visibility_toggle();

		// Password strength meter
		this.form_password_strength_meter();

		// Credit Card
		this.form_credit_card();
		// Bypass
		this.form_bypass_enabled = true;
		this.form_bypass(false);
		// Calculations
		this.form_calc();
		// Form stats
		this.form_stat();

		// Form validation - Real time
		this.form_validate_real_time();

		// Select Cascading
		this.form_cascade();

		// Tab validation
		this.form_tab_validation();

		// Log
		this.log('debug_form_rendered');

		// Trigger rendered event
		this.trigger('rendered');

		// Section repeatable hidden field (This triggers repeatable section events also)
		this.section_repeatable_hidden_field();

		// Set data-wsf-rendered attribute
		this.form_obj.attr('data-wsf-rendered', '');
	}

	$.WS_Form.prototype.form_timer = function() {

		// Timer
		this.date_start = this.cookie_get('date_start', false);
		if((this.date_start === false) || isNaN(this.date_start) || (this.date_start == '')) {

			this.date_start = new Date().getTime();
			this.cookie_set('date_start', this.date_start, false);
		}
	}

	// Trigger events
	$.WS_Form.prototype.trigger = function(slug) {

		// New method
		var action_type = 'wsf-' + slug;
		$(document).trigger(action_type, [this.form, this.form_id, this.form_instance_id, this.form_obj, this.form_canvas_obj]);
		this.log('log_trigger', action_type, 'event');

		// Legacy method - Instance
		var trigger_instance = 'wsf-' + slug + '-instance-' + this.form_instance_id;
		$(window).trigger(trigger_instance);

		// Legacy method - Form
		var trigger_form = 'wsf-' + slug + '-form-' + this.form_id;
		$(window).trigger(trigger_form);
	}

	// Initialize JS
	$.WS_Form.prototype.form_framework = function() {

		// Add framework form attributes
		if(
			(typeof(this.framework.form.public) !== 'undefined') &&
			(typeof(this.framework.form.public.attributes) === 'object')
		) {

			for(var attribute in this.framework.form.public.attributes) {

				var attribute_value = this.framework.form.public.attributes[attribute];

				this.form_obj.attr(attribute, attribute_value);
			}
		}

		// Check framework init_js
		if(typeof(this.framework.init_js) !== 'undefined') {

			// Framework init JS values
			var framework_init_js_values = {'form_canvas_selector': '#' + this.form_obj_id};
			var framework_init_js = this.mask_parse(this.framework.init_js, framework_init_js_values);

			try {

				$.globalEval('(function($) { ' + framework_init_js + ' })(jQuery);');

			} catch(e) {

				this.error('error_js', action_javascript);
			}
		}
	}

	// Form - Reset
	$.WS_Form.prototype.form_reset = function(e) {

		var ws_this = this;

		// Trigger
		this.trigger('reset-before');

		// Unmark as validated
		this.form_obj.removeClass(this.class_validated);

		// HTML form reset
		this.form_obj[0].reset();
		// Reset special fields
		for(var key in this.field_data_cache) {

			if(!this.field_data_cache.hasOwnProperty(key)) { continue; }

			var field = this.field_data_cache[key];

			var field_id = field.id;
			var field_name = this.field_name_prefix + field_id;

			var field_type_config = $.WS_Form.field_type_cache[field.type];
			var trigger = (typeof(field_type_config.trigger) !== 'undefined') ? field_type_config.trigger : 'change';

			switch(field.type) {

				case 'textarea' :

					$('[name="' + field_name + '"], [name^="' + field_name + '["]', this.form_canvas_obj).each(function() {

						ws_this.textarea_set_value($(this), $(this).val());
						$(this).trigger(trigger);
					});

					break;

				case 'color' :

					$('[name="' + field_name + '"], [name^="' + field_name + '["]', this.form_canvas_obj).each(function() {

						if($(this).hasClass('minicolors-input')) {

							$(this).minicolors('value', $(this).val()).trigger(trigger);
						}
					});

					break;

				default :

					$('[name="' + field_name + '"], [name^="' + field_name + '["]', this.form_canvas_obj).each(function() {

						$(this).trigger(trigger);
					});
			}
		}

		// Clear signatures
		this.signatures_clear();

		// Reset reCAPTCHAs
		this.recaptcha_reset();

		// Form conditional=
		this.form_conditional();
		// Trigger
		this.trigger('reset-complete');
	}

	// Form - Clear
	$.WS_Form.prototype.form_clear = function() {

		var ws_this = this;

		// Trigger
		this.trigger('clear-before');

		// Unmark as validated
		this.form_obj.removeClass(this.class_validated);

		// Clear fields
		for(var key in this.field_data_cache) {

			if(!this.field_data_cache.hasOwnProperty(key)) { continue; }

			var field = this.field_data_cache[key];

			var field_id = field.id;
			var field_name = this.field_name_prefix + field_id;

			var field_type_config = $.WS_Form.field_type_cache[field.type];
			var trigger = (typeof(field_type_config.trigger) !== 'undefined') ? field_type_config.trigger : 'change';

			// Clear value
			switch(field.type) {

				case 'checkbox' :
				case 'price_checkbox' :
				case 'radio' :
				case 'price_radio' :

					$('[name="' + field_name + '"], [name^="' + field_name + '["]', this.form_canvas_obj).each(function() {

						if($(this).is(':checked')) {
	
							$(this).prop('checked', false).trigger(trigger);
						}
					});

					break;

				case 'select' :
				case 'price_select' :

					$('[name="' + field_name + '"], [name^="' + field_name + '["] option', this.form_canvas_obj).each(function() {

						if($(this).is(':selected')) {
	
							$(this).prop('selected', false);
							$(this).closest('select').trigger(trigger);
						}
					});

					break;

				case 'textarea' :

					$('[name="' + field_name + '"], [name^="' + field_name + '["]', this.form_canvas_obj).each(function() {

						if($(this).val() != '') {

							$(this).val('').trigger(trigger);
							ws_this.textarea_set_value($(this), '');
						}
					});

					break;

				case 'color' :

					$('[name="' + field_name + '"], [name^="' + field_name + '["]', this.form_canvas_obj).each(function() {

						if($(this).val() != '') {

							$(this).val('').trigger(trigger);

							if($(this).hasClass('minicolors-input')) {

								$(this).minicolors('value', '');
							}
						}
					});

					break;

				default:

					$('[name="' + field_name + '"], [name^="' + field_name + '["]', this.form_canvas_obj).each(function() {

						if($(this).val() != '') {

							$(this).val('').trigger(trigger);
						}
					});
			}
		}

		// Clear signatures
		this.signatures_clear();

		// Reset reCAPTCHAs
		this.recaptcha_reset();

		// Form conditional
		this.form_conditional();
		// Trigger
		this.trigger('clear-complete');
	}

	// Form reload
	$.WS_Form.prototype.form_reload = function() {

		// Read submission data if hash is defined
		var ws_this = this;
		if(this.hash != '') {

			// Call AJAX request
			$.WS_Form.this.api_call('submit/hash/' + this.hash, 'GET', false, function(response) {

				// Save the submissions data
				ws_this.submit = response.data;

				ws_this.form_reload_after_get_submit(true);

				// Finished with submit data
				ws_this.submit = false;

			}, function(response) {

				ws_this.form_reload_after_get_submit(false);
			});

		} else {

			// Reset submit
			this.submit = false;

			this.form_reload_after_get_submit(false);
		}
	}

	// Form reload - After get submit
	$.WS_Form.prototype.form_reload_after_get_submit = function(submit_retrieved) {

		// Clear any messages
		$('[data-wsf-message][data-wsf-instance-id="' + this.form_instance_id + '"]').remove();

		// Show the form
		this.form_canvas_obj.show();

		// Reset form tag
		this.form_canvas_obj.removeClass(this.class_validated)

		// Clear ecommerce real time validation hooks
		this.form_validation_real_time_hooks = [];

		// Empty form object
		this.form_canvas_obj.empty();

		// Build form
		this.form_build();
	}

	// Form - Hash reset
	$.WS_Form.prototype.form_hash_clear = function() {

		// Clear hash variable
		this.hash = '';

		// Clear hash cookie
		this.cookie_clear('hash')

		// Update debug interface
		if($.WS_Form.debug_rendered) {

			this.debug_info('debug_info_hash', this.language('debug_hash_empty'));
			this.debug_info('debug_info_submit_count', 0);
		}

		// Log
		this.log('log_hash_clear');
	}

	// Form password visibility_toggle
	$.WS_Form.prototype.form_password_visibility_toggle = function() {

		var ws_this = this;

		$('[data-wsf-password-visibility-toggle]:not([data-init-wsf-password-visibility-toggle])', this.form_canvas_obj).each(function() {

			$(this).on('click keydown', function(e) {

				// If keydown, check for space or enter
				if(e.type === 'keydown') {

					if(
						(e.keyCode !== 13) && (e.keyCode !== 32)
					) {
						return;
					}
				}

				e.preventDefault();

				var field_wrapper_obj = ws_this.get_field_wrapper($(this));

				var input_obj = $('input', field_wrapper_obj);

				var field_type = ws_this.get_field_type(input_obj);

				var field = ws_this.get_field(input_obj);

				switch(field_type) {

					case 'password' :

						input_obj.attr('type', 'text');

						var title = ws_this.get_object_meta_value(field, 'text_password_visibility_toggle_on', '');
						if(title == '') { title = ws_this.language('password_visibility_toggle_on'); }
						$(this).attr('title', title).attr('aria-live', 'polite').attr('aria-pressed', 'true');

						$('path.wsf-password-visibility-off', $(this)).hide();
						$('g.wsf-password-visibility-on', $(this)).show();
						break;

					case 'text' :

						input_obj.attr('type', 'password');

						var title = ws_this.get_object_meta_value(field, 'text_password_visibility_toggle_off', '');
						if(title == '') { title = ws_this.language('password_visibility_toggle_off'); }
						$(this).attr('title', title).attr('aria-live', 'polite').attr('aria-pressed', 'false');

						$('path.wsf-password-visibility-off', $(this)).show();
						$('g.wsf-password-visibility-on', $(this)).hide();
						break;
				}
			});

			// Set field as initialized
			$(this).attr('data-init-wsf-password-visibility-toggle', '');
		});
	}

	// Form password strength meters
	$.WS_Form.prototype.form_password_strength_meter = function() {

		var ws_this = this;

		if(
			(typeof(wp) === 'undefined') ||
			(typeof(wp.passwordStrength) === 'undefined') ||
			(typeof(wp.passwordStrength.meter) === 'undefined')
		) {

			return;
		}

		var password_field_objs = $('[data-password-strength-meter]:not([data-init-password-strength-meter])', this.form_canvas_obj);

		password_field_objs.each(function() {

			// Flag so it only initializes once
			$(this).attr('data-init-password-strength-meter', '');

			// Add password strength meter message div
			var field_wrapper = ws_this.get_field_wrapper($(this));

			// Get field ID
			var field_id = ws_this.get_field_id($(this));

			// Get repeatable suffix
			var section_repeatable_suffix = ws_this.get_section_repeatable_suffix($(this));

			// Get invalid feedback object
			var invalid_feedback_obj = ws_this.get_invalid_feedback_obj($(this));

			// Help classes
			var class_help_array = ws_this.get_field_value_fallback('password', false, 'class_help', []);
			var help_class = class_help_array.join(' ');

			// Build pasword strength meter div
			var password_strength_meter_div = '<div id="' + ws_this.form_id_prefix + 'password-strength-meter-' + field_id + section_repeatable_suffix + '" class="' + help_class + '"></div>';

			// Add message div
			if(invalid_feedback_obj.length) {

				// Insert before help
				$(password_strength_meter_div).insertBefore(invalid_feedback_obj);

			} else {

				// Insert at end
				field_wrapper.append(password_strength_meter_div);
			}

			// Initial run
			ws_this.form_password_strength_meter_process($(this));
		});

		password_field_objs.on('keyup', function() {

			// Run on keyup
			ws_this.form_password_strength_meter_process($(this));
		});
	}

	$.WS_Form.prototype.form_password_strength_meter_process = function(obj) {

		// Get field wrapper
		var field_wrapper = this.get_field_wrapper(obj);

		// Get field ID
		var field_id = this.get_field_id(obj);

		// Get repeatable suffix
		var section_repeatable_suffix = this.get_section_repeatable_suffix(obj);

		// Get field value
		var field_value = $('#' + this.form_id_prefix + 'field-' + field_id + section_repeatable_suffix, field_wrapper).val();

	    // Get result DOM element
	    var password_strength_result = $('#' + this.form_id_prefix + 'password-strength-meter-' + field_id + section_repeatable_suffix, field_wrapper);

		// If empty, clear result
		if(!field_value) {

			password_strength_result.html('');
			obj.attr('data-password-strength-meter', '');
			return;
		}

		// Get password strength
	    var field_value_strength = wp.passwordStrength.meter(field_value, wp.passwordStrength.userInputBlacklist(), field_value);

	    // Get messaging mask types for current framework
		var types = this.get_framework_config_value('message', 'types');

		// Clear existing classes
		for(var type_id in types) {

			if(!types.hasOwnProperty(type_id)) { continue; }

			if((typeof(types[type_id]) !== 'undefined') && (typeof(types[type_id].text_class) !== 'undefined')) {

				password_strength_result.removeClass(types[type_id].text_class);
			}
		}

		var field = this.field_data_cache[field_id];

		switch (field_value_strength) {

			case 2 :

				var type_id = 'danger';
				var language_id = 'bad';
				break;

			case 3 :

				var type_id = 'warning';
				var language_id = 'good';
				break;

			case 4 :

				var type_id = 'success';
				var language_id = 'strong';
				break;

			default :

				var type_id = 'danger';
				var language_id = 'short';
		}

		// Build label and set HTML
		var password_strength_label = this.get_object_meta_value(field, 'text_password_strength_' + language_id, '');
		if(password_strength_label == '') { password_strength_label = this.language('password_strength_' + language_id); }
		password_strength_result.html(password_strength_label).attr('aria-live', 'polite');

		// Apply data attribute to input
		obj.attr('data-password-strength-meter', type_id);

		// Add class
		if((typeof(types[type_id]) !== 'undefined') && (typeof(types[type_id].text_class) !== 'undefined')) {

			password_strength_result.addClass(types[type_id].text_class);
		}
	}

	$.WS_Form.prototype.form_calc_clean = function() {

		for(var calc_index in this.calc) {

			if(!this.calc.hasOwnProperty(calc_index)) { continue; }

			var calc = this.calc[calc_index];

			var field_id = this.get_part_id(calc.field.id, calc.section_repeatable_index, 'field-wrapper');

			var field_obj = $('#' + field_id, this.form_canvas_obj);

			if(!field_obj.length) {

				this.calc.splice(calc_index, 1);
				this.form_calc_clean();
				return;
			}
		}
	}

	$.WS_Form.prototype.form_calc = function(field_obj_id_changed, section_repeatable_added_section_id) {

		if(typeof(field_obj_id_changed) === 'undefined') { field_obj_id_changed = false; }
		if(typeof(section_repeatable_added_section_id) === 'undefined') { section_repeatable_added_section_id = false; }

		for(var calc_index in this.calc) {

			if(!this.calc.hasOwnProperty(calc_index)) { continue; }

			var calc = this.calc[calc_index];

			// EVENT: Section added
			if(section_repeatable_added_section_id !== false) {

				// Always run #section_row_count variable
				if(calc.value.indexOf('#section_row_count') !== -1) {

					this.form_calc_do(calc, '#section_row_count');
					continue;
				}

				// Always run #section_row_index variable
				if(calc.value.indexOf('#section_row_index') !== -1) {

					this.form_calc_do(calc, '#section_row_index');
					continue;
				}

				// Check if any of the fields exist in the section added
				var field_section_id = calc.field.section_id;
				if(parseInt(field_section_id) === parseInt(section_repeatable_added_section_id)) {

					this.form_calc_do(calc, calc.field.id);
					continue;
				}

				// Check fields ID touched and if they belong in this section, and the field is outside this section, run the calculation
				if(calc.section_repeatable_index === false) {

					for(var field_ids_touched_index in calc.field_ids_touched) {

						if(!calc.field_ids_touched.hasOwnProperty(field_ids_touched_index)) { continue; }

						var field_id_touched = calc.field_ids_touched[field_ids_touched_index];
						var field_config = this.field_data_cache[field_id_touched];

						var section_repeatable_section_id = (typeof(field_config.section_repeatable_section_id) !== 'undefined') ? field_config.section_repeatable_section_id : false;

						if(parseInt(section_repeatable_section_id) === parseInt(section_repeatable_added_section_id)) {

							this.form_calc_do(calc, field_id_touched);
						}
					}
				}

			// EVENT: Field changed
			} else if(field_obj_id_changed !== false) {

				// Get field ID that initiated the change
				var field_obj = $('#' + field_obj_id_changed, this.form_canvas_obj);

				// Don't calculate on self if value
				var field_id_hidden = field_obj.attr('data-id-hidden');
				var field_wrapper_obj = field_id_hidden ? field_obj : field_obj.closest('[data-id]');
				var field_id = field_id_hidden ? parseInt(field_id_hidden, 10) : parseInt(field_wrapper_obj.attr('data-id'), 10);
				if(
					(field_id === calc.field.id) &&
					(calc.field_part == 'value')
				) {
					continue;
				}

				// Get fields that were touched by this calculation
				var field_ids_touched = calc.field_ids_touched;
				if(field_ids_touched.length > 0) {

					if(field_ids_touched.indexOf(field_id) !== -1) {

						// If this calculation is impacted by the field that was changed, run it
						this.form_calc_do(calc, field_id);
					}
				}

			} else {

				// EVENT: Full calculation
				this.form_calc_do(calc, ($.WS_Form.debug_rendered) ? this.language('log_' + calc.type + '_init') : '');
			}
		}
	}

	$.WS_Form.prototype.form_calc_do = function(calc, debug_log_triggered_string) {

		// Log
		if($.WS_Form.debug_rendered) {

			this.log('log_' + calc.type + '_fired', calc.field.label + ' - ' + this.html_encode(calc.value) + (debug_log_triggered_string ? ' (' + this.language('log_' + calc.type + '_fired_triggered', debug_log_triggered_string) + ')' : ''), calc.type);
		}

		// Check field configuration calc_in
		if(typeof($.WS_Form.field_type_cache[calc.field.type]) === 'undefined') { return; }
		var field_config = $.WS_Form.field_type_cache[calc.field.type];
		var allow_in = typeof(field_config[calc.type + '_in']) ? field_config[calc.type + '_in'] : false;
		if(!allow_in) {

			this.error('error_parse_variable_syntax_error_' + calc.type + '_in', 'ID: ' + calc.field.id, 'parse-variables');
			return;
		}

		// Parse default value
		var value = this.parse_variables_process(calc.value, calc.section_repeatable_index, calc.type, calc.field, false, false).output;

		switch(calc.field_part) {

			case 'field_text_editor' :

				// Get field object
				var field_wrapper_id = this.get_part_id(calc.field.id, calc.section_repeatable_index, 'field-wrapper');
				var target_obj = $('[data-text-editor]', $('#' + field_wrapper_id, this.form_canvas_obj));

				// Set HTML
				target_obj.html(value);

				break;

			case 'field_html' :

				// Get field object
				var field_wrapper_id = this.get_part_id(calc.field.id, calc.section_repeatable_index, 'field-wrapper');
				var target_obj = $('[data-html]', $('#' + field_wrapper_id, this.form_canvas_obj));

				// Set HTML
				target_obj.html(value);

				break;

			case 'field_label' :

				// Get field object
				var label_id = this.get_part_id(calc.field.id, calc.section_repeatable_index, 'label');
				var target_obj = $('#' + label_id, this.form_canvas_obj);

				// Get any child elements (e.g. required)
				var target_obj_children = target_obj.children('.wsf-required-wrapper');

				// Set HTML
				target_obj.html(value);

				// Put child elements back (e.g. required)
				if(target_obj_children) {

					target_obj.append(target_obj_children);
				}

				break;

			case 'field_help' :

				// Get field object
				var help_id = this.get_part_id(calc.field.id, calc.section_repeatable_index, 'help');
				var target_obj = $('#' + help_id, this.form_canvas_obj);

				// Set HTML
				target_obj.html(value);

				break;

			case 'field_placeholder' :
			case 'field_min' :
			case 'field_max' :

				switch(calc.field_part) {

					case 'field_min' :
					case 'field_max' :

						var value_number = this.get_number(value, 0, false);

						// Range slider bug fix
						if(
							(value_number % 1 != 0) &&
							((calc.field.type === 'range') || (calc.field.type === 'price_range'))
						) {
							value = this.get_number_rounded(value_number, 8);
						}

						break;
				}

				// Get field object
				var field_id = this.get_part_id(calc.field.id, calc.section_repeatable_index);
				var target_obj = $('#' + field_id, this.form_canvas_obj);

				// Get attribute name
				var attribute_name = calc.field_part.substring(6);

				// Remember old value
				var value_old = target_obj.attr(attribute_name);

				// Set HTML
				target_obj.attr(attribute_name, value);

				// Determine if date field should be re-rendered
				if(
					this.datetimepicker_enabled() &&
					(calc.field.type === 'datetime')
				) {

					target_obj.datetimepicker('destroy');
					this.form_date_process(target_obj);
				}

				// Trigger change if value changed
				if(value_old !== target_obj.attr(attribute_name)) { target_obj.trigger('change'); }

				break;

			case 'field_ecommerce_price_min' :
			case 'field_ecommerce_price_max' :

				// Get field object
				var field_id = this.get_part_id(calc.field.id, calc.section_repeatable_index);
				var target_obj = $('#' + field_id, this.form_canvas_obj);

				// Get attribute name
				var attribute_name = calc.field_part.substring(6);

				// Remember old value
				var value_old = target_obj.attr(attribute_name);

				// Set HTML
				target_obj.attr('data-ecommerce-' + ((calc.field_part === 'field_ecommerce_price_min') ? 'min' : 'max'), value);

				// Re-process currency input mask
				this.form_ecommerce_input_mask_currency(target_obj);

				// Trigger change if value changed
				if(value_old !== target_obj.attr(attribute_name)) { target_obj.trigger('change'); }

				break;

			case 'field_value' :

				// Build field ID
				var field_id = this.get_part_id(calc.field.id, calc.section_repeatable_index);

				// Get field object
				var target_obj = $('#' + field_id, this.form_canvas_obj);

				// Get value for min, max and step values
				var min = max = step = false;
				switch(calc.field.type) {

					case 'progress' :
					case 'range' :
					case 'price_range' :

						value = this.get_number(value, 0, false);

						// Range slider bug fix
						if(
							(value % 1 != 0) &&
							((calc.field.type === 'range') || (calc.field.type === 'price_range'))
						) {
							value = this.get_number_rounded(value, 8);
						}

						var min = (typeof(target_obj.attr('min')) !== 'undefined') ? target_obj.attr('min') : 0;
						var max = (typeof(target_obj.attr('max')) !== 'undefined') ? target_obj.attr('max') : 100;
						var step = (typeof(target_obj.attr('step')) !== 'undefined') ? target_obj.attr('step') : 1;
						break;

					case 'price' :
					case 'price_subtotal' :
					case 'cart_price' :
					case 'number' :
					case 'quantity' :
					case 'wc_quantity' :

						value = this.get_number(value, 0, false);
						var min = (typeof(target_obj.attr('min')) !== 'undefined') ? target_obj.attr('min') : min;
						var max = (typeof(target_obj.attr('max')) !== 'undefined') ? target_obj.attr('max') : max;
						var step = (typeof(target_obj.attr('step')) !== 'undefined') ? target_obj.attr('step') : step;
						break;

					case 'datetime' :

						// Date format
						if(calc.type === 'calc') {

							value = this.get_number(value, 0, true);

							if(value > 0) {

								// Date format
								var format_date = target_obj.attr('data-date-format') ? target_obj.attr('data-date-format') : ws_form_settings.date_format;

								// Time format
								var format_time = target_obj.attr('data-time-format') ? target_obj.attr('data-time-format') : ws_form_settings.time_format;

								// Get date time format string
								switch(target_obj.attr('data-date-type')) {

									case 'date' :

										var date_format = format_date;
										break;

									case 'time' :

										var date_format = format_time;
										args.step = 15;
										break;

									case 'month' :

										var date_format = 'F Y';
										break;

									case 'week' :

										var date_format = '\\W\\e\\e\\k W, Y';
										break;

									default :

										var date_format = format_date + ' ' + format_time;
								}

								value = this.date_format(new Date(value * 1000), date_format);

							} else {

								value = '';
							}
						}

						break;
				}

				// Process values for min, max and step values
				if((min !== false) && (value < min)) { value = min; }
				if((max !== false) && (value > max)) { value = max; }
				if(step !== false) { value = this.get_number_to_step(value, step); }				

				// Determine if field trigger should occur
				switch(calc.field.type) {

					case 'price' :
					case 'price_range' :
					case 'price_subtotal' :
					case 'cart_price' :

						var field_trigger = (this.get_number(target_obj.val(), 0, true) !== value);

						value = this.get_price(value);

						break;

					case 'progress' :
					case 'range' :
					case 'number' :
					case 'quantity' :
					case 'wc_quantity' :

						var field_trigger = (this.get_number(target_obj.val(), 0, false) !== value);

						break;

					default :

						var field_trigger = (target_obj.val() !== value);

						break;
				}

				// Set value
				switch(calc.field.type) {

					case 'progress' :

						// form_progress_set_value handles the change trigger
						this.form_progress_set_value(target_obj, value);
						break;

					case 'price' :
					case 'price_range' :
					case 'price_subtotal' :
					case 'cart_price' :

						// These exceptions are required to handle negative price values
						target_obj.val(value);
						if(field_trigger) { target_obj.trigger('change'); }
						break;

					default :

						target_obj.val(value);
						var value_new = target_obj.val();

						// If the set value equals the get value, and field_trigger, trigger change event (Ensures input can accept that value)
						if((value == value_new) && field_trigger) {

							target_obj.trigger('change');
						}
				}
		}
	}

	// Form e-commerce
	$.WS_Form.prototype.form_ecommerce = function() {

		var ws_this = this;

		// Has e-commerce?
		this.has_ecommerce = $('[data-ecommerce-price],[data-ecommerce-cart-price],[data-ecommerce-cart-total],[data-ecommerce-payment]', this.form_canvas_obj).length;
		if(!this.has_ecommerce) { return; }

		// Add price type
		for(var price_type in $.WS_Form.ecommerce.cart_price_types) {

			if(!$.WS_Form.ecommerce.cart_price_types.hasOwnProperty(price_type)) { continue; }

			this.form_add_hidden_input('wsf_ecommerce_cart[' + price_type + ']', '', ws_this.form_id_prefix + 'ecommerce-cart-' + price_type);
		}

		// Add e-commerce fields to form
		this.form_add_hidden_input('wsf_ecommerce_cart[total]', '', ws_this.form_id_prefix + 'ecommerce-cart-total');
		this.form_add_hidden_input('wsf_ecommerce_transaction', '', ws_this.form_id_prefix + 'ecommerce-transaction');
		this.form_add_hidden_input('wsf_ecommerce_transaction_id', '', ws_this.form_id_prefix + 'ecommerce-transaction-id');
		this.form_add_hidden_input('wsf_ecommerce_status', '', ws_this.form_id_prefix + 'ecommerce-status');
		this.form_add_hidden_input('wsf_ecommerce_payment_method', '', ws_this.form_id_prefix + 'ecommerce-payment-method');

		// Set ecommerce status to new
		this.form_ecommerce_set_status('new');

		// Initialize cart price type array for storing values
		this.ecommerce_cart_price_type = [];

		// Apply input masks
		this.form_ecommerce_input_mask_currency();

		// Event handlers
		$('input[data-ecommerce-price]:not([data-init-ecommerce-event]),input[data-ecommerce-cart-price]:not([data-init-ecommerce-event]),select[data-ecommerce-price]:not([data-init-ecommerce-event])', this.form_canvas_obj).on('keyup change input paste', function(e) {

			// Flag so it only initializes once
			$(this).attr('data-init-ecommerce-event', '');

			// Check for values less than min
			if(typeof($(this).attr('min')) !== 'undefined') {

				var min = parseInt($(this).attr('min'), 10);
				if(
					(e.type == 'input') &&
					(parseInt($(this).val(), 10) < min)

				) { $(this).val(min); }
			}

			// Check for values greater than max
			if(typeof($(this).attr('max')) !== 'undefined') {

				var max = parseInt($(this).attr('max'), 10);
				if(
					(e.type == 'input') &&
					(parseInt($(this).val(), 10) > max)

				) { $(this).val(max); }
			}

			// Recalculate
			ws_this.form_ecommerce_calculate();
		});

		$('input[data-ecommerce-quantity]:not([data-init-ecommerce-event])', this.form_canvas_obj).on('keyup change input paste', function(e) {

			// Flag so it only initializes once
			$(this).attr('data-init-ecommerce-event', '');

			// Check for blank quantity values
			if(
				(e.type == 'change') &&
				($(this).val() == '')

			) { $(this).val(0); }

			// Check for values less than min
			if(typeof($(this).attr('min')) !== 'undefined') {

				var min = parseInt($(this).attr('min'), 10);
				if(
					(e.type == 'input') &&
					(parseInt($(this).val(), 10) < min)

				) { $(this).val(min); }
			}

			// Check for values greater than max
			if(typeof($(this).attr('max')) !== 'undefined') {

				var max = parseInt($(this).attr('max'), 10);
				if(
					(e.type == 'input') &&
					(parseInt($(this).val(), 10) > max)

				) { $(this).val(max); }
			}

			// Recalculate
			ws_this.form_ecommerce_calculate();
		});

		// Initial calculation
		this.form_ecommerce_calculate();
	}

	// Form e-commerce - Input mask currency
	$.WS_Form.prototype.form_ecommerce_input_mask_currency = function(obj) {

		var ws_this = this;

		if(typeof(obj) === 'undefined') {

			obj = $('input[type="text"][data-ecommerce-price],input[data-ecommerce-cart-price],input[data-ecommerce-cart-total]', this.form_canvas_obj);
		}

		// Apply input mask to price fields
		obj.each(function() {

			// Plugin level config
			var currency = ws_this.get_currency();

			// Build input mask settings
			var input_mask_settings = {

				digits: currency.decimals,
				allowMinus: $(this)[0].hasAttribute('data-ecommerce-negative'),
				suffix: currency.suffix,
				groupSeparator: currency.thousand_separator,
				radixPoint: currency.decimal_separator,
				prefix: currency.prefix,
				removeMaskOnSubmit: true,
				rightAlign: false,
				clearMaskOnLostFocus : false
			};

			// Min
			if($(this)[0].hasAttribute('data-ecommerce-min')) { input_mask_settings.min = $(this).attr('data-ecommerce-min'); }

			// Max
			if($(this)[0].hasAttribute('data-ecommerce-max')) { input_mask_settings.max = $(this).attr('data-ecommerce-max'); }

			// Apply input mask
			if(typeof($(this).inputmask) !== 'undefined') {

				$(this).inputmask('currency', input_mask_settings);
			}
		});
	}

	// Form e-commerce - Calculate
	$.WS_Form.prototype.form_ecommerce_calculate = function() {

		if(!this.form_ecommerce_calculate_enabled) { return; }

		// Totals
		var ecommerce_cart_subtotal = 0;
		var ecommerce_cart_totals = [];
		var ecommerce_cart_total_float = 0;

		var currency = this.get_currency();
		var price_subtotal_array = [];

		var ws_this = this;

		// Run through all the price fields
		$('input[data-ecommerce-price],select[data-ecommerce-price]', this.form_canvas_obj).not('[data-ecommerce-price-bypass],[data-ecommerce-price-bypass-section]').each(function() {

			// Get field ID
			var field_id = ws_this.get_field_id($(this));

			// Get repeatable index
			var section_repeatable_index = ws_this.get_section_repeatable_index($(this));

			// Get repeatable suffix
			var section_repeatable_suffix = ws_this.get_section_repeatable_suffix($(this));

			// Price subtotal array index
			var price_subtotal_array_index = field_id + section_repeatable_suffix;

			// Field product type
			var field_product_type = $(this).closest('[data-ecommerce-cart-price-type]');
			if(field_product_type.length) { field_product_type = field_product_type.attr('data-ecommerce-cart-price-type'); } else { field_product_type = 'subtotal'; }

			if(typeof(price_subtotal_array[price_subtotal_array_index]) === 'undefined') {

				price_subtotal_array[price_subtotal_array_index] = {

					subtotal: 0,
					type: field_product_type,
					field_id: field_id,
					section_repeatable_index: section_repeatable_index,
					exclude_price_cart: (typeof($(this).attr('data-wsf-exclude-cart-total')) !== 'undefined')
				};
			}

			// Get price
			switch($(this).attr('type')) {

				case 'checkbox' :
				case 'radio' :

					price_subtotal_array[price_subtotal_array_index].subtotal += $(this).is(':checked') ? ws_this.get_number($(this).attr('data-price'), 0, true) : 0;
					break;

				default :

					if($(this).is('select')) {

						$(this).find('option:selected').each(function() {

							price_subtotal_array[price_subtotal_array_index].subtotal += ws_this.get_number($(this).attr('data-price'), 0, true);
						})

					} else {

						price_subtotal_array[price_subtotal_array_index].subtotal += ws_this.get_number($(this).val());
					}
			}
		});

		// Calculate sub-totals
		for(var price_subtotal_array_index in price_subtotal_array) {

			if(!price_subtotal_array.hasOwnProperty(price_subtotal_array_index)) { continue; }

			// Get field ID
			var field_id = price_subtotal_array[price_subtotal_array_index].field_id;

			// Get field repeatable index
			var section_repeatable_index = price_subtotal_array[price_subtotal_array_index].section_repeatable_index;

			// Get price subtotal (price * quantity) calculated above
			var price_subtotal = price_subtotal_array[price_subtotal_array_index].subtotal;

			// Price type
			var price_type = price_subtotal_array[price_subtotal_array_index].type;

			// Price type
			var exclude_price_cart = price_subtotal_array[price_subtotal_array_index].exclude_price_cart;

			// Find associated quantity field
			if(section_repeatable_index === 0) {

				var quantity_obj = $('input[data-ecommerce-quantity][data-ecommerce-field-id="' + field_id + '"]', this.form_canvas_obj);

			} else {

				var quantity_obj = $('[data-repeatable-index="' + section_repeatable_index + '"] input[data-ecommerce-quantity][data-ecommerce-field-id="' + field_id + '"]', this.form_canvas_obj);
			}
			if(quantity_obj.length) {

				// Multiply price by quantity
				var quantity = this.get_number(quantity_obj.first().val());
				price_subtotal *= quantity;
			};

			// Find associated subtotal field
			if(section_repeatable_index === 0) {

				var field_obj = $('input[data-ecommerce-price-subtotal][data-ecommerce-field-id="' + field_id + '"]', this.form_canvas_obj);

			} else {

				var field_obj = $('[data-repeatable-index="' + section_repeatable_index + '"] input[data-ecommerce-price-subtotal][data-ecommerce-field-id="' + field_id + '"]', this.form_canvas_obj);
			}

			if(field_obj.length) {

				var field_trigger = (this.get_number(field_obj.val(), 0, true) !== this.get_number(price_subtotal, 0, false));
				field_obj.val(this.get_price(price_subtotal, currency));
				if(field_trigger) { field_obj.trigger('change'); }
			}

			// Add to total by price type
			if(!exclude_price_cart) {

				if(typeof(ecommerce_cart_totals[price_type]) === 'undefined') { ecommerce_cart_totals[price_type] = 0; }
				ecommerce_cart_totals[price_type] += price_subtotal;
			}
		}

		// Process price types and calculate cart total
		for(var price_type in $.WS_Form.ecommerce.cart_price_types) {

			if(!$.WS_Form.ecommerce.cart_price_types.hasOwnProperty(price_type)) { continue; }

			// Read price type config
			var price_type_config = $.WS_Form.ecommerce.cart_price_types[price_type];
	
			// Should this price type be included in the ecommerce_cart_total_float calculation?
			var sum = (typeof(price_type_config.sum) !== 'undefined') ? price_type_config.sum : true;

			// Should we render the value of this calculated price type?
			var render = (typeof(price_type_config.render) !== 'undefined') ? price_type_config.render : false;

			// Calculate cart total
			if(price_type == 'subtotal') {

				var price_float = (typeof(ecommerce_cart_totals[price_type]) !== 'undefined') ? ecommerce_cart_totals[price_type] : 0;

			} else {

				// Add up all instances of this price type on the form at that are visible (i.e. includes attrbute data-ecommerce-cart-price)
				var price_float = 0;
				$('input[data-ecommerce-cart-price][data-ecommerce-cart-price-' + price_type + ']', this.form_canvas_obj).each(function() {

					price_float += ws_this.get_number($(this).val());
				});
			}

			if(sum) {

				// Add this price type to the cart total
				ecommerce_cart_total_float += price_float;
			}

			// Should WS Form render this value to the price type field? (e.g. Subtotal)
			if(render && sum) {

				var price_string = this.get_price(price_float, currency, false);
				var price_currency = this.get_price(price_float, currency);

				// Render price
				var price_type_selector = '[data-ecommerce-cart-price-' + price_type + ']';
				var price_type_total_id = '#' + this.form_id_prefix + 'ecommerce-cart-' + price_type;
				this.form_ecommerce_price_type_set(price_type, price_type_selector, price_type_total_id, price_float, price_string, price_currency);
			}
		}

		// Convert to string
		var price_string = this.get_price(ecommerce_cart_total_float, currency, false);
		var price_currency = this.get_price(ecommerce_cart_total_float, currency);

		// Save amount
		this.ecommerce_cart_price_type['total'] = {

			'float': ecommerce_cart_total_float,
			'string': price_string,
			'currency': price_currency,
		};

		// Render prices
		var price_type_selector = '[data-ecommerce-cart-total]';
		var price_type_total_id = '#' + this.form_id_prefix + 'ecommerce-cart-total';
		this.form_ecommerce_price_type_set(false, price_type_selector, price_type_total_id, ecommerce_cart_total_float, price_string, price_currency);
	}

	// Form e-commerce - Set price
	$.WS_Form.prototype.form_ecommerce_price_type_set = function(price_type, price_type_selector, price_type_total_id, price_float, price_string, price_currency) {

		var ws_this = this;

		// Set cart total fields
		var field_obj = $(price_type_selector, this.form_canvas_obj);

		field_obj.each(function() {

			if($(this).is('input')) {

				// Set input
				var field_trigger = (ws_this.get_number($(this).val(), 0, true) != ws_this.get_number(price_currency, 0));
				$(this).val(price_string);	// Must use price_string so that decimal and thousand separators are set
				if(field_trigger) { $(this).trigger('change'); }
			}

			if($(this).is('span')) {

				// Set span
				var ecommerce_price_span = (typeof($(this).attr('data-ecommerce-price-currency')) !== 'undefined') ? price_currency : price_string;
				$(this).html(ecommerce_price_span);
			}
		});

		// Set hidden price type field
		var field_obj = $(price_type_total_id, this.form_canvas_obj);
		var field_trigger = (ws_this.get_number(field_obj.val(), 0, false) != ws_this.get_number(price_float, 0, false));
		field_obj.val(price_float)
		if(field_trigger) { field_obj.trigger('change'); }

		if(price_type !== false) {

			// Save amount
			this.ecommerce_cart_price_type[price_type] = {

				'float': price_float,
				'string': price_string,
				'currency': price_currency,
			};
		}
	}

	// Form e-commerce - Payment error
	$.WS_Form.prototype.form_ecommerce_payment_error = function(error_message) {

		// Log error
		this.error('error_payment', error_message, 'payment');
	}

	// Form e-commerce - Payment processed
	$.WS_Form.prototype.form_ecommerce_payment_process = function(transaction_id, amount, payment_method) {

		// Change status
		this.form_ecommerce_set_status('completed');

		// Set transaction ID
		this.form_ecommerce_set_transaction_id(transaction_id);

		// Set payment method
		this.form_ecommerce_set_payment_method(payment_method);

		// Set payment amount (Overrides calculated amount in case the payment button has a fixed value, we always want to show the processed amount in submissions)
		this.form_ecommerce_set_payment_amount(amount);

		// Submit the form and run actions
		this.form_obj.submit();
	}

	// Form e-commerce - Set status
	$.WS_Form.prototype.form_ecommerce_set_status = function(status) {

		$('#' + this.form_id_prefix + 'ecommerce-status', this.form_canvas_obj).val(status);
		this.log('log_ecommerce_status', status, 'ecommerce');
	}

	// Form e-commerce - Set transaction ID
	$.WS_Form.prototype.form_ecommerce_set_transaction_id = function(transaction_id) {

		$('#' + this.form_id_prefix + 'ecommerce-transaction-id', this.form_canvas_obj).val(transaction_id);
		this.log('log_ecommerce_transaction_id', transaction_id, 'ecommerce');
	}

	// Form e-commerce - Set transaction
	$.WS_Form.prototype.form_ecommerce_set_transaction = function(transaction) {

		$('#' + this.form_id_prefix + 'ecommerce-transaction', this.form_canvas_obj).val(transaction);
	}

	// Form e-commerce - Set payment method
	$.WS_Form.prototype.form_ecommerce_set_payment_method = function(payment_method) {

		$('#' + this.form_id_prefix + 'ecommerce-payment-method', this.form_canvas_obj).val(payment_method);
		this.log('log_ecommerce_payment_method', payment_method, 'ecommerce');
	}

	// Form e-commerce - Set cart total amount
	$.WS_Form.prototype.form_ecommerce_set_payment_amount = function(amount) {

		this.form_ecommerce_calculate_enabled = false;
		$('#' + this.form_id_prefix + 'ecommerce-cart-total', this.form_canvas_obj).val(amount).trigger('change');
		this.log('log_ecommerce_payment_amount', amount, 'ecommerce');
	}

	// Form credit card
	$.WS_Form.prototype.form_credit_card = function() {

		var ws_this = this;

		$('input[data-credit-card]:not([data-init-credit-card])', this.form_canvas_obj).each(function() {

			// Set attribute so it doesn't initialize again
			$(this).attr('data-init-credit-card', '');

			// Set event
			$(this).on("input", function() {

				if(typeof($(this).inputmask) === 'undefined') { return; }

				var value = $(this).val().replace(/\D/g, '');
				var mask;

				if ((/^3[47]\d{0,13}$/).test(value)) {

					// American Express
					mask = '9999 999999 99999'

				} else if ((/^3(?:0[0-5]|[68]\d)\d{0,11}$/).test(value)) { 

					// Diner's Club
					mask = '9999 999999 9999'

				} else if ((/^\d{0,16}$/).test(value)) {

					// Other Credit Cards
					mask = '9999 9999 9999 9999'

				} else {

					// Unknown
					mask = 'remove'
				}

				if($(this).attr('data-currentmask') != mask) {

					$(this).attr('data-currentmask', mask)
					$(this).inputmask(mask, { placeholder: '', clearMaskOnLostFocus: false });
				}
			});
		});
	}

	// Form file inputs
	$.WS_Form.prototype.form_file = function() {

		var ws_this = this;

		// Regular file fields
		$('input[type="file"]:not([data-init-file])', this.form_canvas_obj).each(function() {

	 		// Get field data
			var field = ws_this.get_field($(this));

			// Check for file preview
			var obj_file_preview = false;
			var preview = (ws_this.get_object_meta_value(field, 'file_preview', false) === 'on');
			if(preview) {

				// Field - Attributes - Orientation
				var orientation = ws_this.get_object_meta_value(field, 'orientation', false);

				// Get skin grid gutter
				var skin_grid_gutter = ws_form_settings.skin_grid_gutter;

				switch(orientation) {

					case 'grid' :

						// Get wrapper and row classes
						var class_orientation_wrapper_array = ws_this.get_field_value_fallback(field.type, false, 'class_orientation_wrapper', []);
						var class_orientation_row_array = ws_this.get_field_value_fallback(field.type, false, 'class_orientation_row', []);
						class_orientation_wrapper_array.push('wsf-file-preview');
						var orientation_group_wrapper_class = class_orientation_wrapper_array.join(' ');
						var orientation_class_array = ws_this.column_class_array(field, 'orientation_breakpoint');
						orientation_class_array = class_orientation_row_array.concat(orientation_class_array);
						var orientation_row_class = orientation_class_array.join(' ');

						// Get row and img styles
						var orientation_row_style = '';
						var orientation_el_style = 'display: block; height: revert; margin-top: ' + skin_grid_gutter + 'px; width: 100%;';

						break;

					case 'horizontal' :

						// Get wrapper and row classes
						var orientation_group_wrapper_class = 'wsf-file-preview';
						var orientation_row_class = '';

						// Get row and img styles
						var file_preview_width = ws_this.get_object_meta_value(field, 'file_preview_width', false);
						var orientation_row_style = 'display: inline-block; -webkit-margin-end: ' + skin_grid_gutter + 'px; margin-inline-end: ' + skin_grid_gutter + 'px; vertical-align: top;' + ((file_preview_width !== false) ? ' width: ' + file_preview_width + ';' : '');
						var orientation_el_style = 'display: block; height: revert; margin-top: ' + skin_grid_gutter + 'px; max-width: 100%; width: revert;';

						break;

					default :

						// Get wrapper and row classes
						var orientation_group_wrapper_class = 'wsf-file-preview';
						var orientation_row_class = '';

						// Get row and img styles
						var orientation_row_style = '';
						var orientation_el_style = 'display: block; height: revert; margin-top: ' + skin_grid_gutter + 'px; max-width: 100%; width: 100%;';
				}

				// Initialize
				var obj_file_preview = $('<div' + ((orientation_group_wrapper_class != '') ? ' class="' + orientation_group_wrapper_class + '"' : '') + '></div>');
				$(this).closest('[data-type]').append(obj_file_preview);
			}

			$(this).on('change', function() {

				var files = $(this)[0].files;

				// File preview?
				if(obj_file_preview !== false) {

					ws_this.form_file_preview(files, obj_file_preview, orientation_row_class, orientation_row_style, orientation_el_style);
				}
			});

			// Flag so it only initializes once
			$(this).attr('data-init-file', '');
		});

		// DropzoneJS
		if(typeof(Dropzone) !== 'undefined') {

	 		$('[data-file-type="dropzonejs"]:not([data-init-file])', this.form_canvas_obj).each(function() {


		 		// Get field data
				var field_id = ws_this.get_field_id($(this));
				var field = ws_this.get_field($(this));

				Dropzone.autoDiscover = false;

				var field_obj = $(this);
				var field_obj_id = $(this).attr('id');
				var field_multiple = (typeof($(this).attr('multiple')) !== 'undefined');

				// Progress
				var progress_objs = $('[data-source="post_progress"]', this.form_canvas_obj);

				// Orientation
				var orientation = ws_this.get_object_meta_value(field, 'orientation', false);

				var file_thumbnail_width = null;
				var file_thumbnail_height = null;

				// Get skin grid gutter
				var skin_grid_gutter = ws_form_settings.skin_grid_gutter;

				switch(orientation) {

					case 'grid' :

						// Get wrapper and row classes
						var class_orientation_wrapper_array = ws_this.get_field_value_fallback('file', false, 'class_orientation_wrapper', []);
						class_orientation_wrapper_array.push('wsf-dropzonejs-previews');
						var orientation_group_wrapper_class = class_orientation_wrapper_array.join(' ');

						var class_orientation_row_array = ws_this.get_field_value_fallback('file', false, 'class_orientation_row', []);
						var orientation_class_array = ws_this.column_class_array(field, 'orientation_breakpoint');
						orientation_class_array = class_orientation_row_array.concat(orientation_class_array);
						orientation_class_array.push('wsf-dropzonejs-preview');
						var orientation_row_class = orientation_class_array.join(' ');

						// Get row and img styles
						var orientation_row_style = 'margin-bottom: ' + skin_grid_gutter + 'px;';
						var orientation_el_style = 'display: block; height: revert; width: 100%;';

						break;

					case 'horizontal' :

						// Get wrapper and row classes
						var orientation_group_wrapper_class = 'wsf-dropzonejs-previews';
						var orientation_row_class = 'wsf-dropzonejs-preview';

						// Get row and img styles
						var file_preview_width = ws_this.get_object_meta_value(field, 'file_preview_width', false);
						var orientation_row_style = 'display: inline-block; margin-bottom: ' + skin_grid_gutter + 'px; -webkit-margin-end: ' + skin_grid_gutter + 'px; margin-inline-end: ' + skin_grid_gutter + 'px; vertical-align: top;' + ((file_preview_width !== false) ? ' width: ' + file_preview_width + ';' : '');
						var orientation_el_style = 'display: block; width: revert; height: revert; max-width: 100%;';

						var file_preview_width_numeric = parseInt(ws_this.replace_all(file_preview_width, 'px', ''));

						file_thumbnail_width = file_preview_width_numeric;
						file_thumbnail_height = file_preview_width_numeric;

						break;

					default :

						// Get wrapper and row classes
						var orientation_group_wrapper_class = 'wsf-dropzonejs-previews';
						var orientation_row_class = 'wsf-dropzonejs-preview';

						// Get row and img styles
						var orientation_row_style = 'margin-bottom: ' + skin_grid_gutter + 'px;';
						var orientation_el_style = 'display: block; height: revert; max-width: 100%; width: 100%;';
				}

				// Apply classes
				$('#' + field_obj_id + '-dropzonejs-previews').attr('class', orientation_group_wrapper_class);

				// Preview template - Error message
				var mask_invalid_feedback = ws_this.get_field_value_fallback('file', false, 'mask_invalid_feedback_dropzonejs', '');
				var mask_values_invalid_feedback = [];
				mask_values_invalid_feedback['invalid_feedback_id'] = '#' + field_obj_id + '-dropzone-error-message';
				var class_invalid_feedback_array = ws_this.get_field_value_fallback('file', false, 'class_invalid_feedback', []);
				mask_values_invalid_feedback['invalid_feedback_class'] = class_invalid_feedback_array.join(' ');
				mask_values_invalid_feedback['invalid_feedback'] = '';
				mask_values_invalid_feedback['attributes'] = ' data-dz-errormessage';
				var preview_template_error_message = ws_this.mask_parse(mask_invalid_feedback, mask_values_invalid_feedback);

				// Preview template - Name, size, remove
				var mask_help = ws_this.get_field_value_fallback('file', false, 'mask_help_dropzonejs', '');
				var mask_values_help = [];
				mask_values_help['help_id'] = '#' + field_obj_id + '-dropzone-name';
				var class_help_array = ws_this.get_field_value_fallback('file', false, 'class_help', []);
				mask_values_help['help_class'] = class_help_array.join(' ');
				mask_values_help['help'] = '';
				mask_values_help['help_append'] = '';

				// Name
				mask_values_help['attributes'] = ' data-dz-name';
				var preview_template_name = ws_this.mask_parse(mask_help, mask_values_help);

				// Size
				mask_values_help['attributes'] = ' data-dz-size';
				var preview_template_size = ws_this.mask_parse(mask_help, mask_values_help);

				// Remove
				mask_values_help['attributes'] = '';
				mask_values_help['help'] = '<a href="#" data-dz-remove>' + ws_this.language('dropzonejs_remove') + '</a>';
				var preview_template_remove = ws_this.mask_parse(mask_help, mask_values_help);

				// Preview template
				var preview_template = '<div class="' + (orientation_row_class ? ' ' + orientation_row_class : '') + ((orientation_row_style != '') ? '" style="' + orientation_row_style + '"' : '') + '">';
				preview_template += '<img data-dz-thumbnail style="' + (orientation_el_style ? ' ' + orientation_el_style : '') + '" />';
				preview_template += preview_template_error_message;
				preview_template += preview_template_name;
				preview_template += preview_template_size;
				preview_template += '<div class="wsf-progress"><div class="wsf-upload" data-dz-uploadprogress></div></div>';
				preview_template += preview_template_remove;
				preview_template += '</div>';

				// DropzoneJS args
				var args = {

					url : ws_form_settings.url + 'field/' + field_id + '/dropzonejs/',
					paramName: 'file',
					uploadMultiple: field_multiple,
					previewTemplate: preview_template,
					previewsContainer: '#' + field_obj_id + '-dropzonejs-previews',
					thumbnailWidth: file_thumbnail_width,
					thumbnailHeight: file_thumbnail_height,
					init: function() {

						this.add_custom_file = function(file, thumbnail_url, response) {

							this.files.push(file);
							this.emit('addedfile', file);
							this.emit('thumbnail', file, thumbnail_url);
							this.emit('processing', file);
							this.emit('success', file, response, false);
							this.emit('complete', file);

							this.element.classList.add('dz-started');
						}

						this.ajax_complete = function() {

							if(ws_this.dropzonejs_processes > 0) {

								ws_this.dropzonejs_processes--;
							}

							if(ws_this.dropzonejs_processes === 0) {

								ws_this.form_post_unlock('progress', false, true);

								progress_objs.each(function() {

									ws_this.form_progress_set_value($(this), 0);
								});
							}
						};

						this.input_update = function() {

							// Rebuild 
							var attachment_ids = {};

							for(var dropzonejs_obj_files_index in dropzonejs_obj.files) {

								if(!dropzonejs_obj.files.hasOwnProperty(dropzonejs_obj_files_index)) { continue; }

								var file = dropzonejs_obj.files[dropzonejs_obj_files_index];

								if(
									(file.status !== 'success') ||
									(typeof(file.upload.uuid) === 'undefined') ||
									(typeof(file.upload.attachment_id) === 'undefined')
								) {

									continue;
								}

								attachment_ids[file.upload.uuid] = file.upload.attachment_id;
							}

							// Push to field value
							field_obj.val(Object.keys(attachment_ids).length ? JSON.stringify({type: 'dropzonejs', attachment_ids: attachment_ids}) : '').trigger('change');
						}

						this.on("addedfile", function(file) {

							this.element.classList.add('dz-started');

							ws_this.dropzonejs_processes++;
						});
					}
				};

				// Accepted files
				var field_accepted_files = ws_this.get_object_meta_value(field, 'accept', '');
				if(field_accepted_files != '') { args.acceptedFiles = field_accepted_files; }

				// Max files
				var field_max_files = parseInt(ws_this.get_object_meta_value(field, 'file_max', 0), 10);
				args.maxFiles = field_multiple ? ((field_max_files > 0) ? field_max_files : null) : 1;

				// Max file size
				var field_max_size = parseInt(ws_this.get_object_meta_value(field, 'file_max_size', 0), 10);
				if(field_max_size > 0) { args.maxFilesize = field_max_size; }

				// Resize - Width
				var field_resize_width = parseInt(ws_this.get_object_meta_value(field, 'file_image_max_width', 0), 10);
				if(field_resize_width > 0) { args.resizeWidth = field_resize_width; }

				// Resize - Height
				var field_resize_height = parseInt(ws_this.get_object_meta_value(field, 'file_image_max_height', 0), 10);
				if(field_resize_height > 0) { args.resizeHeight = field_resize_height; }

				// Resize - Method
				var field_resize_method = (ws_this.get_object_meta_value(field, 'file_image_crop', '') == 'on');
				args.resizeMethod = field_resize_method ? 'crop' : 'contain';

				// Resize - Compression
				var field_resize_quality = parseInt(ws_this.get_object_meta_value(field, 'file_image_max_height', 100), 10);
				if(field_resize_quality > 0) { args.resizeQuality = field_resize_quality / 100; }

				// Resize - MIME
				var field_resize_mime_type = ws_this.get_object_meta_value(field, 'file_image_mime', '');
				if(field_resize_mime_type != '') { args.resizeMimeType = field_resize_mime_type; }

				// Capture
				var field_capture = ws_this.get_object_meta_value(field, 'file_capture', '');
				if(field_capture != '') { args.capture = field_capture; }

				// Timeout
				var file_timeout = parseInt(ws_this.get_object_meta_value(field, 'file_timeout', ''), 10);
				if(file_timeout > 0) { args.timeout = file_timeout; }

				// Create DropzoneJS
				var dropzonejs_obj = new Dropzone('#' + field_obj_id + '-dropzonejs', args);

				// Event handling (Pass through to input field)
				$('#' + field_obj_id + '-dropzonejs').on('click mousedown mouseup mouseover mouseout touchstart touchend touchmove touchcancel', function(e) {

					$('#' + field_obj_id).trigger(e.type);
				});

				// Sortable
				$('#' + field_obj_id + '-dropzonejs').sortable({

					items: '.wsf-dropzonejs-preview',
					cursor: 'move',
					tolerance: 'pointer',
					forceHelperSize: true,
					cancel: '[data-dz-remove]',

					start: function(e, ui) {

						// Get index being dragged
						ws_this.dropzonejs_index_dragged_from = ui.helper.index();

						ui.placeholder.attr('style', orientation_row_style);

						var height = ui.helper.height();
						var width = ui.helper.outerWidth();
						ui.placeholder.css({width: width + 'px', height: height + 'px'});
					},

					stop: function(e, ui) {

						// Get index dragged to
						var dropzonejs_index_old = ws_this.dropzonejs_index_dragged_from;
						var dropzonejs_index_new = ui.item.index();

						// Move meta data index
						if (dropzonejs_index_new >= dropzonejs_obj.files.length) {

							var k = dropzonejs_index_new - dropzonejs_obj.files.length;
							while ((k--) + 1) {
								dropzonejs_obj.files.push(undefined);
							}
						}
						dropzonejs_obj.files.splice(dropzonejs_index_new, 0, dropzonejs_obj.files.splice(dropzonejs_index_old, 1)[0]);

						// Push to field value
						dropzonejs_obj.input_update();
					},
				});

				// Check for existing files
				var field_value = $(this).val();

				if(field_value != '') {

					// Get existing file objects
					try {

						var file_objects = JSON.parse(field_obj.val());

					} catch(e) {

						var file_objects = [];
					}

					for(var file_object_index in file_objects) {

						if(!file_objects.hasOwnProperty(file_object_index)) { continue; }

						var file_object = file_objects[file_object_index];

						if(typeof(file_object['name']) === 'undefined') { continue; }

						var file = {

							processing: true,
							accepted: true,
							name: file_object['name'],
							size: file_object['size'],
							type: file_object['type'],
							upload: { uuid: file_object['uuid'], attachment_id: file_object['attachment_id'] },
							status: Dropzone.SUCCESS
						};

						dropzonejs_obj.add_custom_file(file, file_object['url'], { status: 'success' });
					}

					// Push to field value
					dropzonejs_obj.input_update();
				}

				ws_this.dropzonejs_processes = 0;

				dropzonejs_obj.on('sending', function(file, xhr, form_data) {

					// NONCE
					form_data.append(ws_form_settings.wsf_nonce_field_name, ws_form_settings.wsf_nonce);
					form_data.append('_wpnonce', ws_form_settings.x_wp_nonce);

					// Form ID
					form_data.append('id', ws_this.form_id);

					// Preview
					form_data.append('preview', ws_this.form_canvas_obj[0].hasAttribute('data-preview'));
				});

				dropzonejs_obj.on('success', function(file, response, action) {

					if(
						(typeof(response.error) !== 'undefined') &&
						(response.error === false)
					) {

						this.options.success(file);

						if(
							(typeof(response.attachment_ids) === 'object') &&
							(response.attachment_ids.length > 0)
						) {

							// Get existing attachment ids
							try {

								var field_val = JSON.parse(field_obj.val());
								var attachment_ids = field_val.attachment_ids;

							} catch(e) {

								var attachment_ids = {};
							}

							// Check to see if the UUID is already assigned
							var next_attachment_id = false;

							for(var response_attachment_ids_index in response.attachment_ids) {

								if(!response.attachment_ids.hasOwnProperty(response_attachment_ids_index)) { continue; }

								var response_attachment_id = response.attachment_ids[response_attachment_ids_index];

								if(Object.values(attachment_ids).indexOf(response_attachment_id) === -1) {

									next_attachment_id = response_attachment_id;
									break;
								}
							}

							if(next_attachment_id === false) { return; }

							// Save attachment ID to file
							file.upload.attachment_id = next_attachment_id;
						}

						// Push to field value
						this.input_update();

					} else {

						this.options.error(file, response.error_message ? response.error_message : ws_this.language('error_file_upload'));
					}
				});

				dropzonejs_obj.on('processing', function() {

					ws_this.form_post_lock('progress', true, true);
				});

				dropzonejs_obj.on('totaluploadprogress', function(progress) {

					progress_objs.each(function() {

						ws_this.form_progress_set_value($(this), Math.round(progress));
					});

					if(progress > 99) {

						$('.wsf-progress', $(this.element)).addClass('wsf-progress-success');
					}
				});

				dropzonejs_obj.on('complete', function() { this.ajax_complete(); });

				dropzonejs_obj.on('canceled', function() { this.ajax_complete(); });

				dropzonejs_obj.on('removedfile', function(file) {

					// Push to field value
					this.input_update();

					this.ajax_complete();
				});

				// Check if section is disabled
				var disabled = field_obj.attr('disabled');
				if(!disabled) {

					disabled = disabled || $(this).closest('fieldset').attr('disabled');
				}

				if(disabled) {

					dropzonejs_obj.disable();
				}

				// Flag so it only initializes once
				$(this).attr('data-init-file', '');
			});
		}
	}

	$.WS_Form.prototype.form_file_preview = function(files, obj_file_preview, orientation_row_class, orientation_row_style, orientation_el_style) {

		// Reset
		var file_preview_html = '';
		var files_processed = 0;
		var file_readers = [];
		var file_div_pre = '<div' + ((orientation_row_class != '') ? ' class="' + orientation_row_class + '"' : '') + ((orientation_row_style != '') ? ' style="' + orientation_row_style + '"' : '') + '>';

		// Write fresh wrapper
		obj_file_preview.html('');

		// Process each file
		var preview_count = 0;
		for(var file_index in files) {

			if(!files.hasOwnProperty(file_index)) { continue; }

			var file = files[file_index];

			switch(file.type) {

				// Process file as an image
				case 'image/apng' :
				case 'image/bmp' :
				case 'image/gif' :
				case 'image/jpeg' :
				case 'image/png' :
				case 'image/svg+xml' :
				case 'image/tiff' :
				case 'image/webp' :
				case 'image/x-icon' :

					file_readers[file_index] = new FileReader();
					file_readers[file_index].wsf_file_index = file_index;

					file_readers[file_index].onload = function (e) {

						// Get file index
						var file_index = this.wsf_file_index;

						// Get img src
						var img_src = e.target.result;

						// Get file parameters
						var file = files[file_index];
						var img_alt = file.name;

						// Build image
						var img = $('<img />');
						img.attr('src', img_src);
						img.attr('alt', img_alt);
						img.attr('title', img_alt);
						img.attr('style', orientation_el_style);

						// Add this to the file preview HTML
						obj_file_preview.append(file_div_pre + img[0].outerHTML + '</div>');
					}
					file_readers[file_index].readAsDataURL(file);
					break;

				// Process file as a video
				case 'video/avi' :
				case 'video/mp4' :
				case 'video/ogg' :
				case 'video/ogm' :
				case 'video/ogv' :
				case 'video/webm' :

					var video_src = URL.createObjectURL(file);

					// Build video
					var video = $('<video controls />');
					video.attr('src', video_src);
					video.attr('style', orientation_el_style);
					video.html(this.language('error_not_supported_video'));

					// Add this to the file preview HTML
					obj_file_preview.append(file_div_pre + video[0].outerHTML + '</div>');

					break;

				// Process file as audio
				case 'audio/aac' :
				case 'audio/aacp' :
				case 'audio/flac' :
				case 'audio/mp4' :
				case 'audio/mpeg' :
				case 'audio/ogg' :
				case 'audio/wav' :
				case 'audio/webm' :

					var audio_src = URL.createObjectURL(file);

					// Build audio
					var audio = $('<audio controls />');
					audio.attr('src', audio_src);
					audio.attr('style', orientation_el_style + ' height: 40px;');
					audio.html(this.language('error_not_supported_audio'));

					// Add this to the file preview HTML
					obj_file_preview.append(file_div_pre + audio[0].outerHTML + '</div>');

					break;
			}
		}
	}

	// Get file count
	$.WS_Form.prototype.file_get_count_by_field_id = function(field_id) {

		var field_obj = $('#' + this.form_id_prefix + 'field-' + field_id, this.form_canvas_obj);

		var files = false;

		// Check for DropzoneJS
		if(
			field_obj.attr('data-file-type') &&
			(field_obj.attr('data-file-type') === 'dropzonejs')
		) {

			// DropzoneJS
			var obj_wrapper = field_obj.closest('[data-type="file"]');

			if(obj_wrapper) {

				var dropzone = $('.dropzone', obj_wrapper)[0].dropzone;

				if(dropzone.files) {

					files = dropzone.files;
				}
			}

		} else {

			// Default
			files = field_obj.length ? field_obj[0].files : false;
		}

		var file_count = (files !== false) ? files.length : 0;

		return file_count;
	}

	// Form navigation
	$.WS_Form.prototype.form_navigation = function() {

		var ws_this = this;

		var group_count = $('.wsf-group-tabs', this.form_canvas_obj).children(':not([data-wsf-group-hidden])').length;

		// Buttons - Next
		$('[data-action="wsf-tab_next"]', this.form_canvas_obj).each(function() {

			// Remove existing click event
			$(this).off('click');

			// Get next group
			var group_next = $(this).closest('[data-group-index]').nextAll(':not([data-wsf-group-hidden])').first();

			// If there are no tabs, or no next tab, disable the next button
			if(
				(group_count <= 1) ||
				(!group_next.length)
			) {
				$(this).attr('disabled', '').attr('data-wsf-disabled', '');

			} else {

				if(typeof($(this).attr('data-wsf-disabled')) !== 'undefined') { $(this).removeAttr('disabled').removeAttr('data-wsf-disabled'); }
			}

			// If button is disabled, then don't initialize
			if(typeof($(this).attr('disabled')) !== 'undefined') { return; }

			// Add click event
			$(this).on('click', function() {

				ws_this.group_index_new($(this), group_next.attr('data-group-index'));
			});
		});

		// Buttons - Previous
		$('[data-action="wsf-tab_previous"]', this.form_canvas_obj).each(function() {

			// Remove existing click event
			$(this).off('click');

			// Get previous group
			var group_previous = $(this).closest('[data-group-index]').prevAll(':not([data-wsf-group-hidden])').first();

			// If there are no tabs, or no previous tab, disable the previous button
			if(
				(group_count <= 1) ||
				(!group_previous.length)
			) {
				$(this).attr('disabled', '').attr('data-wsf-disabled', '');

			} else {

				if(typeof($(this).attr('data-wsf-disabled')) !== 'undefined') { $(this).removeAttr('disabled').removeAttr('data-wsf-disabled'); }
			}

			// If button is disabled, then don't initialize
			if(typeof($(this).attr('disabled')) !== 'undefined') { return; }

			// Add click event
			$(this).on('click', function() {

				ws_this.group_index_new($(this), group_previous.attr('data-group-index'));
			});
		});

		// Buttons - Save
		this.form_canvas_obj.off('click', '[data-action="wsf-save"]').on('click', '[data-action="wsf-save"]', function() {

			// Get field
			var field = ws_this.get_field($(this));

			if(typeof(field) !== 'undefined') {

				var validate_form = ws_this.get_object_meta_value(field, 'validate_form', '');

				if(validate_form) {

					ws_this.form_post_if_validated('save');

				} else {

					ws_this.form_post('save');
				}
			}
		});

		// Buttons - Reset
		this.form_canvas_obj.off('click', '[data-action="wsf-reset"]').on('click', '[data-action="wsf-reset"]', function(e) {

			// Prevent default
			e.preventDefault();

			ws_this.form_reset();
		});

		// Buttons - Clear
		this.form_canvas_obj.off('click', '[data-action="wsf-clear"]').on('click', '[data-action="wsf-clear"]', function() {

			ws_this.form_clear();
		});
	}

	// Tab - Activate by offset amount
	$.WS_Form.prototype.group_index_new = function(obj, group_index_new) {

		// Activate tab
		this.group_index_set(group_index_new);

		// Get field ID
		var field_id = obj.closest('[data-id]').attr('data-id');
		var field = this.field_data_cache[field_id];
		var scroll_to_top = this.get_object_meta_value(field, 'scroll_to_top', '');
		var scroll_to_top_offset = this.get_object_meta_value(field, 'scroll_to_top_offset', '0');
		scroll_to_top_offset = (scroll_to_top_offset == '') ? 0 : parseInt(scroll_to_top_offset, 10);
		var scroll_position = this.form_canvas_obj.offset().top - scroll_to_top_offset;

		switch(scroll_to_top) {

			// Instant
			case 'instant' :

				$('html,body').scrollTop(scroll_position);

				break;

			// Smooth
			case 'smooth' :

				var scroll_to_top_duration = this.get_object_meta_value(field, 'scroll_to_top_duration', '0');
				scroll_to_top_duration = (scroll_to_top_duration == '') ? 0 : parseInt(scroll_to_top_duration, 10);

				$('html,body').animate({

					scrollTop: scroll_position

				}, scroll_to_top_duration);

				break;
		}
	}

	// Tab - Set
	$.WS_Form.prototype.group_index_set = function(group_index) {

		if(this.form.groups.length <= 1) { return false; }

		var framework_tabs = this.framework['tabs']['public'];

		if(typeof(framework_tabs.activate_js) !== 'undefined') {

			var activate_js = framework_tabs.activate_js;	

			if(activate_js != '') {

				// Parse activate_js
				var mask_values = {'form': '#' + this.form_obj_id, 'index': group_index};
				var activate_js_parsed = this.mask_parse(activate_js, mask_values);

				// Execute activate tab javascript
				$.globalEval('(function($) { $(function() {' + activate_js_parsed + '}); })(jQuery);');

				// Set cookie
				this.cookie_set('tab_index', group_index);
			}
		}

		// Progress by tabs
		this.form_progress_tabs(group_index);

		// Log
		this.log('log_group_index', group_index);
	}

	// Get tab index object resides in
	$.WS_Form.prototype.get_group_index = function(obj) {

		var group_count = $('.wsf-tabs', this.form_canvas_obj).children(':visible').length;
		if(group_count <= 1) { return false; }

		// Get group
		var group_single = obj.closest('[data-group-index]');
		if(group_single.length == 0) { return false; }

		// Get group index
		var group_index = group_single.first().attr('data-group-index');
		if(group_index == undefined) { return false; }

		return parseInt(group_index, 10);
	}

	// Get section id from object
	$.WS_Form.prototype.get_section_id = function(obj) {

		var section_id = obj.closest('[id^="' + this.form_id_prefix + 'section-"]').attr('data-id');

		return (typeof(section_id) !== 'undefined') ? parseInt(section_id, 10) : false;
	}

	// Get section repeatable index from object
	$.WS_Form.prototype.get_section_repeatable_index = function(obj) {

		var section_repeatable_index = obj.closest('[id^="' + this.form_id_prefix + 'section-"]').attr('data-repeatable-index');

		return (section_repeatable_index > 0) ? parseInt(section_repeatable_index, 10) : 0;
	}

	// Get section repeatable suffix from object
	$.WS_Form.prototype.get_section_repeatable_suffix = function(obj) {

		var section_repeatable_index = this.get_section_repeatable_index(obj);

		return section_repeatable_index ? '-repeat-' + section_repeatable_index : '';
	}

	// Get field from obj
	$.WS_Form.prototype.get_field = function(obj) {

		var field_id = this.get_field_id(obj);

		return field_id ? this.field_data_cache[field_id] : false;
	}

	// Get field wrapper from object
	$.WS_Form.prototype.get_field_wrapper = function(obj) {

		return obj.closest('[data-id]')
	}

	// Get field id from object
	$.WS_Form.prototype.get_field_id = function(obj) {

		var field_id = obj.closest('[data-type]').attr('data-id');

		return (typeof(field_id) !== 'undefined') ? parseInt(field_id, 10) : false;
	}

	// Get field type from object
	$.WS_Form.prototype.get_field_type = function(obj) {

		var field_type = obj.closest('[data-type]').attr('data-type');

		return (typeof(field_type) !== 'undefined') ? field_type : false;
	}

	// Get help from object
	$.WS_Form.prototype.get_help_obj = function(obj) {

		var field_id = this.get_field_id(obj);
		var section_repeatable_suffix = this.get_section_repeatable_suffix(obj);

		return $('#' + this.form_id_prefix + 'help-' + field_id + section_repeatable_suffix, this.form_canvas_obj);
	}


	// Get invalid feedback from object
	$.WS_Form.prototype.get_invalid_feedback_obj = function(obj) {

		var field_id = this.get_field_id(obj);
		var section_repeatable_suffix = this.get_section_repeatable_suffix(obj);

		return $('#' + this.form_id_prefix + 'invalid-feedback-' + field_id + section_repeatable_suffix, this.form_canvas_obj);
	}

	// Set invalid feedback on object
	$.WS_Form.prototype.set_invalid_feedback = function(obj, message, object_row_id) {

		// Check for object row
		if(typeof(object_row_id) === 'undefined') { object_row_id = 0; }

		// Get invalid feedback obj
		var invalid_feedback_obj = this.get_invalid_feedback_obj(obj);

		// Get section ID
		var section_id = this.get_section_id(obj);

		// Get section repeatable index
		var section_repeatable_index = this.get_section_repeatable_index(obj);

		// Get field ID
		var field_id = this.get_field_id(obj);

		// Check for false message
		if(message === false) { message = invalid_feedback_obj.html(); }

		// HTML 5 custom validity
		if(obj.length && obj[0].willValidate) {

			if(message !== '') {

				// Store message
				if(typeof(this.validation_message_cache[section_id]) === 'undefined') { this.validation_message_cache[section_id] = []; }
				if(typeof(this.validation_message_cache[section_id][section_repeatable_index]) === 'undefined') { this.validation_message_cache[section_id][section_repeatable_index] = []; }
				if(typeof(this.validation_message_cache[section_id][section_repeatable_index][field_id]) === 'undefined') { this.validation_message_cache[section_id][section_repeatable_index][field_id] = []; }

				this.validation_message_cache[section_id][section_repeatable_index][field_id][object_row_id] = message;

			} else {

				// Recall message
				if(
					(typeof(this.validation_message_cache[section_id]) !== 'undefined') &&
					(typeof(this.validation_message_cache[section_id][section_repeatable_index]) !== 'undefined') &&
					(typeof(this.validation_message_cache[section_id][section_repeatable_index][field_id]) !== 'undefined') &&
					(typeof(this.validation_message_cache[section_id][section_repeatable_index][field_id][object_row_id]) !== 'undefined')
				) {

					delete this.validation_message_cache[section_id][section_repeatable_index][field_id][object_row_id];
				}
			}

			// Set custom validity
			obj[0].setCustomValidity(message);
		}

		// Invalid feedback text
		if(invalid_feedback_obj.length) {

			if(message !== '') {

				// Store invalid feedback
				if(typeof(this.invalid_feedback_cache[section_id]) === 'undefined') { this.invalid_feedback_cache[section_id] = []; }
				if(typeof(this.invalid_feedback_cache[section_id][section_repeatable_index]) === 'undefined') { this.invalid_feedback_cache[section_id][section_repeatable_index] = []; }
				if(typeof(this.invalid_feedback_cache[section_id][section_repeatable_index][field_id]) === 'undefined') { this.invalid_feedback_cache[section_id][section_repeatable_index][field_id] = []; }

				this.invalid_feedback_cache[section_id][section_repeatable_index][field_id][object_row_id] = invalid_feedback_obj.html();

				// Set invalid feedback
				invalid_feedback_obj.html(message);

			} else {

				// Recall invalid feedback
				if(
					(typeof(this.invalid_feedback_cache[section_id]) !== 'undefined') &&
					(typeof(this.invalid_feedback_cache[section_id][section_repeatable_index]) !== 'undefined') &&
					(typeof(this.invalid_feedback_cache[section_id][section_repeatable_index][field_id]) !== 'undefined') &&
					(typeof(this.invalid_feedback_cache[section_id][section_repeatable_index][field_id][object_row_id]) !== 'undefined')
				) {

					invalid_feedback_obj.html(this.invalid_feedback_cache[section_id][section_repeatable_index][field_id][object_row_id]);
				}
			}
		}
	}
	// Form tracking
	$.WS_Form.prototype.form_tracking = function() {

		for(var tracking_id in $.WS_Form.tracking) {

			if(!$.WS_Form.tracking.hasOwnProperty(tracking_id)) { continue; }

			var tracking_config = $.WS_Form.tracking[tracking_id];	

			// Check this tracking method is enabled
			if(!this.get_object_meta_value(this.form, tracking_id, false)) { continue; }

			// Get client source
			if(typeof(tracking_config['client_source']) === 'undefined') { continue; }
			var client_source = tracking_config['client_source'];

			// Get server query var
			if(typeof(tracking_config['server_query_var']) === 'undefined') { continue; }
			var server_query_var = tracking_config['server_query_var'];

			var tracking_value = '';

			switch(client_source) {

				case 'query_var' :

					// Get client query var
					if(typeof(tracking_config['client_query_var']) === 'undefined') { break; }
					var client_query_var = tracking_config['client_query_var'];

					// Read query var value
					tracking_value = this.get_query_var(client_query_var);

					break;

				case 'referrer' :

					// Get document referrer
					tracking_value = (typeof(document.referrer) !== 'undefined') ? document.referrer : '';
					break;

				case 'pathname' :

					// Get location pathname
					tracking_value = (typeof(location.pathname) !== 'undefined') ? location.pathname : '';
					break;

				case 'query_string' :

					// Get location query string (search)
					tracking_value = (typeof(location.search) !== 'undefined') ? location.search : '';
					break;

				case 'os' :

					// Get window.navigator operating system
					if(typeof(window.navigator) === 'undefined') { break; }
					tracking_value = (typeof(window.navigator.platform) !== 'undefined') ? window.navigator.platform : '';
					break;

				case 'geo_location' :

					// Does browser support geolocation?
				    if(!navigator.geolocation) { break; }

				    // Get geo location
					var ws_this = this;

			        navigator.geolocation.getCurrentPosition(function(position) {

					    var tracking_geo_location = position.coords.latitude + ',' + position.coords.longitude;

					    // Set hidden value
					    ws_this.form_geo_location_process(tracking_geo_location);

						// Debug
						ws_this.log('log_tracking_geo_location', tracking_geo_location, 'tracking');

					}, function showError(error) {

					    // Set hidden value
					    ws_this.form_geo_location_process(error.code);

						// Debug
						ws_this.error('error_tracking_geo_location', ($.WS_Form.debug_rendered ? ws_this.form_geo_location_get_error(error) : ''), 'tracking');
					});

					continue;
			}

			// Add to form
			this.form_add_hidden_input(server_query_var, this.html_encode(tracking_value));
		}
	}

	// Form geo location - Process
	$.WS_Form.prototype.form_geo_location_process = function(tracking_geo_location) {

		// Add to form
		this.form_add_hidden_input('wsf_geo_location', tracking_geo_location);
	}

	// Form geo location - Process
	$.WS_Form.prototype.form_geo_location_get_error = function(error) {

		switch(error.code) {

			case error.PERMISSION_DENIED:

				return this.language('debug_tracking_geo_location_permission_denied');

			case error.POSITION_UNAVAILABLE:

				return this.language('debug_tracking_geo_location_position_unavailable');

			case error.TIMEOUT:

				return this.language('debug_tracking_geo_location_timeout');

			default:

				return this.language('debug_tracking_geo_location_default');
		}
	}

	// Form preview
	$.WS_Form.prototype.form_preview = function() {

		if(this.form_canvas_obj[0].hasAttribute('data-preview')) {

			this.form_add_hidden_input('wsf_preview', 'true');
		}
	}

	// Form spam protection
	$.WS_Form.prototype.form_spam_protection = function() {

		// Honeypot
		var honeypot = this.get_object_meta_value(this.form, 'honeypot', false);

		if(honeypot) {

			// Add honeypot field
			var honeypot_hash = (this.form.published_checksum != '') ? this.form.published_checksum : ('honeypot_unpublished_' + this.form_id);

			// Build honeypot input
			var framework_type = $.WS_Form.settings_plugin.framework;
			var framework = $.WS_Form.frameworks.types[framework_type];
			var fields = this.framework['fields']['public'];
			var honeypot_attributes = (typeof(fields.honeypot_attributes) !== 'undefined') ? ' ' + fields.honeypot_attributes.join(' ') : '';

			// Add to form
			this.form_add_hidden_input('field_' + honeypot_hash, '', false, 'autocomplete="off"' + honeypot_attributes);

			// Hide it
			var honeypot_obj = $('[name="field_' + honeypot_hash + '"]', this.form_canvas_obj);
			honeypot_obj.css({'position': 'absolute', 'left': '-9999em'});

			// Debug
			this.log('log_honeypot', '', 'spam-protect');
		}
	}

	// Form analytics
	$.WS_Form.prototype.form_analytics = function() {

		var ws_this = this;

		// Google Analytics
		var analytics_google = this.get_object_meta_value(this.form, 'analytics_google', false);

		// Check to see if Google Analytics is installed
		if(analytics_google) { this.form_analytics_google(); }
	}

	// Form analytics - Google
	$.WS_Form.prototype.form_analytics_google = function(total_ms_start) {

		var ws_this = this;
		var analytics_google_functions = $.WS_Form.analytics.google.functions;

		// Timeout check
		if(typeof(total_ms_start) === 'undefined') { total_ms_start = new Date().getTime(); }
		if((new Date().getTime() - total_ms_start) > this.timeout_analytics_google) {

			this.error('error_timeout_analytics_google', '', 'analytics');
			return false;
		}

		// Run through Google functions
		var analytics_google_function_found = false;
		for(var analytics_google_function in analytics_google_functions) {

			if(!analytics_google_functions.hasOwnProperty(analytics_google_function)) { continue; }

			var analytics_google_function_config = analytics_google_functions[analytics_google_function];

			// Check to see if the window function is available
			if(window[analytics_google_function]) {

				// Found
				analytics_google_function_found = true;

				// Log
				this.log(analytics_google_function_config.log_found, '', 'analytics');

				// Get Google configuration
				var process_fields = this.get_object_meta_value(this.form, 'analytics_google_event_field', false);
				var process_tabs = this.get_object_meta_value(this.form, 'analytics_google_event_tab', false);

				// Process
				this.form_analytics_process('google', analytics_google_function, process_fields, process_tabs);

				// Save which function should be used for future event firing
				this.analytics_function['google'] = analytics_google_function;

				break;
			}
		}

		// Not found, retry
		if(!analytics_google_function_found) {

			setTimeout(function() { ws_this.form_analytics_google(total_ms_start); }, this.timeout_interval);
		}
	}

	// Form analytics - Process
	$.WS_Form.prototype.form_analytics_process = function(type, type_function, process_fields, process_tabs) {

		// Fields
		if(process_fields) { this.form_analytics_process_fields(type, type_function); }

		// Tabs
		if(process_tabs && (this.form.groups.length > 0)) { this.form_analytics_process_tabs(type, type_function); }
	}

	// Form analytics - Process - Tabs
	$.WS_Form.prototype.form_analytics_process_tabs = function(type, type_function) {

		var ws_this = this;

		// Run through all tabs and set up analytics events for this type and function
		var analytics_function = $.WS_Form.analytics[type].functions[type_function];
		var analytics_label = $.WS_Form.analytics[type].label;
		var analytics_function_label = analytics_function.label;

		// Get selector href
		var selector_href = (typeof(this.framework.tabs.public.selector_href) !== 'undefined') ? this.framework.tabs.public.selector_href : 'href';

		// Set up on click event for each tab
		$('[' + selector_href + '^="#' + this.form_id_prefix + 'group-"]:not([data-init-analytics-tab])', this.form_canvas_obj).each(function() {

			$(this).attr('data-init-analytics-tab', '');

			$(this).on('wsf-click', function () {

				var group_index = $(this).parent().index();

				if($(this).attr('data-analytics-event-fired') === undefined) {

					var group = ws_this.form.groups[group_index];

					// Parse values
					var parse_values = {

						'action':	ws_this.js_string_encode(ws_this.form.label),	// Action
						'category': 'Tab',											// Category
						'label':	ws_this.js_string_encode(group.label),			// Label
					};

					// Fire event
					ws_this.form_analytics_event_fire(

						type,
						type_function,
						parse_values
					);

					$(this).attr('data-analytics-event-fired', 'true');
				}
			});
		});

		// Log event
		ws_this.log('log_analytics_event_tab', analytics_label + ' (' + analytics_function_label + ')', 'analytics');
	}

	// Form analytics - Process - Fields
	$.WS_Form.prototype.form_analytics_process_fields = function(type, type_function) {

		var ws_this = this;

		// Run through all fields and set up analytics events for this type and function
		var analytics_function = $.WS_Form.analytics[type].functions[type_function];
		var analytics_label = $.WS_Form.analytics[type].label;
		var analytics_function_label = analytics_function.label;

		for(var field_index in this.field_data_cache) {

			if(!this.field_data_cache.hasOwnProperty(field_index)) { continue; }

			var field_type = this.field_data_cache[field_index].type;
			var field_type_config = $.WS_Form.field_type_cache[field_type];

			// Get events
			if(typeof(field_type_config.events) === 'undefined') { continue; }
			var analytics_event = field_type_config.events.event;

			// Get field ID
			var field_id = this.field_data_cache[field_index].id;

			// Check to see if this field is submitted as an array
			var submit_array = (typeof(field_type_config.submit_array) !== 'undefined') ? field_type_config.submit_array : false;

			// Check to see if field is in a repeatable section
			var field_wrapper = $('[data-type][data-id="' + field_id + '"]', this.form_canvas_obj);

			// Run through each wrapper found (there might be repeatables)
			field_wrapper.each(function() {

				var section_repeatable_index = ws_this.get_section_repeatable_index($(this));
				var section_repeatable_suffix = (section_repeatable_index > 0) ? '[' + section_repeatable_index + ']' : '';

				if(submit_array) {

					var field_obj = $('[name="' + ws_form_settings.field_prefix + field_id + section_repeatable_suffix + '[]"]:not([data-init-analytics-field])', ws_this.form_canvas_obj);

				} else {

					var field_obj = $('[name="' + ws_form_settings.field_prefix + field_id + section_repeatable_suffix + '"]:not([data-init-analytics-field])', ws_this.form_canvas_obj);
				}

				if(field_obj.length) {

					// Flag so it only initializes once
					field_obj.attr('data-init-analytics-field', '');

					// Create event
					field_obj.on(analytics_event, function() {

						if($(this).attr('data-analytics-event-fired') === undefined) {

							var field = ws_this.get_field($(this));
							var analytics_event_category = $.WS_Form.field_type_cache[field.type].events.event_category;

							// Parse values
							var parse_values = {

								'action':	ws_this.js_string_encode(ws_this.form.label),	// Action
								'category': analytics_event_category,						// Category
								'label':	ws_this.js_string_encode(field.label)			// Label
							}

							// Fire event
							ws_this.form_analytics_event_fire(

								type,
								type_function,
								parse_values
							);

							$(this).attr('data-analytics-event-fired', 'true');
						}
					});
				}
			});
		}

		// Log event
		ws_this.log('log_analytics_event_field', analytics_label + ' (' + analytics_function_label + ')', 'analytics');
	}

	// Form analytics - Fire event
	$.WS_Form.prototype.form_analytics_event_fire = function(type, type_function, parse_values) {

		// Run through all fields and set up analytics events for this type and function
		var analytics_function = $.WS_Form.analytics[type].functions[type_function];
		var analytics_label = $.WS_Form.analytics[type].label;
		var analytics_function_label = $.WS_Form.analytics[type].functions[type_function].label;

		// Parse event field args
		var analytics_event_function = atob(analytics_function.analytics_event_function);
		var analytics_event_function_parsed = this.mask_parse(analytics_event_function, parse_values);

		// Call function
		if((type_function == 'js') || (typeof(window[type_function]) === 'function')) {

			$.globalEval('(function($) {' + analytics_event_function_parsed + '})(jQuery);');

			// Log event
			this.log('log_analytics_event_field_fired', analytics_label + ' (' + analytics_function_label + ') ' + analytics_event_function_parsed, 'analytics');

		} else {

			// Log error
			this.error('log_analytics_event_field_failed', analytics_label + ' (' + analytics_function_label + ') ' + analytics_event_function_parsed, 'analytics');
		}
	}

	// Text area
	$.WS_Form.prototype.form_textarea = function() {

		var ws_this = this;

		// Text Editor
		$('[data-textarea-type="tinymce"]', this.form_canvas_obj).each(function() {

			if(typeof(wp) === 'undefined') { return; }
			if(typeof(wp.editor) === 'undefined') { return; }
			if(typeof(wp.editor.remove) === 'undefined') { return; }
			if(typeof(wp.editor.initialize) === 'undefined') { return; }

			var id = $(this).attr('id');
			var toolbar = $(this).attr('data-textarea-toolbar');

			switch(toolbar) {

				case 'compact' :

					var wp_editor_params = { 

						tinymce: { 

							toolbar1: ws_form_settings.tinymce_toolbar1_compact,
							toolbar2: ws_form_settings.tinymce_toolbar2_compact,
							toolbar3: ws_form_settings.tinymce_toolbar3_compact,
							toolbar4: ws_form_settings.tinymce_toolbar4_compact,
							plugins: ws_form_settings.tinymce_plugins_compact
						}
					}

					break;

				default :

					var wp_editor_params = { 

						tinymce: { 

							toolbar1: ws_form_settings.tinymce_toolbar1_full,
							toolbar2: ws_form_settings.tinymce_toolbar2_full,
							toolbar3: ws_form_settings.tinymce_toolbar3_full,
							toolbar4: ws_form_settings.tinymce_toolbar4_full,
							plugins: ws_form_settings.tinymce_plugins_full
						}
					}
			}

			// Standard features
			wp_editor_params.quicktags = true;
			wp_editor_params.tinymce.wpautop = true;

			wp_editor_params.tinymce.init_instance_callback = function (editor) {

				editor.on('keyup change input paste', function (e) {

					$('#' + editor.id, ws_this.form_canvas_obj).val(wp.editor.getContent(editor.id)).trigger(e.type);
				});

				var textarea_obj = $('#' + editor.id, ws_this.form_canvas_obj);
				var invalid_feedback_obj = ws_this.get_invalid_feedback_obj(textarea_obj);
				invalid_feedback_obj.before(textarea_obj.detach());
			};

			// Initialize
			wp.editor.remove(id);
			wp.editor.initialize(id, wp_editor_params);
		})

		// Code Editor
		$('[data-textarea-type="html"]', this.form_canvas_obj).each(function() {

			if(typeof(wp) === 'undefined') { return; }
			if(typeof(wp.codeEditor) === 'undefined') { return; }

			var id = $(this).attr('id');

			// Remove existing instances of CodeMiror
			$('.CodeMirror', ws_this.form_canvas_obj).each(function() {

				$(this).remove();
			});

			// Initialize
			wp.codeEditor.initialize(id);

			// Handle keyup events
			$('.CodeMirror', ws_this.form_canvas_obj).each(function() {

				var code_editor = $(this)[0].CodeMirror;
				code_editor.on("keyup", function (cm, event) {

					var code_editor_value = cm.getValue();
					var code_editor_textarea = cm.getTextArea();
					$(code_editor_textarea, ws_this.form_canvas_obj).val(code_editor_value).trigger('keyup');
				});
			});
		});
	}

	// Text editor set value
	$.WS_Form.prototype.textarea_set_value = function(obj, value) {

		obj.filter('textarea').each(function() {

			var textarea_type = (typeof($(this).attr('data-textarea-type')) !== 'undefined') ? $(this).attr('data-textarea-type') : false;
			if(textarea_type !== false) {

				var populate_id = $(this).attr('id');

				switch(textarea_type) {

					case 'tinymce' :

						if(typeof(wp) === 'undefined') { break; }
						if(typeof(wp.editor) === 'undefined') { break; }
						var active_editor = tinyMCE.get(populate_id);
						active_editor.setContent(value);
						break;

					case 'html' :

						if(typeof(wp) === 'undefined') { break; }
						if(typeof(wp.CodeMirror) === 'undefined') { break; }
						var active_editor = $(this).next().get(0).CodeMirror;
						active_editor.getDoc().setValue(value);
						break;
				}
			}
		});
	}

	// Dedupe values by repeatable section
	$.WS_Form.prototype.form_dedupe_value_scope = function() {

		var ws_this = this;

		$('[data-value-scope]:not([data-init-value-scope])', this.form_canvas_obj).each(function() {

			// Check this field is in a repeatable section
			if(!$(this).closest('[data-repeatable]')) { return; }

			// Process
			ws_this.form_dedupe_value_scope_process($(this), true);

			$(this).on('change', function() {

				// Process
				ws_this.form_dedupe_value_scope_process($(this), false);
			});

			// Add init attribute so it does not initialize again
			$(this).attr('data-init-value-scope', '');
		})
	}

	$.WS_Form.prototype.form_dedupe_value_scope_process_all = function() {

		var ws_this = this;

		$('[data-value-scope]', this.form_canvas_obj).each(function() {

			// Check this field is in a repeatable section
			if(!$(this).closest('[data-repeatable]')) { return; }

			// Process
			ws_this.form_dedupe_value_scope_process($(this), false);
		})
	}

	$.WS_Form.prototype.form_dedupe_value_scope_process = function(obj, initial) {

		var ws_this = this;

		// Get field id
		var field_id = this.get_field_id(obj);

		// Get field type
		var field_type = this.get_field_type(obj);

		switch(field_type) {

			case 'select' :
			case 'price_select' :

				if(!initial) {

					$('[name^="' + ws_form_settings.field_prefix + field_id + '["] option[data-dedupe]', this.form_canvas_obj).removeAttr('data-dedupe').removeAttr('disabled');
				}

				$('[name^="' + ws_form_settings.field_prefix + field_id + '["]', this.form_canvas_obj).each(function() {

					// Get section ID
					var section_id = this.get_section_id($(this));

					// Get section repeatable index
					var section_repeatable_index = this.get_section_repeatable_index($(this));

					var values = $(this).val();
					if(typeof(values) !== 'object') { values = [values]; }

					for(var value_index in values) {

						if(!values.hasOwnProperty(value_index)) { continue; }

						var value = values[value_index];

						if(value === '') { continue; }

						// Run through each repeatable section that does not match this section
						$('[id^="' + ws_this.form_id_prefix + 'section-' + section_id + '-"]:not([data-repeatable-index="' + section_repeatable_index + '"])').each(function() {

							var field_matching_obj = $('[name^="' + ws_form_settings.field_prefix + field_id + '["]', $(this));

							$('option[value="' + value + '"]:not([data-dedupe])', field_matching_obj).prop('selected', false).attr('disabled', '').attr('data-dedupe', '');
						});
					}
				});

				break;

			case 'checkbox' :
			case 'radio' :
			case 'price_checkbox' :
			case 'price_radio' :

				if(!initial) {

					$('[name^="' + ws_form_settings.field_prefix + field_id + '["][data-dedupe]', this.form_canvas_obj).removeAttr('data-dedupe').removeAttr('disabled');
				}

				$('[name^="' + ws_form_settings.field_prefix + field_id + '["]:checked', this.form_canvas_obj).each(function() {

					// Re-check if checked (Because it might have been unchecked below)
					if(!$(this).is(':checked')) { return; }

					// Get section ID
					var section_id = this.get_section_id($(this));

					// Get section repeatable index
					var section_repeatable_index = this.get_section_repeatable_index($(this));

					// Get field type
					var value = $(this).attr('value');

					// Run through each repeatable section that does not match this section
					$('[id^="' + ws_this.form_id_prefix + 'section-' + section_id + '-"]:not([data-repeatable-index="' + section_repeatable_index + '"])').each(function() {

						var field_matching_obj = $('[name^="' + ws_form_settings.field_prefix + field_id + '["][value="' + value + '"]', $(this));

						field_matching_obj.prop('checked', false).attr('disabled', '').attr('data-dedupe', '');
					});
				});

				break;
		}
	}

	// Form - Initialize all repeatable sections
	$.WS_Form.prototype.form_section_repeatable = function() {

		var ws_this = this;

		// Get array of each section [section_id]=count
		var section_id_repeatable_array = this.get_section_id_repeatable_array();

		// Process each section
		for(var section_id in section_id_repeatable_array) {

			if(!section_id_repeatable_array.hasOwnProperty(section_id)) { continue; }

			// Get section data
			var section = this.section_data_cache[section_id];

			// Get section count
			var section_count = section_id_repeatable_array[section_id];

			// Get section repeat min
			var section_repeat_min = this.get_section_repeat_min(section);

			// Get section repeat max
			var section_repeat_max = this.get_section_repeat_max(section, section_repeat_min);

			// Get section repeat default
			var section_repeat_default = this.get_section_repeat_default(section, section_repeat_min, section_repeat_max);

			for(var section_clone_index = 0; section_clone_index < (section_repeat_default - section_count); section_clone_index++) {

				// Get section obj to clone
				var section_clone_this = $('[data-repeatable][data-id="' + section_id + '"]', this.form_canvas_obj).last();

				// Clone
				this.section_clone(section_clone_this);
			}

			// Navigation - Render
			this.section_repeatable_navigation_render(section_id);

			// Navigation - Events
			this.section_repeatable_navigation_events(section_id);

			// Navigation - Enable / Disable
			this.section_repeatable_navigation_enable_disable(section_id);

			// Labels
			this.section_repeatable_labels(section_id);

			// Trigger event
			this.form_canvas_obj.trigger('wsf-section-repeatable-' + section_id);
		}

		// Section repeatable hidden field
		this.section_repeatable_hidden_field();

		// Trigger event
		this.form_canvas_obj.trigger('wsf-section-repeatable');
	}

	// Adds section icons
	$.WS_Form.prototype.section_repeatable_navigation_render = function(section_id) {

		var ws_this = this;

		var method_same_section_array = ['move-up', 'move-down', 'drag'];

		var section_obj = $('[data-repeatable][data-id="' + section_id + '"]');

		// Add data-repeatable-section-id to move up, move down and drag buttons
		for(var method_same_section_index in method_same_section_array) {

			if(!method_same_section_array.hasOwnProperty(method_same_section_index)) { continue; }

			var method_same_section = method_same_section_array[method_same_section_index];

			$('[data-action="wsf-section-' + method_same_section + '-button"]:not([data-repeatable-section-id])', section_obj).attr('data-repeatable-section-id', section_id);
		}

		var section_icon_sets = {

			'circle' : {

				'add' : '<path d="M13.7 2.3C12.1.8 10.1 0 8 0S3.9.8 2.3 2.3 0 5.9 0 8s.8 4.1 2.3 5.7S5.9 16 8 16s4.1-.8 5.7-2.3S16 10.1 16 8s-.8-4.1-2.3-5.7zM8 14.8c-3.7 0-6.8-3-6.8-6.8s3-6.8 6.8-6.8 6.8 3 6.8 6.8-3.1 6.8-6.8 6.8zm.6-7.4h2.8v1.2H8.6v2.8H7.4V8.6H4.6V7.4h2.8V4.6h1.2v2.8z"/>',
				'delete' : '<path d="M8 16c-2.1 0-4.1-.8-5.7-2.3S0 10.1 0 8s.8-4.1 2.3-5.7S5.9 0 8 0s4.1.8 5.7 2.3S16 5.9 16 8s-.8 4.1-2.3 5.7S10.1 16 8 16zM8 1.2c-3.7 0-6.8 3-6.8 6.8s3 6.8 6.8 6.8 6.8-3 6.8-6.8S11.7 1.2 8 1.2zm3.4 6.2H4.6v1.2h6.9V7.4z"/>',
				'move-up' : '<path d="M8 16c-2.1 0-4.1-.8-5.7-2.3S0 10.1 0 8s.8-4.1 2.3-5.7S5.9 0 8 0s4.1.8 5.7 2.3S16 5.9 16 8s-.8 4.1-2.3 5.7S10.1 16 8 16zM8 1.2c-3.7 0-6.8 3-6.8 6.8s3 6.8 6.8 6.8 6.8-3 6.8-6.8S11.7 1.2 8 1.2zm4.3 7.9L8 4.7 3.7 9.1l.9.9L8 6.5l3.4 3.4.9-.8z"/>',
				'move-down' : '<path d="M8 0c2.1 0 4.1.8 5.7 2.3S16 5.9 16 8s-.8 4.1-2.3 5.7S10.1 16 8 16s-4.1-.8-5.7-2.3S0 10.1 0 8s.8-4.1 2.3-5.7S5.9 0 8 0zm0 14.8c3.7 0 6.8-3 6.8-6.8s-3-6.8-6.8-6.8S1.2 4.3 1.2 8s3.1 6.8 6.8 6.8zM3.7 6.9L8 11.3 12.3 7l-.9-.9L8 9.5 4.6 6.1l-.9.8z"/>',
				'drag' : '<path d="M8 0c2.1 0 4.1.8 5.7 2.3S16 5.9 16 8s-.8 4.1-2.3 5.7S10.1 16 8 16s-4.1-.8-5.7-2.3S0 10.1 0 8s.8-4.1 2.3-5.7S5.9 0 8 0zm0 14.8c3.7 0 6.8-3 6.8-6.8s-3-6.8-6.8-6.8S1.2 4.3 1.2 8s3.1 6.8 6.8 6.8zm-4-4.7h8v1.3H4v-1.3zm0-2.7h8v1.3H4V7.4zm0-2.8h8v1.3H4V4.6z"/>',
				'reset' : '<path d="M8,0 C10.1,0 12.1,0.8 13.7,2.3 C15.3,3.8 16,5.9 16,8 C16,10.1 15.2,12.1 13.7,13.7 C12.2,15.3 10.1,16 8,16 C5.9,16 3.9,15.2 2.3,13.7 C0.7,12.2 0,10.1 0,8 C0,5.9 0.8,3.9 2.3,2.3 C3.8,0.7 5.9,0 8,0 Z M8,14.8 C11.7,14.8 14.8,11.8 14.8,8 C14.8,4.2 11.8,1.2 8,1.2 C4.2,1.2 1.2,4.3 1.2,8 C1.2,11.7 4.3,14.8 8,14.8 Z M8,4 C6.5,4 5.2,4.8 4.55,6.05 L4,5.5 L4,7.5 L6,7.5 L5.25,6.75 C5.75,5.75 6.8,5 8,5 C9.65,5 11,6.35 11,8 C11,9.65 9.65,11 8,11 C7.1,11 6.3,10.6 5.75,9.95 L5,10.6 C5.7,11.45 6.8,12 8,12 C10.2,12 12,10.2 12,8 C12,5.8 10.2,4 8,4 Z"/>',
				'clear' : '<path d="M13.7,2.3 C12.1,0.8 10.1,0 8,0 C5.9,0 3.9,0.8 2.3,2.3 C0.7,3.8 0,5.9 0,8 C0,10.1 0.8,12.1 2.3,13.7 C3.8,15.3 5.9,16 8,16 C10.1,16 12.1,15.2 13.7,13.7 C15.3,12.2 16,10.1 16,8 C16,5.9 15.2,3.9 13.7,2.3 Z M8,14.8 C4.3,14.8 1.2,11.8 1.2,8 C1.2,4.2 4.2,1.2 8,1.2 C11.8,1.2 14.8,4.2 14.8,8 C14.8,11.8 11.7,14.8 8,14.8 Z M8,7.15147186 L9.97989899,5.17157288 L10.8284271,6.02010101 L8.84852814,8 L10.8284271,9.97989899 L9.97989899,10.8284271 L8,8.84852814 L6.02010101,10.8284271 L5.17157288,9.97989899 L7.15147186,8 L5.17157288,6.02010101 L6.02010101,5.17157288 L8,7.15147186 Z"/>'
			},

			'circle-solid' : {

				'add' : '<path d="M13.7 2.3C12.1.8 10.1 0 8 0S3.9.8 2.3 2.3C.7 3.8 0 5.9 0 8s.8 4.1 2.3 5.7C3.8 15.3 5.9 16 8 16s4.1-.8 5.7-2.3C15.3 12.2 16 10.1 16 8s-.8-4.1-2.3-5.7zM8.6 7.4h2.8v1.2H8.6v2.8H7.4V8.6H4.6V7.4h2.8V4.6h1.2v2.8z"/>',
				'delete' : '<path d="M8 16c-2.1 0-4.1-.8-5.7-2.3C.7 12.2 0 10.1 0 8s.8-4.1 2.3-5.7C3.8.7 5.9 0 8 0s4.1.8 5.7 2.3C15.3 3.8 16 5.9 16 8s-.8 4.1-2.3 5.7C12.2 15.3 10.1 16 8 16zm3.4-8.6H4.6v1.2h6.9V7.4h-.1z"/>',
				'move-up' : '<path d="M8 16c-2.1 0-4.1-.8-5.7-2.3C.7 12.2 0 10.1 0 8s.8-4.1 2.3-5.7C3.8.7 5.9 0 8 0s4.1.8 5.7 2.3C15.3 3.8 16 5.9 16 8s-.8 4.1-2.3 5.7C12.2 15.3 10.1 16 8 16zm4.3-6.9L8 4.7 3.7 9.1l.9.9L8 6.5l3.4 3.4.9-.8z"/>',
				'move-down' : '<path d="M8 0c2.1 0 4.1.8 5.7 2.3C15.3 3.8 16 5.9 16 8s-.8 4.1-2.3 5.7C12.2 15.3 10.1 16 8 16s-4.1-.8-5.7-2.3C.7 12.2 0 10.1 0 8s.8-4.1 2.3-5.7C3.8.7 5.9 0 8 0zM3.7 6.9L8 11.3 12.3 7l-.9-.9L8 9.5 4.6 6.1l-.9.8z"/>',
				'drag' : '<path d="M8 0c2.1 0 4.1.8 5.7 2.3C15.3 3.8 16 5.9 16 8s-.8 4.1-2.3 5.7C12.2 15.3 10.1 16 8 16s-4.1-.8-5.7-2.3C.7 12.2 0 10.1 0 8s.8-4.1 2.3-5.7C3.8.7 5.9 0 8 0zm4 10.1H4v1.3h8v-1.3zm0-2.7H4v1.3h8V7.4zm0-2.8H4v1.3h8V4.6z"/>',
				'reset' : '<path d="M8,0 C10.1,0 12.1,0.8 13.7,2.3 C15.3,3.8 16,5.9 16,8 C16,10.1 15.2,12.1 13.7,13.7 C12.2,15.3 10.1,16 8,16 C5.9,16 3.9,15.2 2.3,13.7 C0.7,12.2 0,10.1 0,8 C0,5.9 0.8,3.9 2.3,2.3 C3.8,0.7 5.9,0 8,0 Z M8,4 C6.5,4 5.2,4.8 4.55,6.05 L4,5.5 L4,7.5 L6,7.5 L5.25,6.75 C5.75,5.75 6.8,5 8,5 C9.65,5 11,6.35 11,8 C11,9.65 9.65,11 8,11 C7.1,11 6.3,10.6 5.75,9.95 L5,10.6 C5.7,11.45 6.8,12 8,12 C10.2,12 12,10.2 12,8 C12,5.8 10.2,4 8,4 Z"/>',
				'clear' : '<path d="M8,0 C10.1,0 12.1,0.8 13.7,2.3 C15.3,3.8 16,5.9 16,8 C16,10.1 15.2,12.1 13.7,13.7 C12.2,15.3 10.1,16 8,16 C5.9,16 3.9,15.2 2.3,13.7 C0.7,12.2 0,10.1 0,8 C0,5.9 0.8,3.9 2.3,2.3 C3.8,0.7 5.9,0 8,0 Z M9.97989899,5.17157288 L8,7.15147186 L6.02010101,5.17157288 L5.17157288,6.02010101 L7.15147186,8 L5.17157288,9.97989899 L6.02010101,10.8284271 L8,8.84852814 L9.97989899,10.8284271 L10.8284271,9.97989899 L8.84852814,8 L10.8284271,6.02010101 L9.97989899,5.17157288 Z"/>'
			},

			'square' : {

				'add' : '<path d="M8 16H0V0h16v16H8zM8 1.2H1.2v13.6h13.6V1.2H8zm.6 6.2h2.8v1.2H8.6v2.8H7.4V8.6H4.6V7.4h2.8V4.6h1.2v2.8z"/>',
				'delete' : '<path d="M8 16H0V0h16v16H8zM8 1.2H1.2v13.6h13.6V1.2H8zm3.4 6.2H4.6v1.2h6.9V7.4h-.1z"/>',
				'move-up' : '<path d="M8 16H0V0h16v16H8zM8 1.2H1.2v13.6h13.6V1.2H8zm4.3 7.9L8 4.7 3.7 9.1l.9.9L8 6.5l3.4 3.4.9-.8z"/>',
				'move-down' : '<path d="M8 16H0V0h16v16H8zM8 1.2H1.2v13.6h13.6V1.2H8zM3.7 6.9L8 11.3 12.3 7l-.9-.9L8 9.5 4.6 6.1l-.9.8z"/>',
				'drag' : '<path d="M8 16H0V0h16v16H8zM8 1.2H1.2v13.6h13.6V1.2H8zm-4 8.9h8v1.3H4v-1.3zm0-2.7h8v1.3H4V7.4zm0-2.8h8v1.3H4V4.6z"/>',
				'reset' : '<path d="M8,16 L0,16 L0,8 L0,0 L8,0 L16,0 L16,8 L16,16 L8,16 Z M8,1.2 L1.2,1.2 L1.2,8 L1.2,14.8 L8,14.8 L14.8,14.8 L14.8,8 L14.8,1.2 L8,1.2 Z M8,4 C6.5,4 5.2,4.8 4.55,6.05 L4,5.5 L4,7.5 L6,7.5 L5.25,6.75 C5.75,5.75 6.8,5 8,5 C9.65,5 11,6.35 11,8 C11,9.65 9.65,11 8,11 C7.1,11 6.3,10.6 5.75,9.95 L5,10.6 C5.7,11.45 6.8,12 8,12 C10.2,12 12,10.2 12,8 C12,5.8 10.2,4 8,4 Z"/>',
				'clear' : '<path d="M8,16 L0,16 L0,8 L0,0 L8,0 L16,0 L16,8 L16,16 L8,16 Z M8,1.2 L1.2,1.2 L1.2,8 L1.2,14.8 L8,14.8 L14.8,14.8 L14.8,8 L14.8,1.2 L8,1.2 Z M8,7.15147186 L9.97989899,5.17157288 L10.8284271,6.02010101 L8.84852814,8 L10.8284271,9.97989899 L9.97989899,10.8284271 L8,8.84852814 L6.02010101,10.8284271 L5.17157288,9.97989899 L7.15147186,8 L5.17157288,6.02010101 L6.02010101,5.17157288 L8,7.15147186 Z"/>'
			},

			'square-solid' : {

				'add' : '<path d="M16 0v16H0V0h16zM8.6 4.6H7.4v2.8H4.6v1.2h2.8v2.8h1.2V8.6h2.8V7.4H8.6V4.6z"/>',
				'delete' : '<path d="M8 16H0V0h16v16H8zm3.4-8.6H4.6v1.2h6.9V7.4h-.1z"/>',
				'move-up' : '<path d="M8 16H0V0h16v16H8zm4.3-6.9L8 4.7 3.7 9.1l.9.9L8 6.5l3.4 3.4.9-.8z"/>',
				'move-down' : '<path d="M8 16H0V0h16v16H8zM3.7 6.9L8 11.3 12.3 7l-.9-.9L8 9.5 4.6 6.1l-.9.8z"/>',
				'drag' : '<path d="M16 0v16H0V0h16zm-4 10.1H4v1.3h8v-1.3zm0-2.7H4v1.3h8V7.4zm0-2.8H4v1.3h8V4.6z"/>',
				'reset' : '<path d="M16,0 L16,16 L0,16 L0,0 L16,0 Z M8,4 C6.5,4 5.2,4.8 4.55,6.05 L4,5.5 L4,7.5 L6,7.5 L5.25,6.75 C5.75,5.75 6.8,5 8,5 C9.65,5 11,6.35 11,8 C11,9.65 9.65,11 8,11 C7.1,11 6.3,10.6 5.75,9.95 L5,10.6 C5.7,11.45 6.8,12 8,12 C10.2,12 12,10.2 12,8 C12,5.8 10.2,4 8,4 Z"/>',
				'clear' : '<path d="M16,0 L16,16 L0,16 L0,0 L16,0 Z M9.97989899,5.17157288 L8,7.15147186 L6.02010101,5.17157288 L5.17157288,6.02010101 L7.15147186,8 L5.17157288,9.97989899 L6.02010101,10.8284271 L8,8.84852814 L9.97989899,10.8284271 L10.8284271,9.97989899 L8.84852814,8 L10.8284271,6.02010101 L9.97989899,5.17157288 Z"/>'
			}
		};

		// Get section icon objects
		$('[data-section-icons]', section_obj).each(function() {

			// Do not re-render already rendered icons
			if($(this).html() !== '') { return; }

			var section_icons_array = [];

			var field = ws_this.get_field($(this));

			// Read data-repeatable-section-id
			var repeatable_section_id = $(this).attr('data-repeatable-section-id');
			if(typeof(repeatable_section_id) === 'undefined') { 

				ws_this.error('error_section_icon_no_section');
				repeatable_section_id = 0;
			}
			$(this).attr('data-repeatable-section-id', false);

			// Check if button is in its own repeatable section
			var parent_section_obj = $(this).closest('[data-repeatable]');
			var own_repeatable_section = (

				parent_section_obj.length &&
				(parent_section_obj.attr('data-id') == repeatable_section_id)
			);

			// Read section icons style
			var section_icons_style = ws_this.get_object_meta_value(field, 'section_icons_style', []);
			$(this).addClass('wsf-section-icons-' + section_icons_style);

			// Read section icons size
			var section_icons_size = parseInt(ws_this.get_object_meta_value(field, 'section_icons_size', '24'), 10);
			if(isNaN(section_icons_size)) { section_icons_size = 24; }
			if(section_icons_size < 1) { section_icons_size = 1; }

			// Read colors
			var section_icons_color_on = ws_this.get_object_meta_value(field, 'section_icons_color_on', '#000');
			var section_icons_color_off = ws_this.get_object_meta_value(field, 'section_icons_color_off', '#888');

			// Read horizontal alignment
			var section_icons_horizontal_align = ws_this.get_object_meta_value(field, 'horizontal_align', 'right');

			// Get skin spacing small
			var skin_spacing_small = ws_form_settings.skin_spacing_small;

			// Read section icons
			var section_icons = ws_this.get_object_meta_value(field, 'section_icons', []);

			for(var section_icon_index in section_icons) {

				if(!section_icons.hasOwnProperty(section_icon_index)) { continue; }

				var section_icon = section_icons[section_icon_index];

				var section_icon_type = ((typeof(section_icon.section_icons_type) !== 'undefined') ? section_icon.section_icons_type : false);
				if(section_icon_type === false) { continue; }

				var section_icon_label = ((typeof(section_icon.section_icons_label) !== 'undefined') ? section_icon.section_icons_label : ws_this.language('section_icon_' + section_icon_type))

				// Check if icon type can be rendered here
				if(
					(method_same_section_array.indexOf(section_icon_type) !== -1) &&
					!own_repeatable_section
				) {

					ws_this.error('error_section_icon_not_in_own_section', section_icon_type);
					continue;
				}

				var section_icon_text = '<span class="wsf-section-icon-text">' + ws_this.language('section_icon_' + section_icon_type) + '</span>';

				// Determine cursor
				var section_icon_cursor = ((section_icon_type == 'drag') ? 'move' : 'pointer');
				
				// Build HTML
				switch(section_icons_style) {

					case 'text' :

						var section_icon_html = section_icon_text;
						break;

					case 'custom' :

						var section_icon_html = ws_this.get_object_meta_value(field, 'section_icons_html_' + section_icon_type, '');
						if(section_icon_html == '') { section_icon_html = section_icon_text; }
						break;

					default :

						var section_icon_svg = (

							(typeof(section_icon_sets[section_icons_style]) !== 'undefined') &&
							(typeof(section_icon_sets[section_icons_style][section_icon_type]) !== 'undefined')

						) ? section_icon_sets[section_icons_style][section_icon_type] : false;

						var section_icon_html = (section_icon_svg !== false) ? ('<svg class="wsf-section-icon" height="' + section_icons_size + '" width="' + section_icons_size + '" viewBox="0 0 16 16" style="display: block; height: auto; max-width: 100%;">' + section_icon_svg + '</svg>') : section_icon_text;
				}

				section_icons_array.push('<li data-action="wsf-section-' + section_icon_type + '-icon" class="wsf-section-' + section_icon_type + '" style="cursor: ' + section_icon_cursor + '; margin: 0; -webkit-margin-end: ' + skin_spacing_small + 'px; margin-inline-end: ' + skin_spacing_small + 'px; padding: 0;" title="' + ws_this.html_encode(section_icon_label) + '" aria-label="' + ws_this.html_encode(section_icon_label) + '" role="button" data-color-on="' + section_icons_color_on + '" data-color-off="' + section_icons_color_off + '" data-repeatable-section-id="' + repeatable_section_id + '">' + section_icon_html + '</li>');
			}

			$(this).html('<ul class="wsf-section-icons" style="display: flex; justify-content: ' + section_icons_horizontal_align + '; list-style-type: none; margin: 0; padding: 0; user-select: none;">' + section_icons_array.join('') + '</ul>');
		});
	}

	// Initialize navigation enabled/disabled on a repeatable section
	$.WS_Form.prototype.section_repeatable_navigation_enable_disable = function(section_id) {

	var ws_this = this;

		// Get section obj
		var section_obj = $('[data-repeatable][data-id="' + section_id + '"]', this.form_canvas_obj);

		// Get section count
		var section_count = section_obj.length;

		// Get section data
		var section = this.section_data_cache[section_id];

		// Get section repeat min
		var section_repeat_min = this.get_section_repeat_min(section);

		// Get section repeat max
		var section_repeat_max = this.get_section_repeat_max(section, section_repeat_min);

		// Add - Button / Icon (Can be placed anywhere on the form)
		$('[data-action="wsf-section-add-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-add-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).each(function() {

			if((section_repeat_max !== false) && (section_count >= section_repeat_max)) {

				ws_this.section_action_off($(this), 'add');

			} else {

				ws_this.section_action_on($(this), 'add');
			}
		});

		// Delete - Button / Icon (Can be placed anywhere on the form)
		$('[data-action="wsf-section-delete-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-delete-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).each(function() {

			if(section_count <= section_repeat_min) {

				ws_this.section_action_off($(this), 'delete');

			} else {

				ws_this.section_action_on($(this), 'delete');
			}
		});

		// Move Up - Button / Icon (Must be in repeatable section you want to move up)
		$('[data-action="wsf-section-move-up-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-move-up-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).each(function(button_index) {

			var section_index = ws_this.section_get_index($(this), section_id);

			if((section_count == 1) || (section_index == 0)) {

				ws_this.section_action_off($(this), 'move-up');

			} else {

				ws_this.section_action_on($(this), 'move-up');
			}
		});

		// Move Up - Button / Icon (Must be in repeatable section you want to move down)
		$('[data-action="wsf-section-move-down-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-move-down-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).each(function(button_index) {

			var section_index = ws_this.section_get_index($(this), section_id);

			if((section_count == 1) || (section_index == (section_count - 1))) {

				ws_this.section_action_off($(this), 'move-down');

			} else {

				ws_this.section_action_on($(this), 'move-down');
			}
		});

		// Drag - Button / Icon (Can be placed anywhere on the form)
		$('[data-action="wsf-section-drag-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-drag-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).each(function() {

			if(section_count == 1) {

				ws_this.section_action_off($(this), 'drag');

			} else {

				ws_this.section_action_on($(this), 'drag');
			}
		});

		// De-dupe
		this.form_dedupe_value_scope_process_all();
	}

	// Initialize events on a repeatable section
	$.WS_Form.prototype.section_repeatable_navigation_events = function(section_id) {

		var ws_this = this;

		// Get section count
		var section_count = $('[data-repeatable][data-id="' + section_id + '"]', this.form_canvas_obj).length;

		// Get section data
		var section = this.section_data_cache[section_id];

		// Get section repeat min
		var section_repeat_min = this.get_section_repeat_min(section);

		// Get section repeat max
		var section_repeat_max = this.get_section_repeat_max(section, section_repeat_min);

		// Add - Button (Can be placed anywhere on the form)
		$('[data-action="wsf-section-add-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-add-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).not('[data-init-repeatable-section]').on('click', function(e) {

			e.preventDefault();

			// Check if we should run this
			if($(this).hasClass('wsf-section-add-disabled')) { return; }

			// Get section ID
			var section_id = $(this).attr('data-repeatable-section-id');
			if(typeof(section_id) === 'undefined') {

				ws_this.error('error_section_button_no_section');
				return;
			}

			// Check if button is in its own repeatable section
			var parent_section_obj = $(this).closest('[data-repeatable]');
			var own_repeatable_section = (

				parent_section_obj.length &&
				(parent_section_obj.attr('data-id') == section_id)
			);

			// Clone section
			if(own_repeatable_section) {

				// Button/icon is in its own repeatable section
				ws_this.section_clone($(this).closest('[data-repeatable]'));

			} else {

				// Button/icon relates to a different section on the page (add to bottom)
				var section_to_clone = $('[data-repeatable][data-id="' + section_id + '"]', ws_this.form_canvas_obj).last();
				ws_this.section_clone(section_to_clone);
			}

			// Initialize cloned section
			ws_this.section_add_init(section_id);

			// Trigger event
			ws_this.form_canvas_obj.trigger('wsf-section-repeatable').trigger('wsf-section-repeatable-' + section_id);

		}).attr('data-init-repeatable-section', '');

		// Delete - Button (Can be placed anywhere on the form)
		$('[data-action="wsf-section-delete-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-delete-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).not('[data-init-repeatable-section]').on('click', function(e) {

			e.preventDefault();

			// Check if we should run this
			if($(this).hasClass('wsf-section-delete-disabled')) { return; }

			// Get section ID
			var section_id = $(this).attr('data-repeatable-section-id');
			if(typeof(section_id) === 'undefined') {

				ws_this.error('error_section_button_no_section');
				return;
			}

			// Check if button is in its own repeatable section
			var parent_section_obj = $(this).closest('[data-repeatable]');
			var own_repeatable_section = (

				parent_section_obj.length &&
				(parent_section_obj.attr('data-id') == section_id)
			);

			// Delete section
			if(own_repeatable_section) {

				// Button/icon is in its own repeatable section
				$(this).closest('[data-repeatable]').remove();

			} else {

				// Button/icon relates to a different section on the page (remove from bottom)
				var section_to_remove = $('[data-repeatable][data-id="' + section_id + '"]', ws_this.form_canvas_obj).last();
				section_to_remove.remove();
			}

			// Initialize removed section
			ws_this.section_remove_init(section_id);

			// Trigger event
			ws_this.form_canvas_obj.trigger('wsf-section-repeatable').trigger('wsf-section-repeatable-' + section_id);

		}).attr('data-init-repeatable-section', '');

		// Move Up - Button / Icon
		$('[data-action="wsf-section-move-up-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-move-up-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).not('[data-init-repeatable-section]').on('click', function(e) {

			e.preventDefault();

			// Check if we should run this
			if($(this).hasClass('wsf-section-move-up-disabled')) { return; }

			var section_id = $(this).attr('data-repeatable-section-id');
			var section_obj = $(this).closest('[data-repeatable]');

			// Move section up
			section_obj.prev().insertAfter(section_obj);

			// Navigation enable/disable
			ws_this.section_repeatable_navigation_enable_disable(section_id);

			// Labels
			ws_this.section_repeatable_labels(section_id);

			// Section repeatable hidden field
			ws_this.section_repeatable_hidden_field();

			// Calculations
			ws_this.form_calc(false, section_id);

		}).attr('data-init-repeatable-section-yes', '');

		// Move Down - Button / Icon
		$('[data-action="wsf-section-move-down-button"][data-repeatable-section-id="' + section_id + '"], [data-action="wsf-section-move-down-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).not('[data-init-repeatable-section]').on('click', function(e) {

			e.preventDefault();

			// Check if we should run this
			if($(this).hasClass('wsf-section-move-down-disabled')) { return; }

			var section_id = $(this).attr('data-repeatable-section-id');
			var section_obj = $(this).closest('[data-repeatable]');

			// Move section down
			section_obj.next().insertBefore(section_obj);

			// Navigation enable/disable
			ws_this.section_repeatable_navigation_enable_disable(section_id);

			// Labels
			ws_this.section_repeatable_labels(section_id);

			// Section repeatable hidden field
			ws_this.section_repeatable_hidden_field();

			// Calculations
			ws_this.form_calc(false, section_id);

		}).attr('data-init-repeatable-section', '');

		// Drag Icon
		$('[data-action="wsf-section-drag-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).not('[data-init-repeatable-section]').on('mouseenter touchstart', function(e) {

			e.preventDefault();

			// Check if we should run this
			if($(this).hasClass('wsf-section-drag-disabled')) { return; }

			var section_obj = $(this).closest('[data-repeatable]');

			if(
				(ws_this.section_repeatable_dragged === false)
			) {

				var section_id = section_obj.attr('data-id');

				// Make each section sortable
				section_obj.parent(':not(.ui-sortable)').sortable({

					items: '> [data-repeatable][data-id="' + section_id + '"]',
					cancel: '.wsf-section-repeatable-cancel',
					cursor: 'move',
					handle: '.wsf-section-drag',
					tolerance: 'pointer',
					containment: 'parent',
					start: function(event, ui) {

						ws_this.section_repeatable_dragged = true;
					},

					stop: function(event, ui) {

						ws_this.section_repeatable_dragged = false;

						// Navigation enable/disable
						ws_this.section_repeatable_navigation_enable_disable(section_id);

						// Labels
						ws_this.section_repeatable_labels(section_id);

						// Section repeatable hidden field
						ws_this.section_repeatable_hidden_field();

						// Calculations
						ws_this.form_calc(false, section_id);
					}
				});
			}

		}).on('mouseleave touchstart', function(e) {

			e.preventDefault();

			// Check if we should run this
			if($(this).hasClass('wsf-section-drag-disabled')) { return; }

			if(ws_this.section_repeatable_dragged === false) {

				$(this).closest('[data-repeatable]').parent('.ui-sortable').sortable('destroy');
			}

		}).attr('data-init-repeatable-section', '');

		// Reset - Icon (Can be placed anywhere on the form)
		$('[data-action="wsf-section-reset-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).not('[data-init-repeatable-section]').on('click', function(e) {

			e.preventDefault();

			// Get section ID
			var repeatable_section_id = $(this).attr('data-repeatable-section-id');
			if(typeof(repeatable_section_id) === 'undefined') {

				ws_this.error('error_section_button_no_section');
				return;
			}

			// Check if button is in its own repeatable section
			var parent_section_obj = $(this).closest('[data-repeatable]');
			var own_repeatable_section = (

				parent_section_obj.length &&
				(parent_section_obj.attr('data-id') == repeatable_section_id)
			);

			// Get section repeatable index
			var section_repeatable_index = own_repeatable_section ? parent_section_obj.attr('data-repeatable-index') : false;

			// Reset all fields in section
			ws_this.section_fields_reset(repeatable_section_id, false, section_repeatable_index);

		}).attr('data-init-repeatable-section', '');

		// Clear - Icon (Can be placed anywhere on the form)
		$('[data-action="wsf-section-clear-icon"][data-repeatable-section-id="' + section_id + '"]', this.form_canvas_obj).not('[data-init-repeatable-section]').on('click', function(e) {

			e.preventDefault();

			// Get section ID
			var repeatable_section_id = $(this).attr('data-repeatable-section-id');
			if(typeof(repeatable_section_id) === 'undefined') {

				ws_this.error('error_section_button_no_section');
				return;
			}

			// Check if button is in its own repeatable section
			var parent_section_obj = $(this).closest('[data-repeatable]');
			var own_repeatable_section = (

				parent_section_obj.length &&
				(parent_section_obj.attr('data-id') == repeatable_section_id)
			);

			// Get section repeatable index
			var section_repeatable_index = own_repeatable_section ? parent_section_obj.attr('data-repeatable-index') : false;

			// Reset all fields in section
			ws_this.section_fields_reset(repeatable_section_id, true, section_repeatable_index);

		}).attr('data-init-repeatable-section', '');
	}

	// Initialize repeatable section labels
	$.WS_Form.prototype.section_repeatable_labels = function(section_id) {

		// Get section data
		var section = this.section_data_cache[section_id];

		// Section repeat labels
		var section_render_label = this.get_object_meta_value(section, 'render_label', 'on');
		var section_repeat_label = this.get_object_meta_value(section, 'section_repeat_label', 'on');
		if(section_render_label && !section_repeat_label) {

			$('[data-repeatable][data-id="' + section_id + '"]', this.form_canvas_obj).each(function(index) {

				(index) ? $('> legend', $(this)).hide() : $('> legend', $(this)).show();
			});
		}
	}

	// Get section index an object is in
	$.WS_Form.prototype.section_get_index = function(obj, section_id) {

		var section_index = 0;

		// Get section this object is in
		var section_obj = obj.closest('[data-repeatable]');

		// Run through sections and find matching section
		$('[data-repeatable][data-id="' + section_id + '"]', this.form_canvas_obj).each(function(this_section_index) {

			if($(this).attr('id') === section_obj.attr('id')) { section_index = this_section_index; return false; }
		});

		return section_index;
	}

	// Initialize repeatable section hidden field
	$.WS_Form.prototype.section_repeatable_hidden_field = function() {

		var ws_this = this;

		this.section_repeatable_indexes = {};

		var section_obj = $('[data-repeatable]', this.form_canvas_obj);

		// Process each section
		section_obj.each(function() {

			// Get section ID
			var section_id = $(this).attr('data-id');

			// Get section repeatable index
			var section_repeatable_index = $(this).attr('data-repeatable-index');

			// Add to section_repeatable_indexes
			if(typeof(ws_this.section_repeatable_indexes['section_' + section_id]) === 'undefined') { ws_this.section_repeatable_indexes['section_' + section_id] = []; }
			ws_this.section_repeatable_indexes['section_' + section_id].push(section_repeatable_index);

			// Trigger event
			ws_this.form_canvas_obj.trigger('wsf-section-repeatable-' + section_id);
		});

		// Set section_repeatable_indexes hidden field
		this.form_add_hidden_input('wsf_form_section_repeatable_index', JSON.stringify(this.section_repeatable_indexes), false, false, true);

		// Trigger event
		if(section_obj.length) {

			this.form_canvas_obj.trigger('wsf-section-repeatable');
		}
	}

	// Get section repeatable array
	$.WS_Form.prototype.get_section_id_repeatable_array = function() {

		// Get all repeatable sections
		var section_id_repeatable_array = [];

		$('[data-repeatable]', this.form_canvas_obj).each(function() {

			var section_id = $(this).attr('data-id');

			if(typeof(section_id_repeatable_array[section_id]) === 'undefined') {

				section_id_repeatable_array[section_id] = 1;

			} else {

				section_id_repeatable_array[section_id]++;
			}
		});

		return section_id_repeatable_array;
	}

	// Section button/icon off
	$.WS_Form.prototype.section_action_off = function(obj, id) {

		obj.addClass('wsf-section-' + id + '-disabled').filter(':button').attr('disabled', '');

		// Section icon
		if(typeof(obj.attr('data-color-off')) !== 'undefined') {

			obj.css({cursor: 'not-allowed'});
			var color_off = obj.attr('data-color-off');
			$('svg path', obj).attr({'fill': color_off});
			$('span.wsf-section-icon-text', obj).css({color: color_off});
		}
	}

	// Section button/icon on
	$.WS_Form.prototype.section_action_on = function(obj, id) {

		obj.removeClass('wsf-section-' + id + '-disabled').filter(':button').removeAttr('disabled');

		// Section icon
		if(typeof(obj.attr('data-color-on')) !== 'undefined') {

			var action = obj.attr('data-action');
			var cursor = ((action === 'wsf-section-drag-icon') ? 'move' : 'pointer');
			obj.css({cursor: cursor});
			var color_on = obj.attr('data-color-on');
			$('svg path', obj).attr({'fill': color_on});
			$('span.wsf-section-icon-text', obj).css({color: color_on});
		}
	}

	// Clone section
	$.WS_Form.prototype.section_clone = function(section_obj) {

		// Get section ID
		var section_id = section_obj.attr('data-id');

		// Get section data
		var section = this.section_data_cache[section_id];

		// Adjust section meta data
		section.meta.disabled_section = (section_obj.is(':disabled') ? 'on' : '');
		section.meta.hidden_section = (section_obj.is('[style!="display:none;"][style!="display: none;"]') ? '' : 'on');

		// Get section HTML
		var section_html = this.get_section_html(section);

		// Add after current section
		var section_new = $(section_html).insertAfter(section_obj);

		$('[data-init-conditional]', section_new).removeAttr('[data-init-conditional]');

		// Remove fields that cannot be cloned
		for(var field_type in $.WS_Form.field_type_cache) {

			if(!$.WS_Form.field_type_cache.hasOwnProperty(field_type)) { continue; }

			var field_type_config = $.WS_Form.field_type_cache[field_type];

			var multiple = (typeof(field_type_config.multiple) !== 'undefined') ? field_type_config.multiple : true;

			if(multiple === false) {

				var field_obj = $('[data-type="' + field_type + '"]', section_new);

				if(field_obj.length) {

					// Remove field
					field_obj.remove();
				}
			}
		}

		return section_new;
	}

	// Initialize after section added
	$.WS_Form.prototype.section_add_init = function(section_id) {

		// Navigation - Render
		this.section_repeatable_navigation_render(section_id);

		// Navigation - Events
		this.section_repeatable_navigation_events(section_id);

		// Navigation - Enable / Disable
		this.section_repeatable_navigation_enable_disable(section_id);

		// Labels
		this.section_repeatable_labels(section_id);

		// Text areas
		this.form_textarea();

		// Select All
		this.form_select_all();

		// Input masks
		this.form_inputmask();

		// Checkbox min max
		this.form_checkbox_min_max();

		// Select min max
		this.form_select_min_max();

		// Select AJAX
		this.form_select_ajax();

		// Range sliders
		this.form_input_range();

		// Dates
		this.form_date();

		// Colors
		this.form_color();

		// Signature
		this.form_signature();

		// Rating
		this.form_rating();

		// Google Map
		this.form_google_map();

		// Dedupe value scope
		this.form_dedupe_value_scope();

		// File inputs
		this.form_file();

		// Text input and textarea character and word count
		this.form_character_word_count();

		// Password strength meter
		this.form_password_strength_meter();

		// E-Commerce
		this.form_ecommerce();

		// Repeatable section hidden field
		this.section_repeatable_hidden_field();

		// Calculations
		this.form_calc(false, section_id);

		// Credit Card
		this.form_credit_card();

		// Navigation
		this.form_navigation();

		// Analytics
		this.form_analytics();

		// Form validation - Real time
		this.form_validate_real_time();

		// Client side form conditions
		this.form_conditional();

		// Progress
		this.form_progress();

		// Required
		this.form_required();

		// Field Cascacding
		this.form_cascade();

		// Bypass
		this.form_bypass(false);
	}

	// Initialize after section remove
	$.WS_Form.prototype.section_remove_init = function(section_id) {

		// Remove signatures from array
		if(this.signatures.length > 0) {

			for(var signature_index in this.signatures) {

				if(!this.signatures.hasOwnProperty(signature_index)) { continue; }

				var signature = this.signatures[signature_index];

				var signature_name = signature.name;

				var signature_obj_field = $('[name="' + signature_name + '"]', this.form_canvas_obj);

				if(!signature_obj_field.length) {

					this.signatures.splice(signature_index, 1);
				}
			}
		}

		// Delete unused validation_message_cache elements
		for(var section_repeatable_index in this.validation_message_cache[section_id]) {

			var section_obj = $('[data-repeatable][data-id="' + section_id + '"][data-repeatable-index="' + section_repeatable_index + '"]', this.form_canvas_obj);
			if(!section_obj.length) {

				delete this.validation_message_cache[section_id][section_repeatable_index];
			}
		}

		// Delete unused calcs
		this.form_calc_clean();

		// Navigation - Enable / Disable
		this.section_repeatable_navigation_enable_disable(section_id);

		// Labels
		this.section_repeatable_labels(section_id);

		// Re-validate the form
		this.form_validate_real_time_process();

		// Process form progress
		this.form_progress_process();

		// Repeatable section hidden field
		this.section_repeatable_hidden_field();

		// Calculations
		this.form_calc(false, section_id);
	}
	// Form progress
	$.WS_Form.prototype.form_progress = function() {

		var ws_this = this;

		// Get framework classes
		var progress_class_complete_array = this.get_field_value_fallback('progress', false, 'class_complete', []);
		this.progress_class_complete = progress_class_complete_array.join(' ');

		var progress_class_incomplete_array = this.get_field_value_fallback('progress', false, 'class_incomplete', []);
		this.progress_class_incomplete = progress_class_incomplete_array.join(' ');

		// Required field event handling
		$('[data-required]:not([data-init-required])', this.form_canvas_obj).each(function() {

			// Get progress event
			var field = ws_this.get_field($(this));
			var field_type = field.type;
			var field_config = $.WS_Form.field_type_cache[field_type];
			var progress_event = field_config.events.event;

			$(this).on(progress_event, function() {

				ws_this.form_progress_process();
			});
		});

		// data-progress-include additional fields to include (e.g. checkbox min/max checked)
		$('[data-progress-include]:not([data-init-required])', this.form_canvas_obj).each(function() {

			// Get progress event
			var progress_event = $(this).attr('data-progress-include');

			$(this).on(progress_event, function() {

				ws_this.form_progress_process();
			});
		});

		// Initial progress calculation
		this.form_progress_process();

		// Reset post upload progress indicators
		this.api_call_progress_reset();
	}

	// Form progress - Process
	$.WS_Form.prototype.form_progress_process = function() {

		var ws_this = this;
		var radio_field_processed = [];		// This ensures correct progress numbers of radios

		// Count completed fields
		var progress_count = 0;
		var progress_valid_count = 0;

		// Get required fields
		$('[data-required]:not([data-required-bypass],[data-required-bypass-section],[data-required-bypass-group])', this.form_canvas_obj).each(function() {

			// Get progress event
			var field = ws_this.get_field($(this));
			var field_type = field.type;

			// Get repeatable suffix
			var section_repeatable_index = ws_this.get_section_repeatable_index($(this));
			var section_repeatable_suffix = (section_repeatable_index > 0) ? '[' + section_repeatable_index + ']' : '';

			// Build field name
			var field_name = ws_form_settings.field_prefix + ws_this.get_field_id($(this)) + section_repeatable_suffix;

			// Determine field validity based on field type
			var validity = false;
			switch(field_type) {

				case 'radio' :
				case 'price_radio' :

					if(typeof(radio_field_processed[field_name]) === 'undefined') { 

						validity = $(this)[0].checkValidity();

					} else {

						return;
					}
					break;

				case 'signature' :

					validity = ws_this.signature_get_response_by_name(field_name);
					break;

				case 'email' :

					var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					validity = re.test($(this).val());
					break;

				default :

					validity = $(this)[0].checkValidity();
			}

			if(validity) { progress_valid_count++; }
			radio_field_processed[field_name] = true;
			progress_count++;
		});

		// data-progress-include additional fields to include (e.g. checkbox min/max checked)
		$('[data-progress-include]', this.form_canvas_obj).each(function() {

			var validity = $(this)[0].checkValidity();
			if(validity) { progress_valid_count++; }
			progress_count++;
		});

		// Calculate progress of the form
		var progress_percentage = (progress_count > 0) ? Math.round((progress_valid_count / progress_count) * 100) : 0;

		// Set progress fields
		var progress_obj = $('[data-progress-bar][data-source="form_progress"], .wsf-form-conversational-nav-progress', this.form_canvas_obj);
		progress_obj.each(function() {

			ws_this.form_progress_set_value($(this), progress_percentage);
		});
	}

	// Form progress - Set value (value = 0 to 100)
	$.WS_Form.prototype.form_progress_set_value = function(obj, progress_percentage) {

		var progress_value_obj = $('[data-progress-bar-value]', obj);
		if(!progress_value_obj.length) { progress_value_obj = obj; }

		// Apply width if this is not a progress bar
		if(obj.is('progress')) {

			// Work out range
			if(obj.attr('max')) {

				var progress_max = parseFloat(obj.attr('max'));

			} else {

				var progress_max = 100;
				obj.attr('max', 100);
			}

			// Work out value
			var progress_value = ((progress_percentage / 100) * progress_max);
			if(progress_value > progress_max) { progress_value = progress_max; }

			var field_trigger = (progress_value_obj.val() != progress_value);
			progress_value_obj.val(progress_value);
			if(field_trigger) { progress_value_obj.trigger('change'); }

		} else {

			var field_trigger = (progress_value_obj.attr('data-value') != progress_percentage);
			progress_value_obj.attr('data-value', progress_percentage).css('width', progress_percentage + '%');
			if(field_trigger) { progress_value_obj.trigger('change'); }

			// ARIA
			if(typeof(obj.attr('aria-valuenow')) !== 'undefined') { obj.attr('aria-valuenow', progress_percentage); }
			if(typeof(progress_value_obj.attr('aria-valuenow')) !== 'undefined') { progress_value_obj.attr('aria-valuenow', progress_percentage); }
		}

		// Assign classes
		if(progress_percentage == 100) {

			obj.addClass(this.progress_class_complete);
			obj.removeClass(this.progress_class_incomplete);

		} else {

			obj.removeClass(this.progress_class_complete);
			obj.addClass(this.progress_class_incomplete);
		}

		// Help text
		if(this.conversational && obj.hasClass('wsf-form-conversational-nav-progress')) {

			var help_obj = $('.wsf-form-conversational-nav-progress-help', this.form_canvas_obj);
			var help = this.get_object_meta_value(this.form, 'conversational_nav_progress_help', '#progress_percent', false, false);

		} else {

			var field = this.get_field(obj);;
			var help = this.get_object_meta_value(field, 'help', '#progress_percent', false, false);
			var help_obj = this.get_help_obj(obj);
		}

		// If #progress_ not present, don't bother processing
		if(
			help_obj.length &&
			(help.indexOf('#progress') !== -1)
		) {

			// Parse the help text
			var help_values = {

				'progress_remaining_percent': (100 - progress_percentage) + '%',
				'progress_remaining': (100 - progress_percentage),
				'progress_percent': progress_percentage + '%',
				'progress': progress_percentage
			};
			var help_parsed = this.mask_parse(help, help_values);
			help_parsed = this.parse_variables_process(help_parsed).output;

			// Update help HTML
			help_obj.html(help_parsed);
		}
	}

	// Form Progress - Tabs
	$.WS_Form.prototype.form_progress_tabs = function(group_index) {

		var ws_this = this;

		var progress_objs = $('[data-source="tab_progress"]', this.form_canvas_obj);
		if(progress_objs.length) {

			var group_count = $('.wsf-group-tabs', this.form_canvas_obj).children(':not([data-wsf-group-hidden])').length;

			progress_objs.each(function() {

				// Get progress value
				var progress_percentage = ((parseInt(group_index) + 1) / group_count) * 100;

				// Set progress fields
				ws_this.form_progress_set_value($(this), Math.round(progress_percentage));
			});
		}
	}

	// Adds signature elements
	$.WS_Form.prototype.form_signature = function() {

		var ws_this = this;

		// Get signature objects
		var signature_objects = $('[data-type="signature"]:not([data-init-signature])', this.form_canvas_obj);
		var signature_objects_count = signature_objects.length;
		if(!signature_objects_count) { return false;}

		// Process each signature
		signature_objects.each(function() {

			// Flag so it only initializes once
			$(this).attr('data-init-signature', '');

			// Input
			var input = $('input', $(this));

			// Canvas
			var canvas = $('canvas', $(this));
			var canvas_element = canvas[0];

			// Name
			var name = input.attr('name');

			// Height
			var height = input.attr('data-height');
			canvas.attr('style', 'height: ' + height + '; padding: 0; width: 100%;');

			// ID
			var id = $(this).attr('data-id');

			// Field
			var field = ws_this.field_data_cache[id];

			// Size
			var dot_size = input.attr('data-dot-size');

			// Crop
			var crop = (input.attr('data-crop') !== undefined);

			// Pen color
			var pen_color = input.attr('data-pen-color');

			// Type
			var mime = (input.attr('data-mime') !== undefined) ? input.attr('data-mime') : 'image/png';

			// Build config
			var config = {

				maxWidth: dot_size,
				penColor: pen_color,
			}

			var signature = {signature: false, canvas: canvas, canvas_element: canvas_element, input: input, name: name, mime: mime, config: config, crop: crop};

			// Background color (JPG only)
			if(mime == 'image/jpeg') {

				var background_color = (canvas.attr('data-background-color') !== undefined) ? canvas.attr('data-background-color') : '#ffffff';
				config.backgroundColor = background_color;
				signature.background_color = background_color;
			}

			// Add to signatures array
			ws_this.signatures.push(signature)

			// Process
			ws_this.signature_process(ws_this.signatures[ws_this.signatures.length-1]);
		});
	}

	// Wait until Signature loaded, then process
	$.WS_Form.prototype.signature_process = function(signature, total_ms_start) {

		var ws_this = this;

		// Check to see if SignaturePad loaded
		if(typeof(SignaturePad) !== 'undefined') {

			// Get current framework
			var framework_groups = this.framework['groups']['public'];
			var class_active = typeof(framework_groups['class_active']) ? framework_groups['class_active'] : false;

			// Momentarily show group if currently hidden so that width is calculated correctly
			var group_obj = $(signature.canvas_element, this.form_canvas_obj).closest('[id^="' + this.form_id_prefix + 'group-"]');
			var group_visible = group_obj.is(':visible');

			if(!group_visible) {

				if(class_active) {

					group_obj.addClass(class_active);

				} else {

					group_obj.show();
				}
			}

			// Init signature pad
			var signature_pad = new SignaturePad(signature.canvas_element, signature.config);

			// Add to signatures object
			signature.signature = signature_pad;

			// Add signature to signatures_by_name array
			this.signatures_by_name[signature.name] = signature;

			// Clear event
			signature.canvas.parent().find('[data-action="wsf-signature-clear"]').on('click', function(e) {

				e.preventDefault();

				signature.signature.clear();

				// Clear validation input
				signature.input.val('').trigger('change');
			});

			// Mouse down / touch start event
			signature.canvas.on('mousedown touchstart', function() {

				// Set validation input
				signature.input.val('1').trigger('change');
			});

			$(document).on('keydown', function(e) {

				if(signature.canvas.is(':focus') && (e.keyCode == 27)) {

					signature.signature.clear();

					// Clear validation input
					signature.input.val('').trigger('change');
				}
			});

			// Window resize
			$(window).resize(function() {

				ws_this.signature_redraw(signature.signature, signature.canvas_element);
			});

			// Initial redraw
			ws_this.signature_redraw(signature.signature, signature.canvas_element, true);

			// Hide group if it was hidden originally
			if(!group_visible) {

				if(class_active) {

					group_obj.removeClass(class_active);

				} else {

					group_obj.hide();
				}
			}

			// Fire real time form validation
			this.form_validate_real_time_process(false);
		}
	}

	// Adds signature elements
	$.WS_Form.prototype.signature_redraw = function(signature, canvas_element, clear) {

		if(typeof(clear) === 'undefined') { clear = false; }

		// If the signature is empty, we'll clear it instead of drawing from data otherwise signature thinks it is not empty
		if(!clear && signature.isEmpty()) { clear = true; }

		// Remember canvas
		if(!clear) {

			var canvas_data = signature.toDataURL();
		}

		// Resize
		var ratio = Math.max(window.devicePixelRatio || 1, 1);
		canvas_element.width = canvas_element.offsetWidth * ratio;
		canvas_element.height = canvas_element.offsetHeight * ratio;
		canvas_element.getContext("2d").scale(ratio, ratio);

		// Redraw canvas using original data
		if(clear) {

			signature.clear();

		} else {

			signature.fromDataURL(canvas_data);
		}
	}

	// Signatures - Redraw on tab, section or field changes
	$.WS_Form.prototype.signatures_redraw = function(tab_index, section_id, field_id) {

		if(typeof(section_id) === 'undefined') { section_id = false; }
		if(typeof(field_id) === 'undefined') { field_id = false; }

		for(var signature_index in this.signatures) {

			if(!this.signatures.hasOwnProperty(signature_index)) { continue; }

			var signature = this.signatures[signature_index];

			// Skip if not yet initialized
			if(signature.signature === false) { continue; }

			var signature_canvas_element = signature.canvas_element;

			var signature_tab_index = this.get_group_index($(signature_canvas_element, this.form_canvas_obj));
			var signature_section_id = this.get_section_id($(signature_canvas_element, this.form_canvas_obj));
			var signature_field_id = this.get_field_id($(signature_canvas_element, this.form_canvas_obj));

			if(
				((tab_index !== false) && (signature_tab_index == tab_index)) ||
				((section_id !== false) && (section_id == signature_section_id)) ||
				(field_id == signature_field_id)
			) {
				this.signature_redraw(signature.signature, signature_canvas_element);
			}
		}
	}

	// Signature - Clear all signatures
	$.WS_Form.prototype.signatures_clear = function() {

		for(var signature_index in this.signatures) {

			if(!this.signatures.hasOwnProperty(signature_index)) { continue; }

			var signature = this.signatures[signature_index];

			signature.signature.clear();

			signature.input.val('').trigger('change');
		}
	}

	// Signature - Clear by name
	$.WS_Form.prototype.signature_clear_by_name = function(name) {

		var signature = (typeof(this.signatures_by_name[name]) !== 'undefined') ? this.signatures_by_name[name] : false;
		if(signature !== false) {

			signature.signature.clear();

			signature.input.val('').trigger('change');
		}
	}

	// Signature - Get response by name
	$.WS_Form.prototype.signature_get_response_by_name = function(name) {

		var signature = (typeof(this.signatures_by_name[name]) !== 'undefined') ? this.signatures_by_name[name] : false;
		return (signature !== false) ? (signature.input.val() !== '') : false;
	}

	// Adds recaptcha elements
	$.WS_Form.prototype.form_recaptcha = function() {

		var ws_this = this;

		// Get reCapture objects
		var recaptcha_objects = $('[data-recaptcha-type]', this.form_canvas_obj);
		var recaptcha_objects_count = recaptcha_objects.length;
		if(!recaptcha_objects_count) { return false;}

		// Should header script be loaded
		if(!$('#wsf-recaptcha-script-head').length) {

			var recaptcha_script_head = '<script id="wsf-recaptcha-script-head">';
			recaptcha_script_head += 'var wsf_recaptcha_loaded = false;';
			recaptcha_script_head += 'function wsf_recaptcha_onload() {';
			recaptcha_script_head += 'wsf_recaptcha_loaded = true;';
			recaptcha_script_head += '}';
			recaptcha_script_head += '</script>';

			$('head').append(recaptcha_script_head);
		}

		// Work out what type of reCAPTCHA should load
		var recaptcha_version = ($('[data-recaptcha-type="v3_default"]', this.form_canvas_obj).length) ? 3 : 2;

		// Should reCAPTCHA script be called?
		if(!window['___grecaptcha_cfg'] && !$('#wsf-recaptcha-script-body').length) {

			switch(recaptcha_version) {

				case 2 :

					var recaptcha_script_body = '<script id="wsf-recaptcha-script-body" src="https://www.google.com/recaptcha/api.js?onload=wsf_recaptcha_onload&render=explicit" async defer></script>';
					break;

				case 3 :

					var recaptcha_site_key = $('[data-recaptcha-type="v3_default"]', this.form_canvas_obj).eq(0).attr('data-site-key');
					var recaptcha_script_body = '<script id="wsf-recaptcha-script-body" src="https://www.google.com/recaptcha/api.js?onload=wsf_recaptcha_onload&render=' + recaptcha_site_key + '"></script>';
					break;
			}
			$('body').append(recaptcha_script_body);
		}

		// Reset reCaptcha arrays
		this.recaptchas = [];
		this.recaptchas_v2_default = [];
		this.recaptchas_v2_invisible = [];
		this.recaptchas_v3_default = [];

		recaptcha_objects.each(function() {

			// Name
			var name = $(this).attr('name');

			// ID
			var recaptcha_id = $(this).attr('id');
			if((recaptcha_id === undefined) || (recaptcha_id == '')) { return false; }

			// Site key
			var recaptcha_site_key = $(this).attr('data-site-key');
			if((recaptcha_site_key === undefined) || (recaptcha_site_key == '')) { return false; }

			// Recaptcha type
			var recaptcha_recaptcha_type = $(this).attr('data-recaptcha-type');
			if((recaptcha_recaptcha_type === undefined) || (['v2_default', 'v2_invisible', 'v3_default'].indexOf(recaptcha_recaptcha_type) == -1)) { recaptcha_recaptcha_type = 'default'; }

			// Type
			var recaptcha_type = $(this).attr('data-type');
			if((recaptcha_type === undefined) || (['image', 'audio'].indexOf(recaptcha_type) == -1)) { recaptcha_type = 'image'; }

			// Language (Optional)
			var recaptcha_language = $(this).attr('data-language');
			if(recaptcha_language === undefined) { recaptcha_language = ''; }

			// Type
			var recaptcha_action = $(this).attr('data-recaptcha-action');
			if((recaptcha_action === undefined) || (recaptcha_action == '')) { recaptcha_action = 'ws_form_loaded_#form_id'; }

			switch(recaptcha_recaptcha_type) {

				case 'v2_default' :

					// Size
					var recaptcha_size = $(this).attr('data-size');
					if((recaptcha_size === undefined) || (['normal', 'compact', 'invisible'].indexOf(recaptcha_size) == -1)) { recaptcha_size = 'normal'; }

					// Theme (Default only)
					var recaptcha_theme = $(this).attr('data-theme');
					if((recaptcha_theme === undefined) || (['light', 'dark'].indexOf(recaptcha_theme) == -1)) { recaptcha_theme = 'light'; }

					// Classes
					var class_recaptcha_invalid_label_array = ws_this.get_field_value_fallback('recaptcha', false, 'class_invalid_label', []);
					var class_recaptcha_invalid_field_array = ws_this.get_field_value_fallback('recaptcha', false, 'class_invalid_field', []);
					var class_recaptcha_invalid_invalid_feedback_array = ws_this.get_field_value_fallback('recaptcha', false, 'class_invalid_invalid_feedback', []);
					var class_recaptcha_valid_label_array = ws_this.get_field_value_fallback('recaptcha', false, 'class_valid_label', []);
					var class_recaptcha_valid_field_array = ws_this.get_field_value_fallback('recaptcha', false, 'class_valid_field', []);
					var class_recaptcha_valid_invalid_feedback_array = ws_this.get_field_value_fallback('recaptcha', false, 'class_valid_invalid_feedback', []);

					// Process recaptcha
					var recaptcha_obj_field = $(this);
					var recaptcha_obj_wrapper = recaptcha_obj_field.closest('[data-id]');
					var recaptcha_obj_label = $('label', recaptcha_obj_wrapper);
					var recaptcha_obj_invalid_feedback = $('#' + this.form_id_prefix + 'invalid-feedback-' + recaptcha_id, recaptcha_obj_wrapper, ws_this.form_canvas_obj);

					var config = {'sitekey': recaptcha_site_key, 'type': recaptcha_type, 'theme': recaptcha_theme, 'size': recaptcha_size, 'callback': function(token) {

						// Completed - Label
						recaptcha_obj_label.addClass(class_recaptcha_valid_label_array.join(' '));
						recaptcha_obj_label.removeClass(class_recaptcha_invalid_label_array.join(' '));

						// Completed - Field
						recaptcha_obj_field.addClass(class_recaptcha_valid_field_array.join(' '));
						recaptcha_obj_field.removeClass(class_recaptcha_invalid_field_array.join(' '));

						// Completed - Feedback
						recaptcha_obj_invalid_feedback.addClass(class_recaptcha_valid_invalid_feedback_array.join(' '));
						recaptcha_obj_invalid_feedback.removeClass(class_recaptcha_invalid_invalid_feedback_array.join(' '));

						// Run conditions
						for(var recaptcha_conditions_index in ws_this.recaptchas_conditions) {

							if(!ws_this.recaptchas_conditions.hasOwnProperty(recaptcha_conditions_index)) { continue; }

							ws_this.recaptchas_conditions[recaptcha_conditions_index]();
						}

						// Fire real time form validation
						ws_this.form_validate_real_time_process(false);

					}, 'expired-callback': function() {

						// Empty - Label
						recaptcha_obj_label.addClass(class_recaptcha_invalid_label_array.join(' '));
						recaptcha_obj_label.removeClass(class_recaptcha_valid_label_array.join(' '));

						// Empty - Field
						recaptcha_obj_field.addClass(class_recaptcha_invalid_field_array.join(' '));
						recaptcha_obj_field.removeClass(class_recaptcha_valid_field_array.join(' '));

						// Empty - Feedback
						recaptcha_obj_invalid_feedback.addClass(class_recaptcha_invalid_invalid_feedback_array.join(' '));
						recaptcha_obj_invalid_feedback.removeClass(class_recaptcha_valid_invalid_feedback_array.join(' '));

						// Run conditions
						for(var recaptcha_conditions_index in ws_this.recaptchas_conditions) {

							if(!ws_this.recaptchas_conditions.hasOwnProperty(recaptcha_conditions_index)) { continue; }

							ws_this.recaptchas_conditions[recaptcha_conditions_index]();
						}

						// Fire real time form validation
						ws_this.form_validate_real_time_process(false);

					}, 'error-callback': function() {

						// Empty - Label
						recaptcha_obj_label.addClass(class_recaptcha_invalid_label_array.join(' '));
						recaptcha_obj_label.removeClass(class_recaptcha_valid_label_array.join(' '));

						// Empty - Field
						recaptcha_obj_field.addClass(class_recaptcha_invalid_field_array.join(' '));
						recaptcha_obj_field.removeClass(class_recaptcha_valid_field_array.join(' '));

						// Empty - Feedback
						recaptcha_obj_invalid_feedback.addClass(class_recaptcha_invalid_invalid_feedback_array.join(' '));
						recaptcha_obj_invalid_feedback.removeClass(class_recaptcha_valid_invalid_feedback_array.join(' '));

						// Run conditions
						for(var recaptcha_conditions_index in ws_this.recaptchas_conditions) {

							if(!ws_this.recaptchas_conditions.hasOwnProperty(recaptcha_conditions_index)) { continue; }

							ws_this.recaptchas_conditions[recaptcha_conditions_index]();
						}

						// Fire real time form validation
						ws_this.form_validate_real_time_process(false);
					}};
					if(recaptcha_language != '') { config.hl = recaptcha_language; }

					// Build recaptcha object
					var recaptcha = {'id': false, 'recaptcha_site_key': recaptcha_site_key, 'name': name, 'recaptcha_id': recaptcha_id, 'config': config, 'recaptcha_recaptcha_type': recaptcha_recaptcha_type, 'type': 'v2_default'}

					// Add to recaptcha array
					ws_this.recaptchas_v2_default.push(recaptcha)

					ws_this.recaptcha_process(recaptcha);

					break;

				case 'v2_invisible' :

					// Badge (Invisible only)
					var recaptcha_badge = $(this).attr('data-badge');
					if((recaptcha_badge === undefined) || (['bottomright', 'bottomleft', 'inline'].indexOf(recaptcha_badge) == -1)) { recaptcha_badge = 'bottomright'; }

					// Process recaptcha
					var config = {'sitekey': recaptcha_site_key, 'badge': recaptcha_badge, 'size': 'invisible', 'callback': function() {

						// Run conditions
						for(var recaptcha_conditions_index in ws_this.recaptchas_conditions) {

							if(!ws_this.recaptchas_conditions.hasOwnProperty(recaptcha_conditions_index)) { continue; }

							ws_this.recaptchas_conditions[recaptcha_conditions_index]();
						}

						// Fire real time form validation
						ws_this.form_validate_real_time_process(false);

						// Form validated
						ws_this.form_post('submit');

					}, 'expired-callback': function() {

						// Run conditions
						for(var recaptcha_conditions_index in ws_this.recaptchas_conditions) {

							if(!ws_this.recaptchas_conditions.hasOwnProperty(recaptcha_conditions_index)) { continue; }

							ws_this.recaptchas_conditions[recaptcha_conditions_index]();
						}

						// Fire real time form validation
						ws_this.form_validate_real_time_process(false);

					}, 'error-callback': function() {

						// Throw error
						ws_this.error('error_recaptcha_v2_hidden');

						// Run conditions
						for(var recaptcha_conditions_index in ws_this.recaptchas_conditions) {

							if(!ws_this.recaptchas_conditions.hasOwnProperty(recaptcha_conditions_index)) { continue; }

							ws_this.recaptchas_conditions[recaptcha_conditions_index]();
						}

						// Fire real time form validation
						ws_this.form_validate_real_time_process(false);
					}};
					if(recaptcha_language != '') { config.hl = recaptcha_language; }

					// Build recaptcha object
					var recaptcha = {'id': false, 'recaptcha_site_key': recaptcha_site_key, 'name': name, 'recaptcha_id': recaptcha_id, 'config': config, 'recaptcha_recaptcha_type': recaptcha_recaptcha_type, 'type': 'v2_invisible'}

					// Add to recaptcha array
					ws_this.recaptchas_v2_invisible.push(recaptcha)

					// Process recaptcha
					ws_this.recaptcha_process(recaptcha);

					break;				

				case 'v3_default' :

					// Parse recaptcha_action
					recaptcha_action = ws_this.parse_variables_process(recaptcha_action).output;

					// Config
					var config = {'action': recaptcha_action};

					// Build recaptcha object
					var recaptcha = {'id': false, 'recaptcha_site_key': recaptcha_site_key, 'name': name, 'recaptcha_id': recaptcha_id, 'config': config, 'recaptcha_recaptcha_type': recaptcha_recaptcha_type, 'type': 'v3_default'}

					// Add to recaptcha array
					ws_this.recaptchas_v3_default.push(recaptcha)

					// Process recaptcha
					ws_this.recaptcha_process(recaptcha);

					break;
			}
		});
	}

	// Wait until reCAPTCHA loaded, then process
	$.WS_Form.prototype.recaptcha_process = function(recaptcha, total_ms_start) {

		var ws_this = this;

		// Timeout check
		if(typeof(total_ms_start) === 'undefined') { total_ms_start = new Date().getTime(); }
		if((new Date().getTime() - total_ms_start) > this.timeout_recaptcha) {

			this.error('error_timeout_recaptcha');
			return false;
		}

		// Check to see if reCAPTCHA loaded
		if(wsf_recaptcha_loaded) {

			switch(recaptcha.type) {

				case 'v2_default' :

					var id = grecaptcha.render(recaptcha.recaptcha_id, recaptcha.config);
					recaptcha.id = id;
					this.form_validate_real_time_process(false);
					break;

				case 'v2_invisible' :

					var id = grecaptcha.render(recaptcha.recaptcha_id, recaptcha.config);
					recaptcha.id = id;
					this.form_validate_real_time_process(false);
					break;

				case 'v3_default' :

					// Get site key
					var ws_this = this;

					// Initial action
					var id = grecaptcha.execute(recaptcha.recaptcha_site_key, recaptcha.config).then(function(token) {

						// Add hidden field
						if(!$('[data-recaptcha-response="' + recaptcha.recaptcha_id + '"]', ws_this.form_canvas_obj).length) {

							ws_this.form_add_hidden_input('g-recaptcha-response', token);
						}

						// Fire real time form validation
						ws_this.form_validate_real_time_process(false);

						// Log
						ws_this.log('log_recaptcha_v3_action_fired', recaptcha.config.action);
					});

					break;
			}

		} else {

			var ws_this = this;
			setTimeout(function() { ws_this.recaptcha_process(recaptcha, total_ms_start); }, this.timeout_interval);
		}
	}

	// reCAPTCHA V2 invisible execute
	$.WS_Form.prototype.recaptcha_v2_invisible_execute = function() {

		var ws_this = this;		

		// Run through each hidden captcha for this form
		for(var recaptchas_v2_invisible_index in this.recaptchas_v2_invisible) {

			if(!this.recaptchas_v2_invisible.hasOwnProperty(recaptchas_v2_invisible_index)) { continue; }

			// Get ID
			var recaptcha = this.recaptchas_v2_invisible[recaptchas_v2_invisible_index];
			var recaptcha_id = recaptcha.id;

			// Execute
			grecaptcha.execute(recaptcha_id);

			// Fire real time form validation
			ws_this.form_validate_real_time_process(false);
		}
	}

	// reCAPTCHA - Reset
	$.WS_Form.prototype.recaptcha_reset = function() {

		// Run through each reCAPTCHA for this form and reset it
		for(var recaptchas_index in this.recaptchas) {

			if(!this.recaptchas.hasOwnProperty(recaptchas_index)) { continue; }

			// Get ID
			var recaptcha = this.recaptchas[recaptchas_index];
			var recaptcha_id = recaptcha.id;

			// Reset
			grecaptcha.reset(recaptcha_id);
		}
	}

	// reCAPTCHA - Get response by name
	$.WS_Form.prototype.recaptcha_get_response_by_name = function(name) {

		// Run through each reCAPTCHA and look for name
		for(var recaptchas_index in this.recaptchas) {

			if(!this.recaptchas.hasOwnProperty(recaptchas_index)) { continue; }

			var recaptcha = this.recaptchas[recaptchas_index];

			// If name found, return response
			if(recaptcha.name == name) { return recaptcha.getResponse(recaptcha.id); }
		}

		return '';
	}

	// Legal
	$.WS_Form.prototype.form_legal = function() {

		var ws_this = this;

		$('[data-wsf-legal]', this.form_canvas_obj).each(function() {

			// Source
			var source = $(this).attr('data-wsf-legal-source');
			if(!source) { return; }

			switch(source) {

				// Termageddon
				case 'termageddon' :

					// Clear
					$(this).html('');

					// Read key
					var key = $(this).attr('data-wsf-termageddon-key');
					if(typeof(key) !== 'undefined') {

						// Read extra
						var extra = $(this).attr('data-wsf-termageddon-extra') ? '?' + $(this).attr('data-wsf-termageddon-extra') : '';

						// Set up object to populate
						var obj = $(this);

						// This code adapted from Termageddon's embed code
						var xhr = new XMLHttpRequest();
						xhr.onloadend = function() {

							switch(xhr.status) {

								case 200 :

									obj.html(xhr.responseText);
									break;

								case 404 :

									ws_this.error('error_termageddon_404');
									break;

								default :

									ws_this.error('error_termageddon');
							}
						}
						xhr.open('GET', 'https://app.termageddon.com/api/policy/' + key + extra);
						xhr.send();
					}

					break;
			}
		});
	}

	// Adds rating elements
	$.WS_Form.prototype.form_rating = function() {

		var ws_this = this;

		// Get skin spacing small
		var skin_spacing_small = ws_form_settings.skin_spacing_small;

		// Get rating objects
		$('[data-rating]:not([data-init-rating])', this.form_canvas_obj).each(function() {

			// Flag so it only initializes once
			$(this).attr('data-init-rating', '');

			// Get field wrapper
			var field_wrapper = ws_this.get_field_wrapper($(this));

			// Get field
			var field = ws_this.get_field($(this));

			// Read rating data
			var rating_max = parseInt(ws_this.get_object_meta_value(field, 'rating_max', '5'), 10);
			if(isNaN(rating_max)) { rating_max = 5; }
			if(rating_max < 1) { rating_max = 1; }

			// Read rating
			var rating_value = $(this).val();

			// Rating design
			var rating_icon = ws_this.get_object_meta_value(field, 'rating_icon', 'star');
			var rating_size = parseInt(ws_this.get_object_meta_value(field, 'rating_size', '24'), 10);
			if(isNaN(rating_size)) { rating_size = 24; }
			if(rating_size < 1) { rating_size = 1; }
			var rating_color_off = $(this).attr('data-rating-color-off');
			var rating_color_on = $(this).attr('data-rating-color-on');

			// Read only
			var readonly = (typeof($(this).attr('readonly')) !== 'undefined');

			// Build rating icon HTML
			if(rating_icon != 'custom') {

				var rating_icon_html = '<svg class="wsf-rating-icon" height="' + rating_size + '" width="' + rating_size + '" viewBox="0 0 16 16" style="display: block; height: auto; max-width: 100%;">';

				switch(rating_icon) {

					// Heart
					case 'heart' :

						rating_icon_html += '<path d="M7.4,13.6c-0.3-0.4-1.2-1.1-1.9-1.7c-2.1-1.6-2.4-1.8-3.2-2.6C0.7,7.9,0,6.4,0,4.5 c0-1,0.1-1.3,0.3-1.9c0.5-1,1.1-1.7,2-2.1C2.9,0.1,3.2,0,4.2,0c1.1,0,1.3,0.1,1.9,0.5c0.8,0.4,1.5,1.3,1.7,1.9L8,2.8l0.2-0.5 c1.4-3,5.8-3,7.4,0.1c0.5,1,0.5,3.1,0.1,4.2c-0.6,1.5-1.6,2.7-4.1,4.5C10,12.2,8.2,14,8,14.3C7.9,14.6,8,14.3,7.4,13.6z" fill="' + rating_color_off + '" />';
						break;

					// Check
					case 'check' :

						rating_icon_html += '<path d="M7.3 14.2l-7.1-5.2 1.7-2.4 4.8 3.5 6.6-8.5 2.3 1.8z" fill="' + rating_color_off + '" />';
						break;

					// Circle
					case 'circle' :

						rating_icon_html += '<path d="M0,8a8,8 0 1,0 16,0a8,8 0 1,0 -16,0" fill="' + rating_color_off + '" />';
						break;

					// Flag
					case 'flag' :

						rating_icon_html += '<path d="M11.8 1.2s-2.7 1.3-5.3.3C3.6.5 2.3.9 1 2.5c-.2-.1-.5-.1-.7 0-.3.2-.4.6-.2.9l7.1 11.5c.1.2.4.3.6.3.1 0 .2 0 .4-.1.3-.2.4-.6.2-1l-3.2-5c1.2-1.5 2.6-1.9 5.4-.9 2.7.9 5.4-.4 5.4-.4l-4.2-6.6z" fill="' + rating_color_off + '" />';
						break;

					// Smiley
					case 'smiley' :

						rating_icon_html += '<path d="M8 16c4.4 0 8-3.6 8-8s-3.6-8-8-8-8 3.6-8 8 3.6 8 8 8zM8 1.5c3.6 0 6.5 2.9 6.5 6.5s-2.9 6.5-6.5 6.5S1.5 11.6 1.5 8 4.4 1.5 8 1.5zM4.6 5.6c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1-1-.5-1-1zm4.5 0c0-.6.4-1 1-1s1 .4 1 1-.4 1-1 1-1-.5-1-1zM11 9.3l1.3.8c-.9 1.5-2.5 2.4-4.3 2.4s-3.4-1-4.3-2.4L5 9.3c.6 1 1.7 1.7 3 1.7s2.4-.6 3-1.7z" fill="' + rating_color_off + '" />';
						break;

					// Square
					case 'square' :

						rating_icon_html += '<path d="M0 0h16v16H0z" fill="' + rating_color_off + '" />';
						break;

					// Thumb
					case 'thumb' :

						rating_icon_html += '<path d="M13.9 9.9c0 .7-.7 1.2-1.4 1.2.5.1 1.2.7 1.2 1.4s-.7 1.1-1.3 1.1h-.6c.5.1 1.1.8 1.1 1.4 0 .7-.7 1.1-1.4 1.1h-6c-2 0-3.5-1.6-3.5-3.6V8.7c0-1.4.8-2.9 2-3.3.9-.6 2.8-1.7 3.2-3.8V.1s2.6-.3 2.6 2.2c0 2.9-1.8 3.4-.4 3.5h2.2c.8 0 1.4.8 1.4 1.5s-.6 1.1-1.2 1.2h.6c.9 0 1.5.7 1.5 1.4z" fill="' + rating_color_off + '" />';
						break;

					// Star
					default :

						rating_icon_html += '<path d="M12.9 15.8c-1.6-1.2-3.2-2.5-4.9-3.7-1.6 1.3-3.3 2.5-4.9 3.7 0 0-.1 0-.1-.1.6-2 1.2-4 1.9-6C3.3 8.4 1.7 7.2 0 5.9h6C6.7 3.9 7.3 2 8 0h.1c.7 1.9 1.3 3.9 2 5.9H16V6c-1.6 1.3-3.2 2.5-4.9 3.8.6 1.9 1.3 3.9 1.8 6 .1-.1 0 0 0 0z" fill="' + rating_color_off + '" />';
						break;
				}

				rating_icon_html += '</svg>';

			} else {

				var rating_icon_html = ws_this.get_object_meta_value(field, 'rating_icon_html', '<span>*</span>');
			}

			// Read horizontal alignment
			var rating_horizontal_align = ws_this.get_object_meta_value(field, 'horizontal_align', 'left');

			// Build rating HTML
			var rating_html = '<div class="wsf-rating-wrapper" tabindex="0" style="outline:0;"><ul class="wsf-rating" style="display: flex; list-style: none; margin: 0; padding: 0; user-select: none; justify-content: ' + rating_horizontal_align + '">';

			for(var rating_index = 1; rating_index <= rating_max; rating_index++) {

				rating_html += '<li class="wsf-rating-' + rating_index + ((rating_index <= rating_value) ? ' wsf-rating-selected' : '') + '" style="' + (!readonly ? 'cursor: pointer; ' : '') + 'display:inline-block; -webkit-padding-end: ' + skin_spacing_small + 'px; padding-inline-end: ' + skin_spacing_small + 'px; margin: 0;" data-value="' + rating_index + '" title="' + rating_index + '">' + rating_icon_html + '</li>';
			}

			rating_html += '</ul></div>';

			// Add to field
			$(this).after(rating_html);

			// Init
			$('ul.wsf-rating > li', field_wrapper).each(function(e) {

				$('svg.wsf-rating-icon path', $(this)).attr('fill', $(this).hasClass('wsf-rating-selected') ? rating_color_on : rating_color_off);
			});

			// Change to hidden input
			$(this).on('change input', function() {

				ws_this.form_rating_process($(this), Math.round(parseFloat($(this).val(), 10), 0));
			});

			var rating_input = $(this);

			// Only add event handlers if not read only
			if(!readonly) {

				// Event handlers
				$('.wsf-rating-wrapper', field_wrapper).on('keydown', function(e) {

					if(e.keyCode == 39) {

						e.preventDefault();

						var rating_current = rating_input.val();

						if(rating_current < rating_max) {
	
							rating_input.val(++rating_current).trigger('change');
						}
					}

					if(e.keyCode == 37) {

						e.preventDefault();

						var rating_current = rating_input.val();

						if(rating_current > 0) {
	
							rating_input.val(--rating_current).trigger('change');
						}
					}
				});

				$('ul.wsf-rating > li', field_wrapper).on('click touchstart', function() {

					var rating_obj = $('[data-rating]', $(this).closest('[data-id]'));

					var rating_index = parseInt($(this).attr('data-value'), 10); 

					// Set rating
					rating_obj.val(rating_index).attr('data-value-old', rating_index).trigger('change');
				});

				$('ul.wsf-rating > li', field_wrapper).on('mouseover', function() {

					var rating_obj = $('[data-rating]', $(this).closest('[data-id]'));
					var rating_color_off = rating_obj.attr('data-rating-color-off');
					var rating_color_on = rating_obj.attr('data-rating-color-on');

					// Store old value
					rating_obj.attr('data-value-old', rating_obj.val());

					// Get new value
					var rating_value = Math.round(parseFloat($(this).attr('data-value'), 10), 0); 

					// Store new value
					rating_obj.val(rating_value).trigger('input');

					// Now highlight all the stars that's not after the current hovered star
					$(this).parent().children('li').each(function(e) {
		
						if (e < rating_value) {

							$(this).addClass('wsf-rating-hover');
							$('svg.wsf-rating-icon path', $(this)).attr('fill', rating_color_on);

						} else {

							$(this).removeClass('wsf-rating-hover');
							$('svg.wsf-rating-icon path', $(this)).attr('fill', rating_color_off);
						}

					})

				}).on('mouseout', function() {

					var rating_obj = $('[data-rating]', $(this).closest('[data-id]'));

					// If an old value is set, reset it
					if(typeof(rating_obj.attr('data-value-old')) !== 'undefined') {

						var rating_value_old = rating_obj.attr('data-value-old');
						rating_obj.val(rating_value_old).trigger('input');
					}

					$(this).parent().children('li').each(function(e) {

						$(this).removeClass('wsf-rating-hover');

						$('svg.wsf-rating-icon path', $(this)).attr('fill', $(this).hasClass('wsf-rating-selected') ? rating_color_on : rating_color_off);
					});
				});
			}
		});
	}

	// Rating process
	$.WS_Form.prototype.form_rating_process = function(rating_obj, rating_index) {

		var rating_color_off = rating_obj.attr('data-rating-color-off');
		var rating_color_on = rating_obj.attr('data-rating-color-on');

		// Now highlight all the stars that's not after the current hovered star
		$('ul li', rating_obj.parent()).each(function(e) {

			if (e < rating_index) {

				$(this).addClass('wsf-rating-selected');
				$('svg.wsf-rating-icon path', $(this)).attr('fill', rating_color_on);

			} else {

				$(this).removeClass('wsf-rating-selected');
				$('svg.wsf-rating-icon path', $(this)).attr('fill', rating_color_off);
			}
		});
	}

	// Adds Google Map
	$.WS_Form.prototype.form_google_map = function() {

		var ws_this = this;

		// Get Google Map objects
		var google_map_objects = $('[data-google-map]:not([data-init-google-map])', this.form_canvas_obj);
		var google_map_objects_count = google_map_objects.length;
		if(!google_map_objects_count) { return false;}

		// Should header script be loaded
		if(!$('#wsf-google-map-script-head').length) {

			var google_map_script_head = '<script id="wsf-google-map-script-head">';
			google_map_script_head += 'var wsf_google_maps_loaded = false;';
			google_map_script_head += 'function wsf_google_map_onload() {';
			google_map_script_head += 'wsf_google_maps_loaded = true;';
			google_map_script_head += '}';
			google_map_script_head += '</script>';

			$('head').append(google_map_script_head);
		}

		// Should Google Maps script be called?
		if(!(window.google && window.google.maps) && !$('#wsf-google-map-script-body').length) {

			// Get Google Maps JS API key
			var api_key_google_map = $.WS_Form.settings_plugin.api_key_google_map;
			var google_map_script_body = '<script id="wsf-google-map-script-body" src="https://maps.googleapis.com/maps/api/js?key=' + api_key_google_map + '&callback=wsf_google_map_onload&libraries=places&v=weekly" async defer></script>';
			$('body').append(google_map_script_body);
		}

		// Reset Google Maps arrays
		this.google_maps = [];

		google_map_objects.each(function() {

			$(this).attr('data-init-google-map', '');

			// Get field ID
			var field_id = ws_this.get_field_id($(this));

			// Get field object
			var field = ws_this.get_field($(this));

			// Build google_map object
			var google_map = {};

			// ID
			google_map.id = $(this).attr('id');

			// Map ID
			google_map.id_map = google_map.id + '-map';

			// $(this)
			google_map.obj = $(this);

			// Map obj
			google_map.obj_map = $('#' + google_map.id_map, ws_this.form_canvas_obj);

			// Height
			google_map.height = ws_this.parse_variables_process(ws_this.get_object_meta_value(field, 'google_map_height', '')).output;
			if(google_map.height) {

				google_map.obj_map.css({

					'height': 0,
					'overflow': 'hidden',
					'padding-bottom': google_map.height,
					'position': 'relative'
				});
			}

			// Latitude
			google_map.lat = ws_this.parse_variables_process(ws_this.get_object_meta_value(field, 'google_map_lat', '')).output;

			// Longitude
			google_map.lng = ws_this.parse_variables_process(ws_this.get_object_meta_value(field, 'google_map_lng', '')).output;

			// Zoom
			google_map.zoom = ws_this.parse_variables_process(ws_this.get_object_meta_value(field, 'google_map_zoom', '')).output;
			if(google_map.zoom) {

				google_map.zoom = parseInt(google_map.zoom);

			} else {

				google_map.zoom = 14;
			}

			// Type
			google_map.type = ws_this.get_object_meta_value(field, 'google_map_type', '');
			if(!google_map.type) {

				google_map.type = 'roadmap';
			}

			// Search field ID
			google_map.search_field_id = parseInt(ws_this.get_object_meta_value(field, 'google_map_search_field_id', 0));

			// Marker - Title
			google_map.marker_icon_title = ws_this.parse_variables_process(ws_this.get_object_meta_value(field, 'google_map_marker_icon_title', '')).output;

			// Marker - Icon
			google_map.marker_icon_url = ws_this.parse_variables_process(ws_this.get_object_meta_value(field, 'google_map_marker_icon_url', '')).output;

			// Style
			google_map.style = ws_this.parse_variables_process(ws_this.get_object_meta_value(field, 'google_map_style', '')).output;

			// Controls
			google_map.control_type = (ws_this.get_object_meta_value(field, 'google_map_control_type', 'on') !== '');
			google_map.control_full_screen = (ws_this.get_object_meta_value(field, 'google_map_control_full_screen', 'on') !== '');
			google_map.control_street_view = (ws_this.get_object_meta_value(field, 'google_map_control_street_view', 'on') !== '');
			google_map.control_zoom = (ws_this.get_object_meta_value(field, 'google_map_control_zoom', 'on') !== '');

			// Add to google_map array
			ws_this.google_maps.push(google_map)

			ws_this.google_map_process(google_map);
		});
	}

	// Wait until Google Maps loaded, then process
	$.WS_Form.prototype.google_map_process = function(google_map, total_ms_start) {

		var ws_this = this;

		// Timeout check
		if(typeof(total_ms_start) === 'undefined') { total_ms_start = new Date().getTime(); }
		if((new Date().getTime() - total_ms_start) > this.timeout_google_maps) {

			this.error('error_timeout_google_maps');
			return false;
		}

		if(window.google && window.google.maps) {

			wsf_google_maps_loaded = true;
		}

		// Check to see if Google Maps loaded
		if(wsf_google_maps_loaded) {

			// Save default value
			google_map.obj.attr('data-default-value', google_map.obj.val());

			// Geocoder
			google_map.geocoder = new google.maps.Geocoder();

			// Height
			if(google_map.height) {

				google_map.obj_map.css({

					'height': 0,
					'overflow': 'hidden',
					'padding-bottom': google_map.height,
					'position': 'relative'
				});
			}

			// Run geolocator
			google_map.geolocate_process = function(position) {

				// Geocoder
				if(google_map.search_field_obj) {

					google_map.geocoder.geocode({ location: position }, function(results, status) {

						if(
							(status === 'OK') &&
							results[0]
						) {

							google_map.search_field_obj.val(results[0].formatted_address);
							google_map.marker_set_position(position,results[0]);

						} else {

							google_map.search_field_obj.val('');
							google_map.marker_set_position(position);
						}
					});
				}
			}

			// Set field value
			google_map.set_field_value = function(field_value_obj) {

				// Build latitude,longitude string
				var field_value = JSON.stringify(field_value_obj);

				// Set hidden value
				var trigger = (google_map.obj.val() !== field_value);
				google_map.obj.val(field_value);
				if(trigger) { google_map.obj.trigger('change'); }
			}

			// Marker position function
			google_map.marker_set_position = function(position, place) {

				// Get latitude and longitude
				var latitude = position.lat();
				var longitude = position.lng();

				var field_value_obj = {

					'lat': latitude,
					'lng': longitude,
					'zoom' : google_map.map.getZoom(),
					'map_type_id' : google_map.map.getMapTypeId(),
				}

				if(typeof(place) !== 'undefined') {

					// Place ID
					field_value_obj.place_id = (typeof(place.place_id) ? place.place_id : '');

					// Address
					field_value_obj.address = (typeof(place.formatted_address) ? place.formatted_address : '');

					// Name
					field_value_obj.name = (typeof(place.name) ? place.name : '');

					if(typeof(place.address_components) !== 'undefined') {

						place.address_components.forEach(function(address_component) {

							var types = address_component.types;

							// City
							if(types.indexOf('locality') !== -1) { field_value_obj.city = address_component.long_name; }

							// State
							if(types.indexOf('administrative_area_level_1') !== -1) { field_value_obj.city = address_component.long_name; }

							// Country Short / Long
							if(types.indexOf('country') !== -1) {

								field_value_obj.country = address_component.long_name;
								field_value_obj.country_short = address_component.short_name;
							}
						});
					}
				}

				google_map.set_field_value(field_value_obj);
			}

			// On change event
			google_map.obj.on('change', function() {

				var marker_visible = false;

				var field_value = $(this).val();

				try {

					// Check for regular format
					var field_value_obj = JSON.parse(field_value);

				} catch (e) {

					// Support for comma separated values
					var field_value_array = field_value.split(',');

					if(field_value_array.length === 2) {

						var field_value_obj = {

							lat: field_value_array[0],
							lng: field_value_array[1]
						};

						if(typeof(field_value_array[2]) !== 'undefined') {

							field_value_obj.zoom = field_value_array[2]
						}

						if(typeof(field_value_array[3]) !== 'undefined') {

							field_value_obj.map_type_id = field_value_array[3]
						}

						$(this).val(JSON.stringify(field_value_obj));

						google_map.geolocate_process(new google.maps.LatLng(parseFloat(field_value_obj.lat), parseFloat(field_value_obj.lng)));

					} else {

						var field_value_obj = false;
					}
				}

				if(field_value_obj !== false) {

					var position = new google.maps.LatLng(parseFloat(field_value_obj.lat), parseFloat(field_value_obj.lng));
					marker_visible = true;

					// Populate address
					if(
						google_map.search_field_obj &&
						field_value_obj.address &&
						(field_value_obj.address != google_map.search_field_obj.val())
					) {

						google_map.search_field_obj.val(field_value_obj.address);
					}

					// Set zoom
					if(
						field_value_obj.zoom &&
						(field_value_obj.zoom != google_map.map.getZoom())
					) {

						google_map.map.setZoom(field_value_obj.zoom);
					}

					// Set map type ID
					if(
						field_value_obj.map_type_id &&
						(field_value_obj.map_type_id != google_map.map.getMapTypeId())
					) {

						google_map.map.setMapTypeId(field_value_obj.map_type_id);
					}

				} else {

					if(google_map.lat && google_map.lng) {

						var position = new google.maps.LatLng(parseFloat(google_map.lat), parseFloat(google_map.lng));

					} else {

						var position = new google.maps.LatLng(29.95, -90.08);	// Fallback to New Orleans, LA
					}

					// Reset zoom
					google_map.map.setZoom(google_map.zoom);

					// Reset type
					google_map.map.setMapTypeId(google_map.type);
				}

				// Move the marker
				google_map.marker.setPosition(position);
				google_map.marker.setVisible(marker_visible);

				// Move map
				google_map.map.setCenter(position);
			});

			// Default options
			var options = {

				id: google_map.id_map,
				zoom: google_map.zoom,
				mapTypeId: google_map.type,
				clickableIcons: false,
				gestureHandling: 'cooperative',
				mapTypeControl: google_map.control_type,
				fullscreenControl: google_map.control_full_screen,
				streetViewControl: google_map.control_street_view,
				zoomControl: google_map.control_zoom
			};

			if(google_map.style) {

				try {

					options.styles = JSON.parse(google_map.style);

				} catch(e) {

					this.error('error_google_map_style_js');
				}
			}

			// Create map
			var map = new google.maps.Map(google_map.obj_map[0], options);
			google_map.map = map;

			// On zoom changed event
			google_map.map.addListener('zoom_changed', function() {

				var field_value = google_map.obj.val();
				if(field_value == '') { return; }

				try {

					// Check for regular format
					var field_value_obj = JSON.parse(field_value);

				} catch (e) { return; }

				if(typeof(field_value_obj) === 'object') {

					field_value_obj.zoom = google_map.map.getZoom();
					google_map.set_field_value(field_value_obj);
				}
			});

			// On map type change
			google_map.map.addListener('maptypeid_changed', function() {

				var field_value = google_map.obj.val();
				if(field_value == '') { return; }

				try {

					// Check for regular format
					var field_value_obj = JSON.parse(field_value);

				} catch (e) { return; }

				if(typeof(field_value_obj) === 'object') {

					field_value_obj.map_type_id = google_map.map.getMapTypeId();
					google_map.set_field_value(field_value_obj);
				}
			});


			// Map click event handler
			google_map.map.addListener('click', function(e) {

				google_map.marker_set_position(e.latLng);

				google_map.geolocate_process(e.latLng);
			});

			// Build map marker options
			var options_marker = {

				map: map,
				visible: false
			};

			// Marker - Icon
			if(google_map.marker_icon_url) {

				if(typeof(options_marker.icon) === 'undefined') { options_marker.icon = {}; }
				options_marker.icon.url = google_map.marker_icon_url;
			}

			// Marker - Title
			if(google_map.marker_icon_title) {

				options_marker.title = google_map.marker_icon_title;
			}

			// Add marker
			google_map.marker = new google.maps.Marker(options_marker);

			// Clear event
			google_map.obj.parent().find('[data-action="wsf-google-map-clear"]').on('click', function(e) {

				e.preventDefault();

				google_map.obj.val('').trigger('change');
			});

			// Search field ID
			if(google_map.search_field_id) {

				// Get section repeatable index
				var section_repeatable_suffix = ws_this.get_section_repeatable_suffix(google_map.obj);

				// Get search input
				var field_id = parseInt(google_map.search_field_id);
				var search_field_obj = $('[id^="' + ws_this.form_id_prefix + 'field-' + field_id + section_repeatable_suffix + '"]', ws_this.form_canvas_obj);
				if(section_repeatable_suffix && !search_field_obj.length) {

					// Check outside of repeater
					var search_field_obj = $('[id^="' + ws_this.form_id_prefix + 'field-' + field_id + '"]', ws_this.form_canvas_obj);
				}
				if(search_field_obj.length) {

					google_map.search_field_obj = search_field_obj;

					// Set up search box
					var search_field_element = search_field_obj[0];
					google_map.search_box = new google.maps.places.SearchBox(search_field_element);

					google_map.map.addListener('bounds_changed', function() {

						google_map.search_box.setBounds(google_map.map.getBounds());
					});

					google_map.search_box.addListener('places_changed', function() {

						var places = google_map.search_box.getPlaces();

						if(places.length == 0) { return; }

						places.forEach(function(place) {

							if(!place.geometry) { return; }

							google_map.marker_set_position(place.geometry.location, place);

							if(place.geometry.viewport) {

								google_map.map.fitBounds(place.geometry.viewport);
							}
						});
					});
				}
			}

			// Initial change
			google_map.obj.trigger('change');

		} else {

			var ws_this = this;
			setTimeout(function() { ws_this.google_map_process(google_map, total_ms_start); }, this.timeout_interval);
		}
	}

	// Adds required string (if found in framework config) to all labels
	$.WS_Form.prototype.form_required = function() {

		var ws_this = this;

		// Get required label HTML
		var label_required = this.get_object_meta_value(this.form, 'label_required', false);
		if(!label_required) { return false; }

		var label_mask_required = this.get_object_meta_value(this.form, 'label_mask_required', '', true, true);
		if(label_mask_required == '') {

			// Use framework mask_required_label
			var framework_type = $.WS_Form.settings_plugin.framework;
			var framework = $.WS_Form.frameworks.types[framework_type];
			var fields = this.framework['fields']['public'];

			if(typeof(fields.mask_required_label) === 'undefined') { return false; }
			var label_mask_required = fields.mask_required_label;
			if(label_mask_required == '') { return false; }
		}

		// Get all labels in this form
		$('label', this.form_canvas_obj).each(function() {

			// Get 'for' attribute of label
			var label_for = $(this).attr('for');
			if(label_for === undefined) { return; }

			// Get field related to 'for'
			var field_obj = $('[id="' + label_for + '"]', ws_this.form_canvas_obj);
			if(!field_obj.length) { return; }

			// Check if field should be processed
			if(typeof(field_obj.attr('data-init-required')) !== 'undefined') { return; }

			// Check if field is required
			var field_required = (typeof(field_obj.attr('data-required')) !== 'undefined');

			// Check if the require string should be added to the parent label (e.g. for radios)
			var label_required_id = $(this).attr('data-label-required-id');
			if((typeof(label_required_id) !== 'undefined') && (label_required_id !== false)) {

				var label_obj = $('#' + label_required_id, ws_this.form_canvas_obj);

			} else {

				var label_obj = $(this);
			}

			// Check if wsf-required-wrapper span exists, if not, create it (You can manually insert it in config using #required)
			var required_wrapper = $('.wsf-required-wrapper', label_obj);
			if(!required_wrapper.length && field_required) {

				var required_wrapper_html = '<span class="wsf-required-wrapper"></span>';

				// If field is wrapped in label, find the first the first element to inject the required wrapper before
				var first_child = label_obj.children('div,[name]').first();

				// Add at appropriate place
				if(first_child.length) {

					first_child.before(required_wrapper_html);

				} else {

					label_obj.append(required_wrapper_html);
				}

				required_wrapper = $('.wsf-required-wrapper', label_obj);
			}

			if(field_required) {

				// Add it
				required_wrapper.html(label_mask_required);
				field_obj.attr('data-init-required', '');

			} else {

				// Remove it
				required_wrapper.html('');
				field_obj.removeAttr('data-init-required');
			}
		});
	}

	// Field required bypass
	$.WS_Form.prototype.form_bypass = function(conditional_initiated) {

		if(!this.form_bypass_enabled) { return; }

		var ws_this = this;

		// Process attributes that should be bypassed if a field is hidden
		var attributes = {

			'required':						{'bypass': 'data-required-bypass', 'not': '[type="hidden"]'},
			'aria-required':				{'bypass': 'data-aria-required-bypass', 'not': '[type="hidden"]'},
			'min':							{'bypass': 'data-min-bypass', 'not': '[type="hidden"],[type="range"]'},
			'max':							{'bypass': 'data-max-bypass', 'not': '[type="hidden"],[type="range"]'},
			'minlength':					{'bypass': 'data-minlength-bypass', 'not': '[type="hidden"]'},
			'maxlength':					{'bypass': 'data-maxlength-bypass', 'not': '[type="hidden"]'},
			'pattern':						{'bypass': 'data-pattern-bypass', 'not': '[type="hidden"]'},
			'step':							{'bypass': 'data-step-bypass', 'not': '[type="hidden"],[type="range"]', 'replace': 'any'},
			'data-ecommerce-price':			{'bypass': 'data-ecommerce-price-bypass', 'not': '[data-ecommerce-persist]'},
			'data-ecommerce-cart-price':	{'bypass': 'data-ecommerce-cart-price-bypass', 'not': '[data-ecommerce-persist]'}
		};

		for(var attribute_source in attributes) {

			if(!attributes.hasOwnProperty(attribute_source)) { continue; }

			var attribute_config = attributes[attribute_source];

			var attribute_bypass = attribute_config.bypass;
			var attribute_not = attribute_config.not;
			var attribute_replace = (typeof(attribute_config.replace) !== 'undefined') ? attribute_config.replace : false;

			// If a group is visible, and contains fields that have a data bypass attribute, reset that attribute
			if($('[' + attribute_bypass + '-group]', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'group-"]:not([data-wsf-group-hidden]) [' + attribute_bypass + '-group]:not(' + attribute_not + ')', this.form_canvas_obj).attr(attribute_source, function() { return $(this).attr(attribute_bypass + '-group'); }).removeAttr(attribute_bypass + '-group');
			}

			// If a group is not visible, and contains validation attributes, add bypass attributes
			if($('[' + attribute_source + ']', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'group-"][data-wsf-group-hidden] [' + attribute_source + ']:not(' + attribute_not + '), [id^="' + this.form_id_prefix + 'group-"][data-wsf-group-hidden] [' + attribute_source + ']:not(' + attribute_not + ')').attr(attribute_bypass + '-group', function() { var attribute_source_value = $(this).attr(attribute_source); if(attribute_replace) { $(this).attr(attribute_source, attribute_replace); } else { $(this).removeAttr(attribute_source); } return attribute_source_value; });
			}

			// If a hidden field is in a hidden group, convert bypass address to group level
			if($('[' + attribute_bypass + ']', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'group-"][data-wsf-group-hidden] [' + attribute_bypass + ']:not(' + attribute_not + '), [id^="' + this.form_id_prefix + 'group-"][data-wsf-group-hidden] [' + attribute_bypass + ']:not(' + attribute_not + ')').attr(attribute_bypass + '-group', function() { return $(this).attr(attribute_bypass); }).removeAttr(attribute_bypass);
			}


			// If a section is visible, and contains fields that have a data bypass attribute, reset that attribute
			if($('[' + attribute_bypass + '-section]', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'section-"][style!="display:none;"][style!="display: none;"] [' + attribute_bypass + '-section]:not(' + attribute_not + ')', this.form_canvas_obj).attr(attribute_source, function() { return $(this).attr(attribute_bypass + '-section'); }).removeAttr(attribute_bypass + '-section');
			}

			// If a section is not visible, and contains validation attributes, add bypass attributes
			if($('[' + attribute_source + ']', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'section-"][style="display:none;"] [' + attribute_source + ']:not(' + attribute_not + '), [id^="' + this.form_id_prefix + 'section-"][style="display: none;"] [' + attribute_source + ']:not(' + attribute_not + ')').attr(attribute_bypass + '-section', function() { var attribute_source_value = $(this).attr(attribute_source); if(attribute_replace) { $(this).attr(attribute_source, attribute_replace); } else { $(this).removeAttr(attribute_source); } return attribute_source_value; });
			}

			// If a hidden field is in a hidden section, convert bypass address to section level
			if($('[' + attribute_bypass + ']', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'section-"][style="display:none;"] [' + attribute_bypass + ']:not(' + attribute_not + '), [id^="' + this.form_id_prefix + 'section-"][style="display: none;"] [' + attribute_bypass + ']:not(' + attribute_not + ')').attr(attribute_bypass + '-section', function() { return $(this).attr(attribute_bypass); }).removeAttr(attribute_bypass);
			}


			// If field is visible, add validation attributes back that have a bypass data tag
			if($('[' + attribute_bypass + ']', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'field-wrapper-"][style!="display:none;"][style!="display: none;"] [' + attribute_bypass + ']:not(' + attribute_not + ')', this.form_canvas_obj).attr(attribute_source, function() { return $(this).attr(attribute_bypass); }).removeAttr(attribute_bypass);
			}

			// If field is not visible, add contain validation attributes, add bypass attributes
			if($('[' + attribute_source + ']', this.form_canvas_obj).length) {

				$('[id^="' + this.form_id_prefix + 'field-wrapper-"][style="display:none;"] [' + attribute_source + ']:not(' + attribute_not + '), [id^="' + this.form_id_prefix + 'field-wrapper-"][style="display: none;"] [' + attribute_source + ']:not(' + attribute_not + ')', this.form_canvas_obj).attr(attribute_bypass, function() { var attribute_source_value = $(this).attr(attribute_source); if(attribute_replace) { $(this).attr(attribute_source, attribute_replace); } else { $(this).removeAttr(attribute_source) } return attribute_source_value; });
			}
		}

		// Process custom validity messages - Groups
		$('[id^="' + this.form_id_prefix + 'group-"]:not([data-wsf-group-hidden])', this.form_canvas_obj).find('[name]:not([type="hidden"]),[data-static],[data-recaptcha-type]').each(function() {

			ws_this.form_bypass_process($(this), '-group', false);
		});

		$('[id^="' + this.form_id_prefix + 'group-"][data-wsf-group-hidden]').find('[name]:not([type="hidden"]),[data-static],[data-recaptcha-type]').each(function() {

			ws_this.form_bypass_process($(this), '-group', true);
		});

		// Process custom validity messages - Sections
		$('[id^="' + this.form_id_prefix + 'section-"][style!="display:none;"][style!="display: none;"]', this.form_canvas_obj).find('[name]:not([type="hidden"],[data-hidden-group]),[data-static],[data-recaptcha-type]').each(function() {

			ws_this.form_bypass_process($(this), '-section', false);
		});

		$('[id^="' + this.form_id_prefix + 'section-"][style="display:none;"], [id^="' + this.form_id_prefix + 'section-"][style="display: none;"]').find('[name]:not([type="hidden"]),[data-static],[data-recaptcha-type]').each(function() {

			ws_this.form_bypass_process($(this), '-section', true);
		});

		// Process custom validity messages - Fields
		$('[id^="' + this.form_id_prefix + 'field-wrapper-"][style!="display:none;"][style!="display: none;"]', this.form_canvas_obj).find('[name]:not([type="hidden"],[data-hidden-section],[data-hidden-group]),[data-static],[data-recaptcha-type]').each(function() {

			ws_this.form_bypass_process($(this), '', false);
		});

		$('[id^="' + this.form_id_prefix + 'field-wrapper-"][style="display:none;"], [id^="' + this.form_id_prefix + 'field-wrapper-"][style="display: none;"]', this.form_canvas_obj).find('[name]:not([type="hidden"]),[data-static],[data-recaptcha-type]').each(function() {

			ws_this.form_bypass_process($(this), '', true);
		});

		// Process form progress
		this.form_progress_process();

		// Recalculate e-commerce
		if(ws_this.has_ecommerce) { ws_this.form_ecommerce_calculate(); }

		// Fire real time form validation
		this.form_validate_real_time_process(conditional_initiated);
	}

	// Form bypass process
	$.WS_Form.prototype.form_bypass_process = function(obj, attr_suffix, set) {

		if(!obj[0].willValidate) { return; }

		var section_id = this.get_section_id(obj);
		var section_repeatable_index = this.get_section_repeatable_index(obj);
		var field_id = this.get_field_id(obj);
	
		if(set) {

			var validation_message = obj[0].validationMessage;

			if(validation_message !== '') {

				if(typeof(this.validation_message_cache[section_id]) === 'undefined') { this.validation_message_cache[section_id] = []; }
				if(typeof(this.validation_message_cache[section_id][section_repeatable_index]) === 'undefined') { this.validation_message_cache[section_id][section_repeatable_index] = []; }
				if(typeof(this.validation_message_cache[section_id][section_repeatable_index][0]) === 'undefined') { this.validation_message_cache[section_id][section_repeatable_index][0] = []; }

				this.validation_message_cache[section_id][section_repeatable_index][field_id][0] = validation_message;

				// Set custom validation message to blank
				obj[0].setCustomValidity('');
			}

			// Add data-hidden attribute
			if(typeof(obj.attr('data-hidden-bypass')) === 'undefined') {

				obj.attr('data-hidden' + attr_suffix, '');
			}

		} else {

			if(
				(typeof(this.validation_message_cache[section_id]) !== 'undefined') &&
				(typeof(this.validation_message_cache[section_id][section_repeatable_index]) !== 'undefined') &&
				(typeof(this.validation_message_cache[section_id][section_repeatable_index][field_id]) !== 'undefined') &&
				(typeof(this.validation_message_cache[section_id][section_repeatable_index][field_id][0]) !== 'undefined')
			) {

				// Recall custom validation message
				obj[0].setCustomValidity(this.validation_message_cache[section_id][section_repeatable_index][field_id][0]);
			}

			// Remove data-hidden attribute
			if(typeof(obj.attr('data-hidden-bypass')) === 'undefined') {

				obj.removeAttr('data-hidden' + attr_suffix);
			}
		}
	}

	// Select all
	$.WS_Form.prototype.form_select_all = function() {

		var ws_this = this;

		$('[data-wsf-select-all]:not([data-init-select-all])', this.form_canvas_obj).each(function() {

			// Flag so it only initializes once
			$(this).attr('data-init-select-all', '');

			// Get select all name
			var select_all_name = $(this).attr('name');
			$(this).removeAttr('name').removeAttr('value').attr('data-wsf-select-all', select_all_name);

			// Click event
			$(this).on('click', function() {

				var select_all = $(this).is(':checked');
				var select_all_name = $(this).attr('data-wsf-select-all');

				// Get field wraper
				var field_wrapper_obj = $(this).closest('[data-id]');

				// Is select all within a field set
				var fieldset_obj = $(this).closest('fieldset', field_wrapper_obj);

				// Determine context
				var context = fieldset_obj.length ? fieldset_obj : ws_this.form_canvas_obj;

				// We use 'each' here to ensure they are checked in ascending order
				$('[name="' + select_all_name + '"]:enabled', context).each(function() {

					$(this).prop('checked', select_all).trigger('change');
				});
			})
		});
	}

	// Select - AJAX
	$.WS_Form.prototype.form_select_ajax = function(obj) {

		if(typeof(obj) === 'undefined') { obj = $('[data-wsf-select2]', this.form_canvas_obj); }

		var ws_this = this;

		// Check Select2 is loaded
		if(typeof(jQuery().select2) !== 'undefined') {

			obj.each(function() {

				// Get field ID
				var field_id = ws_this.get_field_id($(this));

				// Get field
				var field = ws_this.get_field($(this));

				// Get placeholder
				var placeholder = ws_this.get_object_meta_value(field, 'placeholder_row', '');

				// Get language
				var locale = ws_form_settings.locale;
				var language = locale.substring(0, 2);

				// Build AJAX URL
				var url = ws_form_settings.url + 'field/' + field_id + '/select-ajax/';

				// Build args
				var args = {

					// Custom selection template to support e-commerce fields
					templateSelection: function(container) {

						if(typeof(container.data_price) !== 'undefined') {

							$(container.element).attr('data-price', container.data_price);
						}

						return container.text;
					},

					// Add clear icon
					allowClear: true,

					// Placeholder
					placeholder: placeholder,

					// Language
					language: language,

					// CSS
					selectionCssClass: 'wsf-select2-selection',
					dropdownCssClass: 'wsf-select2-dropdown'
				};

				// Use AJAX? (Cannot be used if cascading is enabling)
				var cascade = (ws_this.get_object_meta_value(field, field.type + '_cascade', '') == 'on');
				var select2_ajax = !cascade && (ws_this.get_object_meta_value(field, 'select2_ajax', '') == 'on');
				if(select2_ajax) {

					args['ajax'] = {

						// AJAX URL
						url: url,

						// Data type of JSON
						dataType: 'json',

						// Modify request
						data: function (params) {

							var query = {

								id: ws_this.form_id,
								preview: ws_this.form_canvas_obj[0].hasAttribute('data-preview'),
								value: params.term
							}

							// NONCE
							query[ws_form_settings.wsf_nonce_field_name] = ws_form_settings.wsf_nonce;
							query['_wpnonce'] = ws_form_settings.x_wp_nonce;

							return query;
						},

						// Add call delay
						delay: 250,

						// Enable caching
						cache: true
					};
				}

				// Tagging
				var multiple = (ws_this.get_object_meta_value(field, 'multiple', '') == 'on');
				var select2_tags = (ws_this.get_object_meta_value(field, 'select2_tags', '') == 'on');

				if(multiple && select2_tags) {

					args['tags'] = true;
				}

				// Max
				var obj_wrapper = $(this).closest('[data-type="select"]');
				var select_max = obj_wrapper.attr('data-select-max');

				if(select_max) {

					var select_max = parseInt(select_max);
					if(select_max > 0) {

						args['maximumSelectionLength'] = select_max;
					}
				}

				// Initialize select2
				$(this).select2(args);
			});
		}
	}

	// Select - Cascading
	$.WS_Form.prototype.form_cascade = function() {

		var ws_this = this;

		// Remember checked options
		$('[data-cascade-field-id]:not([data-init-cascade]) input:checked', this.form_canvas_obj).attr('data-checked', '');

		// Process each cascading field
		$('[data-cascade-field-id]:not([data-init-cascade])', this.form_canvas_obj).each(function() {

			var field_id

			// Save this object
			var obj_child_field = $(this);

			// Get child field
			var obj_child = $(this).closest('[data-type]');

			// This skips any subsequent groups that were set as initialized
			if(typeof($(this).attr('data-init-cascade')) !== 'undefined') { return; }

			// Get parent ID
			var obj_parent_id = $(this).attr('data-cascade-field-id');

			// Get repeatable index
			var obj_child_repeatable_index = obj_child.attr('data-repeatable-index');

			// Flag so it only initializes once
			$('[data-cascade-field-id="' + obj_parent_id + '"]', obj_child).attr('data-init-cascade', '');

			// Get parent field
			var obj_parent = false;
			if(obj_child_repeatable_index) {

				// Field is in a repeatable section, so lets see if parent field if in same section
				var obj_parent = $('[id^="' + ws_this.form_id_prefix + 'field-wrapper-' + obj_parent_id + '"][data-id="' + obj_parent_id + '"][data-repeatable-index="' + obj_child_repeatable_index + '"]', ws_this.form_canvas_obj);
				if(!obj_parent.length) { obj_parent = false; }
			}

			if(!obj_parent) {

				// Field is not a repeatable section
				var obj_parent = $('[id^="' + ws_this.form_id_prefix + 'field-wrapper-' + obj_parent_id + '"][data-id="' + obj_parent_id + '"]', ws_this.form_canvas_obj);				
			}

			// Parent cannot be found
			if(!obj_parent.length) { return; }

			// Get parent type
			var obj_parent_type = obj_parent.attr('data-type');

			// Determine event triggers
			switch(obj_parent_type) {

				case 'text' :
				case 'number' :
				case 'rating' :
				case 'range' :
				case 'price_range' :

					var obj_parent_event = 'change input';

					break;

				default :

					var obj_parent_event = 'change';
			}

			// Change event
			obj_parent.on(obj_parent_event, function() {

				// Process
				ws_this.form_cascade_process(obj_parent, obj_child, obj_child_field);
			});

			// Initial process
			ws_this.form_cascade_process(obj_parent, obj_child, obj_child_field);
		});
	}

	$.WS_Form.prototype.form_cascade_process = function(obj_parent, obj_child, obj_child_field) {

		var ws_this = this;

		// Get child data
		var obj_child_id = obj_child.attr('data-id');
		var obj_child_field_data = this.field_data_cache[obj_child_id];
		var obj_child_repeatable_index = obj_child.attr('data-repeatable-index');
		if(!obj_child_repeatable_index) { obj_child_repeatable_index = 0; }
		var obj_child_type = obj_child.attr('data-type');

		// Get parent data
		var obj_parent_id = obj_parent.attr('data-id');
		var obj_parent_repeatable_index = obj_parent.attr('data-repeatable-index');
		var obj_parent_repeatable_suffix = (typeof(obj_parent_repeatable_index) !== 'undefined') ? '[' + obj_parent_repeatable_index + ']' : '';
		var obj_parent_type = obj_parent.attr('data-type');
		var obj_parent_name = this.field_name_prefix + obj_parent_id + obj_parent_repeatable_suffix;

		// Get no rows option text
		var option_text_no_rows = ws_this.get_object_meta_value(obj_child_field_data, obj_child_type + '_cascade_option_text_no_rows', '');
		if(option_text_no_rows == '') { option_text_no_rows = ws_this.language('cascade_option_text_no_rows'); }

		// Cascade no match (Show all if no matches)
		var cascade_no_match = this.get_object_meta_value(obj_child_field_data, obj_child_type + '_cascade_no_match', false);

		switch(obj_parent_type) {

			case 'select' :
			case 'price_select' :

				var obj_parent_value = $('[name="' + obj_parent_name + '[]"]', this.form_canvas_obj).val();
				break;

			case 'checkbox' :
			case 'price_checkbox' :
			case 'radio' :
			case 'price_radio' :

				var obj_parent_value = [];
				$('[name="' + obj_parent_name + '[]"]:checked', this.form_canvas_obj).each(function() {

					obj_parent_value.push($(this).val());
				});
				break;

			default :

				var obj_parent_value = $('[name="' + obj_parent_name + '"]', this.form_canvas_obj).val();
		}

		if(
			(obj_parent_value === null) ||
			(obj_parent_value === '') ||
			(typeof(obj_parent_value) === 'undefined') ||
			((typeof(obj_parent_value) === 'object') && (obj_parent_value.length === 0))
		) {

			obj_parent_value = false;

		} else {

			if(typeof(obj_parent_value) !== 'object') {

				obj_parent_value = [obj_parent_value];
			}
		}

		switch(obj_child_type) {

			case 'select' :
			case 'price_select' :

				var obj_child_select = $('select', obj_child);

				// Check for Select2
				if(typeof(obj_child_field.attr('data-wsf-select2')) !== 'undefined') {

					var select2_obj = $('+ .select2', obj_child_field);

				} else {

					var select2_obj = false
				}

				// Check for AJAX
				if(typeof(obj_child_field.attr('data-cascade-ajax')) !== 'undefined') {

					// Cancel existing API call
					if(
						!this.form_post_locked &&
						(typeof(this.api_call_handle[obj_child_id]) === 'object')
					) {

						this.api_call_handle[obj_child_id].abort();
					}

					// Handle empty parent value
					if((obj_parent_value === false) && !cascade_no_match) {

						// Set select to show placeholder text
						obj_child_select.html('<option value="">' + option_text_no_rows + '</option>').val('');

						return;
					}

					// Get placeholder
					var placeholder_row = ws_this.get_object_meta_value(obj_child_field_data, 'placeholder_row', '');

					// Get loading option text
					var option_text_loading = this.get_object_meta_value(obj_child_field_data, obj_child_type + '_cascade_ajax_option_text_loading', '');
					if(option_text_loading == '') { option_text_loading = this.language('cascade_option_text_loading'); }

					// Set select 2 loading placeholder
					if(select2_obj) {

						this.set_select2_placeholder(obj_child_select, option_text_loading);
					}

					// Set select to show placeholder text
					var trigger = (obj_child_select.val() !== '');
					obj_child_select.html('<option value="">' + option_text_loading + '</option>').val('');
					if(trigger) { obj_child_select.trigger('change'); }

					// Build params
					var form_data = new FormData();

					// Form ID
					form_data.append('id', this.form_id);

					// Parent value
					form_data.append('value', JSON.stringify(obj_parent_value));

					// Preview
					form_data.append('preview', this.form_canvas_obj[0].hasAttribute('data-preview'));

					// Call API
					this.api_call_handle[obj_child_id] = this.api_call('field/' + obj_child_id + '/cascade/', 'GET', form_data, function(response) {

						if(!response.data) { return; }

						var field_html = ws_this.get_field_html(response.data, obj_child.attr('data-repeatable-index'));

						var options_html = $('select', $(field_html)).html();

						if(options_html) {

							if(select2_obj) { ws_this.set_select2_placeholder(obj_child_select, placeholder_row); }

							obj_child_select.html(options_html);

						} else {

							if(select2_obj) { ws_this.set_select2_placeholder(obj_child_select, option_text_no_rows); }

							// Set select to show placeholder text
							obj_child_select.html('<option value="">' + option_text_no_rows + '</option>').val('');
						}

						// Remove empty optgroups
						$('optgroup', obj_child_select).each(function() {

							if(!$('option', $(this)).length) { $(this).remove(); }
						});
					});

				} else {

					// Get select
					var obj_child_select = $('select', obj_child);

					if(typeof(this.cascade_cache[obj_child_id]) === 'undefined') {

						this.cascade_cache[obj_child_id] = [];
					}

					if(typeof(this.cascade_cache[obj_child_id][obj_child_repeatable_index]) === 'undefined') {

						// Add to cache
						this.cascade_cache[obj_child_id][obj_child_repeatable_index] = '<select id="wsf-cascade-scratch">' + obj_child_select.html() + '</select>';
					}

					// Retrieve from cache
					var obj_child_select_scratch = $(this.cascade_cache[obj_child_id][obj_child_repeatable_index]);

					// Comma separate child values?
					var cascade_field_filter_comma = this.get_object_meta_value(obj_child_field_data, obj_child_type + '_cascade_field_filter_comma', false);

					// Check for matched rows
					var matched_row = false;
					if(obj_parent_value !== false) {

						$('option', obj_child_select_scratch).each(function() {

							var cascade_value = $(this).attr('data-cascade-value');

							if(typeof(cascade_value) === 'string') {

								var cascade_value_array = cascade_field_filter_comma ? cascade_value.split(',') : [cascade_value];

								for(var cascade_value_array_index in cascade_value_array) {

									if(!cascade_value_array.hasOwnProperty(cascade_value_array_index)) { continue; }

									var cascade_value = cascade_value_array[cascade_value_array_index];

									if(obj_parent_value.indexOf(cascade_value) !== -1) {

										// Match found so we won't show all rows
										matched_row = true;
										return false;
									}
								}
							}
						});
					}

					// Cascade no match
					if(!matched_row) {

						// Show all if no match?
						var cascade_no_match = this.get_object_meta_value(obj_child_field_data, obj_child_type + '_cascade_no_match', false);
						if(cascade_no_match) {

							// Show all
							obj_child_select.html(obj_child_select_scratch.html());

						} else {

							// Set select to show placeholder text
							obj_child_select.html('<option value="">' + option_text_no_rows + '</option>').val('');
						}

						return;
					}

					// Hide non matching rows
					$('option', obj_child_select_scratch).each(function() {

						var cascade_value = $(this).attr('data-cascade-value');

						if(typeof(cascade_value) === 'string') {

							var cascade_value_array = cascade_field_filter_comma ? cascade_value.split(',') : [cascade_value];

							var cascade_value_found = false;

							for(var cascade_value_array_index in cascade_value_array) {

								if(!cascade_value_array.hasOwnProperty(cascade_value_array_index)) { continue; }

								var cascade_value = cascade_value_array[cascade_value_array_index];

								if(obj_parent_value.indexOf(cascade_value) !== -1) {

									cascade_value_found = true;
									break;
								}
							}

							if(!cascade_value_found) {

								$(this).remove();
							}
						}
					});

					// Remove empty optgroups
					$('optgroup', obj_child_select_scratch).each(function() {

						if(!$('option', $(this)).length) { $(this).remove(); }
					});

					// Show filtered scratch
					obj_child_select.html(obj_child_select_scratch.html());
				}

				break;

			case 'checkbox' :
			case 'price_checkbox' :
			case 'radio' :
			case 'price_radio' :

				// Find a matching row
				var matched_row = false;

				// Comma separate child values?
				var cascade_field_filter_comma = this.get_object_meta_value(obj_child_field_data, obj_child_type + '_cascade_field_filter_comma', false);

				// Check for matched rows
				if(obj_parent_value !== false) {

					$('[data-cascade-value]', obj_child).each(function() {

						var cascade_value = $(this).attr('data-cascade-value');

						if(typeof(cascade_value) === 'string') {

							var cascade_value_array = cascade_field_filter_comma ? cascade_value.split(',') : [cascade_value];

							for(var cascade_value_array_index in cascade_value_array) {

								if(!cascade_value_array.hasOwnProperty(cascade_value_array_index)) { continue; }

								var cascade_value = cascade_value_array[cascade_value_array_index];

								if(obj_parent_value.indexOf(cascade_value) !== -1) {

									// Match found so we won't show all rows
									matched_row = true;
									return false;
								}
							}
						}
					});
				}

				// Cascade no match
				var cascade_no_match = this.get_object_meta_value(obj_child_field_data, obj_child_type + '_cascade_no_match', false);
				if(cascade_no_match && !matched_row) {

					$('[data-cascade-value]', obj_child).show().attr('data-cascade-on', '');
					$('fieldset', obj_child).show();

					return;
				}

				// No matching rows
				if(!matched_row) {

					// Hide all
					$('[data-cascade-value]', obj_child).hide().removeAttr('data-cascade-on');

				} else {

					// Hide non matching rows
					$('[data-cascade-value]', obj_child).each(function() {

						var cascade_value = $(this).attr('data-cascade-value');

						if(typeof(cascade_value) === 'string') {

							var cascade_value_array = cascade_field_filter_comma ? cascade_value.split(',') : [cascade_value];

							var cascade_value_found = false;

							for(var cascade_value_array_index in cascade_value_array) {

								if(!cascade_value_array.hasOwnProperty(cascade_value_array_index)) { continue; }

								var cascade_value = cascade_value_array[cascade_value_array_index];

								if(obj_parent_value.indexOf(cascade_value) !== -1) {

									cascade_value_found = true;
									break;
								}
							}

							if(cascade_value_found) {

								$(this).show().attr('data-cascade-on', '');

							} else {

								$(this).hide().removeAttr('data-cascade-on');
							}
						}
					});
				}

				// Remove empty fieldsets
				$('fieldset', obj_child).show().each(function() {

					if(!$('[data-cascade-value][data-cascade-on]', $(this)).length) { $(this).hide(); }
				});

				// Check / uncheck according to datagrid defaults
				$('[data-cascade-value]:not([data-cascade-on]) input:checked', obj_child).each(function() {

					$(this).prop('checked', false).trigger('change');
				});
				$('[data-cascade-value][data-cascade-on] input[data-checked]:not(:checked)', obj_child).each(function() {

					$(this).prop('checked', true).trigger('change');
				});

				break;
		}
	}

	// Set select2 placeholder
	$.WS_Form.prototype.set_select2_placeholder = function(obj, placeholder_text) {

		var select2 = obj.data('select2');
		if(
			select2 &&
			select2.selection &&
			select2.selection.placeholder &&
			select2.selection.placeholder.text
		) {

			select2.selection.placeholder.text = placeholder_text;
		}
	}

	// Form - Date
	$.WS_Form.prototype.form_date = function() {

		// Do not load date picker if no datetime fields found
		if(!$('[data-type="datetime"] input', this.form_canvas_obj).length) { return false; }

		// Do not use date/time picker
		if($.WS_Form.settings_plugin.ui_datepicker == 'off') { return false; }

		if(
			this.datetimepicker_enabled()
		) {		

			// Process form date fields
			this.form_date_process();

		} else {

			if(this.native_date) {

				var ws_this = this;

				// Ensure date values are in correct format
				$('[data-type="datetime"] input', this.form_canvas_obj).each(function () {

					var value = $(this).attr('value');
					if(value == '') { return false; }

					var type = $(this).attr('data-date-type');

					try {

						switch(type) {

							case 'datetime-local' :

								var date_time = new Date(value);
								var date_time_blog = new Date(date_time.valueOf() - (date_time.getTimezoneOffset() * 60000)).toISOString();
								value = date_time_blog.substring(0,date_time_blog.length-1);
								break;
						}

					} catch (err) {

						ws_this.error('error_datetime_default_value', err);
					}

					$(this).val(value);
				});
			}
		}

		// Process date validity
		this.form_date_validity();
	}

	// Form - Date - datetimepicker enabled
	$.WS_Form.prototype.datetimepicker_enabled = function() {

		return (

			// Checks for our datetimepicker (Avoids clash with other datetimepickers)
			(typeof(jQuery().datetimepicker) === 'function') &&
			(typeof(jQuery.datetimepicker) === 'object') &&							
			(typeof(jQuery.datetimepicker.setLocale) === 'function') &&
			(typeof(jQuery.datetimepicker.setDateFormatter) === 'function') &&

			(

				// Use jQuery date/time picker
				($.WS_Form.settings_plugin.ui_datepicker == 'on') ||

				// If browser does not support native date/time picked, use datetimepicker
				(
					($.WS_Form.settings_plugin.ui_datepicker == 'native') &&
					!this.native_date
				)
			)
		);
	}

	// Form - Date - Process
	$.WS_Form.prototype.form_date_process = function(obj) {

		var ws_this = this;

		if(typeof(obj) === 'undefined') {

			obj = $('[data-type="datetime"] input', this.form_canvas_obj);
		}

		// Language
		var locale = ws_form_settings.locale;
		var args_lang = locale.substring(0, 2);
		jQuery.datetimepicker.setLocale(args_lang);

		// Process each date field
		obj.each(function() {

			// Get field
			var field = ws_this.get_field($(this));

			// Check for read only
			if($(this).is('[readonly]')) {

				$(this).datetimepicker('destroy');
				return;
			}

			// Inline
			if(typeof($(this).attr('data-inline')) !== 'undefined') { args.inline = true; }

			// Input type date/time
			var input_type_datetime = $(this).attr('data-date-type');

			// Date format
			var format_date = $(this).attr('data-date-format') ? $(this).attr('data-date-format') : ws_form_settings.date_format;

			// Time format
			var format_time = $(this).attr('data-time-format') ? $(this).attr('data-time-format') : ws_form_settings.time_format;

			// Base args
			var args = {

				allowBlank: true,
				validateOnBlur: false,
				scrollInput: false,
				formatDate: 'Y-m-d',
				formatTime: format_time
			};

			// Day of week start
			var dow_start = $(this).attr('data-dow-start') ? parseInt($(this).attr('data-dow-start')) : 1;
			if(dow_start < 0) { dow_start = 0; }
			if(dow_start > 6) { dow_start = 6; }
			args.dayOfWeekStart = dow_start;

			// Min
			var min = $(this).attr('min');
			if(min) {

				if(
					(min.charAt(0) != '+') &&
					(min.charAt(0) != '-')
				) {

					var gmt_offset = parseInt(ws_form_settings.gmt_offset, 10);
					var min_date = new Date(min);
					min_date.setHours(min_date.getHours() + (gmt_offset * -1));
					args.minDate = ws_this.date_format(min_date, 'Y-m-d');
//						args.minTime = ws_this.date_format(min_date, format_time);	// We don't like this feature :) it limits the time range on every date, not just the start date

				} else {

					// Allow + / - dates
					args.minDate = min;
				}
			}

			// Max
			var max = $(this).attr('max');
			if(max) {

				if(
					(max.charAt(0) != '+') &&
					(max.charAt(0) != '-')
				) {

					var gmt_offset = parseInt(ws_form_settings.gmt_offset, 10);
					var max_date = new Date(max);
					max_date.setHours(max_date.getHours() + (gmt_offset * -1));
					args.maxDate = ws_this.date_format(max_date, 'Y-m-d');
//						args.maxTime = ws_this.date_format(max_date, format_time);

				} else {

					// Allow + / - dates
					args.maxDate = max;
				}
			}

			// Year start
			var year_start = $(this).attr('data-year-start');
			if(year_start) { args.yearStart = year_start; }

			// Year end
			var year_end = $(this).attr('data-year-end');
			if(year_end) { args.yearEnd = year_end; }

			// Date/time on/off
			switch(input_type_datetime) {

				case 'date' :

					args.format = format_date;
					args.timepicker = false;
					args.closeOnDateSelect = true;
					break;

				case 'time' :

					args.format = format_time;
					args.datepicker = false;
					args.step = 15;
					args.closeOnDateSelect = true;
					break;

				case 'month' :

					args.format = 'F Y';
					args.timepicker = false;
					args.closeOnDateSelect = true;
					break;

				case 'week' :

					args.format = '\\W\\e\\e\\k W, Y';
					args.timepicker = false;
					args.weeks = true;
					args.closeOnDateSelect = true;
					break;

				default :

					args.format = format_date + ' ' + format_time;
					args.step = 15;
			}

			if(ws_this.conversational) {

				args.onShow = function(e, input) {

					var datetimepicker = $('.xdsoft_datetimepicker').first();
					input.after(datetimepicker);
				};
			}

			// Disabled week days
			var disabled_week_days_array = [];
			var disabled_week_days = ws_this.get_object_meta_value(field, 'disabled_week_days');

			if(
				(typeof(disabled_week_days) === 'object') &&
				disabled_week_days.length
			) {

				for(var disabled_week_days_index in disabled_week_days) {

					if(!disabled_week_days.hasOwnProperty(disabled_week_days_index)) { continue; }

					var disabled_week_day = disabled_week_days[disabled_week_days_index];

					if(typeof(disabled_week_day.disabled_week_days_day) === 'undefined') { continue; }

					disabled_week_day = parseInt(disabled_week_day.disabled_week_days_day);

					if((disabled_week_day >= 0) && (disabled_week_day <= 6)) {

						disabled_week_days_array.push(disabled_week_day);
					}
				}
			}

			if(disabled_week_days_array.length > 0) {

				args.disabledWeekDays = disabled_week_days_array;
			}

			// Disabled dates
			var disabled_dates_array = [];
			var disabled_dates = ws_this.get_object_meta_value(field, 'disabled_dates');

			if(
				(typeof(disabled_dates) === 'object') &&
				disabled_dates.length
			) {

				for(var disabled_dates_index in disabled_dates) {

					if(!disabled_dates.hasOwnProperty(disabled_dates_index)) { continue; }

					var disabled_date = disabled_dates[disabled_dates_index];

					if(typeof(disabled_date.disabled_dates_date) === 'undefined') { continue; }
					if(disabled_date.disabled_dates_date == '') { continue; }

					disabled_dates_array.push(disabled_date.disabled_dates_date);
				}
			}

			if(disabled_dates_array.length > 0) {

				args.disabledDates = disabled_dates_array;
			}

			// Enabled dates
			var enabled_dates_array = [];
			var enabled_dates = ws_this.get_object_meta_value(field, 'enabled_dates');

			if(
				(typeof(enabled_dates) === 'object') &&
				enabled_dates.length
			) {

				for(var enabled_dates_index in enabled_dates) {

					if(!enabled_dates.hasOwnProperty(enabled_dates_index)) { continue; }

					var enabled_date = enabled_dates[enabled_dates_index];

					if(typeof(enabled_date.enabled_dates_date) === 'undefined') { continue; }
					if(enabled_date.enabled_dates_date == '') { continue; }

					enabled_dates_array.push(enabled_date.enabled_dates_date);
				}
			}

			if(enabled_dates_array.length > 0) {

				args.allowDates = enabled_dates_array;
			}

			// Initialize date / time picker
			$(this).datetimepicker(args);
		});
	}

	// Form - Date - Validity
	$.WS_Form.prototype.form_date_validity = function() {

		if(typeof(jQuery().datetimepicker) === 'undefined') { return; }

		var ws_this = this;

		// Get all jQuery date fields
		$('input[type="text"][data-date-type]:not([data-hidden],[data-hidden-section],[data-hidden-group]), input[type="text"][data-date-type]:not([data-hidden],[data-hidden-section],[data-hidden-group])', this.form_canvas_obj).each(function() {

			ws_this.field_date_validity_process($(this));

			// Field validation on change
			$(this).on('change', function() {

				// Process validity
				ws_this.field_date_validity_process($(this));
			});
		});
	}

	// Form - Date - Validity - Process
	$.WS_Form.prototype.field_date_validity_process = function(obj) {

		// Get field ID
		var field_id = this.get_field_id(obj);

		// Get field
		var field = this.get_field(obj);

		// Reset invalid feedback
		this.set_invalid_feedback(obj, '');

		// Get input value
		var input_value = obj.val();

		// Ignore if empty
		if(input_value === '') { return; }

		// Get input type date/time
		var input_type_datetime = obj.attr('data-date-type');

		// Ignore date/time types we don't do min/max checks on
		if(
			(input_type_datetime === 'week') ||
			(input_type_datetime === 'month')
		) {

			return;
		}

		// Get date format
		var format_date = obj.attr('data-date-format') ? obj.attr('data-date-format') : ws_form_settings.date_format;

		// Convert input value into date
		var input_date = this.get_date(input_value, input_type_datetime, format_date);

		// Check its a valid date
		if(isNaN(input_date.getTime())) {

			// Set invalid feedback
			this.set_invalid_feedback(obj, false);

			return;
		}

		// Check min / max
		var min = obj.attr('min');
		var max = obj.attr('max');
		var gmt_offset = 0;

		if(
			(min || max)
		) {

			// Min
			if(min) {

				switch(input_type_datetime) {

					case 'time' :

						min = '01/01/1970 ' + min;
						break;

					case 'date' :

						min = min + ' 00:00:00';
						break;

					default :

						var gmt_offset = parseInt(ws_form_settings.gmt_offset, 10);
				}

				var min_date = new Date(min);

				min_date.setHours(min_date.getHours() + (gmt_offset * -1));
			}

			// Max
			if(max) {

				switch(input_type_datetime) {

					case 'time' :

						max = '01/01/1970 ' + max;
						break;

					case 'date' :

						max = max + ' 00:00:00';
						break;

					default :

						var gmt_offset = parseInt(ws_form_settings.gmt_offset, 10);
				}

				var max_date = new Date(max);

				max_date.setHours(max_date.getHours() + (gmt_offset * -1));
			}

			// Check against min
			if(
				(min && (input_date < min_date)) ||
				(max && (input_date > max_date))
			) {

				// Set invalid feedback
				this.set_invalid_feedback(obj, false);
				return;
			}
		}

		// Ignore date/time types we don't do disabled / enable date checks on
		if(input_type_datetime === 'time') { return; }

		// Disabled week days
		var disabled_week_days = this.get_object_meta_value(field, 'disabled_week_days');

		if(
			(typeof(disabled_week_days) === 'object') &&
			disabled_week_days.length
		) {

			for(var disabled_week_days_index in disabled_week_days) {

				if(!disabled_week_days.hasOwnProperty(disabled_week_days_index)) { continue; }

				var disabled_week_day = disabled_week_days[disabled_week_days_index];

				if(typeof(disabled_week_day.disabled_week_days_day) === 'undefined') { continue; }

				disabled_week_day = parseInt(disabled_week_day.disabled_week_days_day);

				if(
					(disabled_week_day >= 0) &&
					(disabled_week_day <= 6) &&
					(input_date.getDay() === disabled_week_day)
				) {

					// Set invalid feedback
					this.set_invalid_feedback(obj, false);
					return;
				}
			}
		}

		// Disabled dates
		var disabled_dates = this.get_object_meta_value(field, 'disabled_dates');

		if(
			(typeof(disabled_dates) === 'object') &&
			disabled_dates.length
		) {

			for(var disabled_dates_index in disabled_dates) {

				if(!disabled_dates.hasOwnProperty(disabled_dates_index)) { continue; }

				var disabled_date = disabled_dates[disabled_dates_index];

				if(typeof(disabled_date.disabled_dates_date) === 'undefined') { continue; }
				if(disabled_date.disabled_dates_date == '') { continue; }

				var disabled_date = this.get_date(disabled_date.disabled_dates_date + ' 00:00:00', input_type_datetime, format_date);

				if(
					(disabled_date.getFullYear() === input_date.getFullYear()) &&
					(disabled_date.getMonth() === input_date.getMonth()) &&
					(disabled_date.getDate() === input_date.getDate())
				) {

					// Set invalid feedback
					this.set_invalid_feedback(obj, false);
					return;
				}
			}
		}

		// Enabled dates
		var enabled_dates = this.get_object_meta_value(field, 'enabled_dates');

		if(
			(typeof(enabled_dates) === 'object') &&
			enabled_dates.length
		) {

			var enabled_dates_valid = false;
			var enabled_dates_valid_check = false;

			for(var enabled_dates_index in enabled_dates) {

				if(!enabled_dates.hasOwnProperty(enabled_dates_index)) { continue; }

				var enabled_date = enabled_dates[enabled_dates_index];

				if(typeof(enabled_date.enabled_dates_date) === 'undefined') { continue; }
				if(enabled_date.enabled_dates_date == '') { continue; }

				var enabled_date = this.get_date(enabled_date.enabled_dates_date + ' 00:00:00', input_type_datetime, format_date);

				if(
					(enabled_date.getFullYear() === input_date.getFullYear()) &&
					(enabled_date.getMonth() === input_date.getMonth()) &&
					(enabled_date.getDate() === input_date.getDate())
				) {

					enabled_dates_valid = true;
				}

				enabled_dates_valid_check = true;
			}

			if(enabled_dates_valid_check && !enabled_dates_valid) {

				// Set invalid feedback
				this.set_invalid_feedback(obj, false);
				return;
			}
		}
	}

	// Form - Color
	$.WS_Form.prototype.form_color = function() {

		// Do not load color picker if no color fields found
		if(!$('[data-type="color"] input', this.form_canvas_obj).length) { return false; }

		// Do not use color picker
		if($.WS_Form.settings_plugin.ui_color == 'off') { return false; }

		if(

			// Use color picker
			($.WS_Form.settings_plugin.ui_color == 'on') ||

			// If browser does not support native color picked, use minicolors
			(
				($.WS_Form.settings_plugin.ui_color == 'native') &&
				!this.native_color
			)
		) {

			this.form_color_process();
		}
	}

	// Form - Color - Process
	$.WS_Form.prototype.form_color_process = function() {

		var ws_this = this;

		// Check to see if minicolors loaded
		if(typeof(jQuery().minicolors) !== 'undefined') {

			$('[data-type="color"] input', this.form_canvas_obj).each(function() {

				if(

					// Use color picker
					($.WS_Form.settings_plugin.ui_color == 'on') ||

					// If browser does not support native color picker, use minicolors
					(
						($.WS_Form.settings_plugin.ui_color == 'native') &&
						!ws_this.native_color
					)

				) {

					// Custom invalid feedback text
					var invalid_feedback_obj = ws_this.get_invalid_feedback_obj($(this));

					// Get framework specific args
					var args = (typeof(ws_this.framework.minicolors_args) !== 'undefined') ? ws_this.framework.minicolors_args : {};

					// Apply minicolors
					$(this).minicolors(args);

					// Move invalid feedback div
					invalid_feedback_obj.insertAfter($(this));
				}
			});
		}
	}
	// Form - Input Mask
	$.WS_Form.prototype.form_inputmask = function() {

		$('[data-inputmask]', this.form_canvas_obj).each(function () {

			if(typeof($(this).inputmask) !== 'undefined') {

				$(this).inputmask().off('invalid');
			}
		});
	}

	// Form - Checkbox Min / Max
	$.WS_Form.prototype.form_checkbox_min_max = function() {

		var ws_this = this;

		$('[data-checkbox-min]:not([data-checkbox-min-max-init]),[data-checkbox-max]:not([data-checkbox-min-max-init])', this.form_canvas_obj).each(function () {

			var checkbox_min = $(this).attr('data-checkbox-min');
			var checkbox_max = $(this).attr('data-checkbox-max');

			// If neither attribute present, disregard this feature
			if(
				(typeof(checkbox_min) === 'undefined') &&
				(typeof(checkbox_max) === 'undefined')
			) {

				return;
			}

			// Get field ID
			var field_id = $(this).attr('data-id');

			// Get repeatable suffix
			var section_repeatable_suffix = ws_this.get_section_repeatable_suffix($(this));

			// Build number input
			var checkbox_min_max = $('<input type="number" id="' + ws_this.form_id_prefix + 'checkbox-min-max-' + field_id + section_repeatable_suffix + '" data-checkbox-min-max data-progress-include="change" style="display:none !important;" />', ws_this.form_canvas_obj);

			// Add min attribute
			if(typeof(checkbox_min) !== 'undefined') { checkbox_min_max.attr('min', checkbox_min); }

			// Add max attribute
			if(typeof(checkbox_max) !== 'undefined') { checkbox_min_max.attr('max', checkbox_max); }
			checkbox_max = parseInt(checkbox_max, 10);

			// Add value attribute
			var checked_count = $('input[type="checkbox"]:not([data-wsf-select-all]):checked', $(this)).length;
			checkbox_min_max.attr('value', checked_count);

			// Add before invalid feedback
			var invalid_feedback_obj = ws_this.get_invalid_feedback_obj($(this));
			invalid_feedback_obj.before(checkbox_min_max);

			// Add event on all checkboxes
			$('input[type="checkbox"]:not([data-wsf-select-all])', $(this)).on('change', function(e) {

				// Get field wrapper
				var field_wrapper = ws_this.get_field_wrapper($(this));

				// Get field ID
				var field_id = ws_this.get_field_id($(this));

				// Get repeatable suffix
				var section_repeatable_suffix = ws_this.get_section_repeatable_suffix($(this));

				// Custom invalid feedback text
				var checkbox_min_max_obj = $('#' + ws_this.form_id_prefix + 'checkbox-min-max-' + field_id + section_repeatable_suffix, ws_this.form_canvas_obj);

				// Set value
				var checked_count = $('input[type="checkbox"]:not([data-wsf-select-all]):checked', field_wrapper).length;

				// Max check
				var obj_wrapper = $(this).closest('[data-type]');
				var input_number = $('input[type="number"]', obj_wrapper);
				var checkbox_max = ws_this.get_number(input_number.attr('max'), 0, false);
				if(
					(checkbox_max > 0) &&
					(checked_count > checkbox_max)
				) {

					$(this).prop('checked', false);
					checked_count--;
				}

				checkbox_min_max_obj.val(checked_count).trigger('change');
			});

			// Flag so it only initializes once
			$(this).attr('data-checkbox-min-max-init', '');
		});
	}

	// Form - Select Min / Max
	$.WS_Form.prototype.form_select_min_max = function() {

		var ws_this = this;

		$('[data-select-min]:not([data-select-min-max-init]),[data-select-max]:not([data-select-min-max-init])', this.form_canvas_obj).each(function () {

			var select_min = $(this).attr('data-select-min');
			var select_max = $(this).attr('data-select-max');

			// If neither attribute present, disregard this feature
			if(
				(typeof(select_min) === 'undefined') &&
				(typeof(select_max) === 'undefined')
			) {

				return;
			}

			// Get field ID
			var field_id = $(this).attr('data-id');

			// Get repeatable suffix
			var section_repeatable_suffix = ws_this.get_section_repeatable_suffix($(this));

			// Build number input
			var select_min_max = $('<input type="number" id="' + ws_this.form_id_prefix + 'select-min-max-' + field_id + section_repeatable_suffix + '" data-select-min-max data-progress-include="change" style="display:none !important;" />', ws_this.form_canvas_obj);

			// Add min attribute
			if(typeof(select_min) !== 'undefined') { select_min_max.attr('min', select_min); }

			// Add max attribute
			if(typeof(select_max) !== 'undefined') { select_min_max.attr('max', select_max); }
			select_max = parseInt(select_max, 10);

			// Add value attribute
			var selected_count = $('select option:selected', $(this)).length;
			select_min_max.attr('value', selected_count);

			// Add before invalid feedback
			var invalid_feedback_obj = ws_this.get_invalid_feedback_obj($(this));
			invalid_feedback_obj.before(select_min_max);

			// Add event on all selects
			$('select', $(this)).on('change', function() {

				var field_wrapper = ws_this.get_field_wrapper($(this));

				// Get field ID
				var field_id = ws_this.get_field_id($(this));

				// Get repeatable suffix
				var section_repeatable_suffix = ws_this.get_section_repeatable_suffix($(this));

				// Custom invalid feedback text
				var select_min_max_obj = $('#' + ws_this.form_id_prefix + 'select-min-max-' + field_id + section_repeatable_suffix, ws_this.form_canvas_obj);

				// Get count
				var selected_count = $('select option:selected', field_wrapper).length;

				// Max check
				if(
					(select_max > 0) &&
					(selected_count > select_max)
				) {

					$(this).prop('selected', false);
					selected_count--;
				}

				// Set value
				select_min_max_obj.val(selected_count).trigger('change');
			});

			// Flag so it only initializes once
			$(this).attr('data-select-min-max-init', '');
		});
	}

	// Form - Client side validation
	$.WS_Form.prototype.form_validation = function() {

		// WS Form forms are set with novalidate attribute so we can manage that ourselves
		var ws_this = this;

		// Disable submit on enter
		if(!this.get_object_meta_value(this.form, 'submit_on_enter', false)) {

			this.form_obj.on('keydown', ':input:not(textarea)', function(e) {

				if(e.keyCode == 13) {

					e.preventDefault();
					return false;
				}
			});
		}

		// On submit
		this.form_obj.on('submit', function(e) {

			e.preventDefault();
			e.stopPropagation();

			// Post if form validates
			ws_this.form_post_if_validated('submit');
		});
	}

	// Form - Post if validated
	$.WS_Form.prototype.form_post_if_validated = function(post_mode) {

		// Trigger
		this.trigger(post_mode + '-before');

		// If form post is locked, return
		if(this.form_post_locked) { return; }

		// Recalculate e-commerce
		if(this.has_ecommerce) { this.form_ecommerce_calculate(); }

		// Mark as validated
		this.form_obj.addClass(this.class_validated);

		// Check validity of form
		if(this.form_validate(this.form_obj)) {

			// Trigger
			this.trigger(post_mode + '-validate-success');

			// reCAPTCHA
			if(this.recaptchas_v2_invisible.length > 0) {

				// Execute (Once reCAPTCHA executes, it calls form_submit)
				this.recaptcha_v2_invisible_execute();

			} else {
				// Submit form
				this.form_post(post_mode);
			}
		} else {

			// Trigger
			this.trigger(post_mode + '-validate-fail');
		}
	}

	// Form - Validate (WS Form validation functions)
	$.WS_Form.prototype.form_validate = function(form) {

		if(typeof(form) === 'undefined') { form = this.form_obj; }

		// Trigger rendered event
		this.trigger('validate-before');

		// Tab focussing
		var group_index_focus_enabled = (this.form.groups.length > 0);
		var group_index_focus = false;
		var object_focus = false;

		// Get form as element
		var form_el = form[0];

		// Execute browser validation
		var form_validated = form_el.checkValidity();

		if(!form_validated) {

			// Get all invalid fields
			var fields_invalid = $(':invalid', form).not('fieldset');

			if(fields_invalid) {

				// Get first invalid field
				object_focus = fields_invalid.first();

				// Get group index
				group_index_focus = this.get_group_index(object_focus);
			}
		}

		if(this.recaptchas_v2_default.length > 0) {

			// reCAPTCHA
			var class_recaptcha_invalid_label_array = this.get_field_value_fallback('recaptcha', false, 'class_invalid_label', []);
			var class_recaptcha_invalid_field_array = this.get_field_value_fallback('recaptcha', false, 'class_invalid_field', []);
			var class_recaptcha_invalid_invalid_feedback_array = this.get_field_value_fallback('recaptcha', false, 'class_invalid_invalid_feedback', []);
			var class_recaptcha_valid_label_array = this.get_field_value_fallback('recaptcha', false, 'class_valid_label', []);
			var class_recaptcha_valid_field_array = this.get_field_value_fallback('recaptcha', false, 'class_valid_field', []);
			var class_recaptcha_valid_invalid_feedback_array = this.get_field_value_fallback('recaptcha', false, 'class_valid_invalid_feedback', []);

			// Run through each reCAPTCHA for this form
			for(var recaptchas_index in this.recaptchas_v2_default) {

				if(!this.recaptchas_v2_default.hasOwnProperty(recaptchas_index)) { continue; }

				// Get data
				var recaptcha = this.recaptchas_v2_default[recaptchas_index];
				var recaptcha_id = recaptcha.id;
				var recaptcha_name = recaptcha.name;

				// If reCaptcha is hidden, bypass this reCaptcha
				var recaptcha_obj = $('#' + recaptcha.recaptcha_id, this.form_canvas_obj);
				if(
					(recaptcha_obj.attr('data-required-bypass') !== undefined) ||
					(recaptcha_obj.attr('data-required-bypass-section') !== undefined) ||
					(recaptcha_obj.attr('data-required-bypass-group') !== undefined)

				) { continue; };

				var recaptcha_obj_field = $('[name="' + recaptcha_name + '"]', form);
				var recaptcha_obj_wrapper = recaptcha_obj_field.closest('[data-id]');
				var recaptcha_obj_label = $('label', recaptcha_obj_wrapper);
				var recaptcha_obj_invalid_feedback = $('#' + this.form_id_prefix + 'invalid-feedback-' + recaptcha_id, form);

				// Execute
				if(grecaptcha.getResponse(recaptcha_id) == '') {

					// Empty - Label
					recaptcha_obj_label.addClass(class_recaptcha_invalid_label_array.join(' '));
					recaptcha_obj_label.removeClass(class_recaptcha_valid_label_array.join(' '));

					// Empty - Field
					recaptcha_obj_field.addClass(class_recaptcha_invalid_field_array.join(' '));
					recaptcha_obj_field.removeClass(class_recaptcha_valid_field_array.join(' '));

					// Empty - Feedback
					recaptcha_obj_invalid_feedback.addClass(class_recaptcha_invalid_invalid_feedback_array.join(' '));
					recaptcha_obj_invalid_feedback.removeClass(class_recaptcha_valid_invalid_feedback_array.join(' '));

					// Determine which tab and object to focus
					if(group_index_focus === false) { group_index_focus = this.get_group_index(recaptcha_obj_wrapper); }
					if(object_focus === false) { object_focus = recaptcha_obj_field; }

					form_validated = false;

				} else {

					// Completed - Label
					recaptcha_obj_label.addClass(class_recaptcha_valid_label_array.join(' '));
					recaptcha_obj_label.removeClass(class_recaptcha_invalid_label_array.join(' '));

					// Completed - Field
					recaptcha_obj_field.addClass(class_recaptcha_valid_field_array.join(' '));
					recaptcha_obj_field.removeClass(class_recaptcha_invalid_field_array.join(' '));

					// Completed - Feedback
					recaptcha_obj_invalid_feedback.addClass(class_recaptcha_valid_invalid_feedback_array.join(' '));
					recaptcha_obj_invalid_feedback.removeClass(class_recaptcha_invalid_invalid_feedback_array.join(' '));
				}
			}
		}
		// Focus
		if(!form_validated) {

			if(object_focus !== false) {

				// Focus object
				if(this.get_object_meta_value(this.form, 'invalid_field_focus', true)) {

					if(group_index_focus !== false) { 

						this.object_focus = object_focus;

					} else {

						object_focus.trigger('focus');
					}
				}
			}

			// Focus tab
			if(group_index_focus !== false) { this.group_index_set(group_index_focus); }
		}

		// Trigger rendered event
		this.trigger('validate-after');

		return form_validated;
	}

	// Form - Validate - Real time
	$.WS_Form.prototype.form_validate_real_time = function(form) {

		var ws_this = this;

		// Set up form validation events
		for(var field_index in this.field_data_cache) {

			if(!this.field_data_cache.hasOwnProperty(field_index)) { continue; }

			var field_type = this.field_data_cache[field_index].type;
			var field_type_config = $.WS_Form.field_type_cache[field_type];

			// Get events
			if(typeof(field_type_config.events) === 'undefined') { continue; }
			var form_validate_event = field_type_config.events.event;

			// Get field ID
			var field_id = this.field_data_cache[field_index].id;

			// Check to see if this field is submitted as an array
			var submit_array = (typeof(field_type_config.submit_array) !== 'undefined') ? field_type_config.submit_array : false;

			// Check to see if field is in a repeatable section
			var field_wrapper = $('[data-type][data-id="' + field_id + '"],input[type="hidden"][data-id-hidden="' + field_id + '"]', this.form_canvas_obj);

			// Run through each wrapper found (there might be repeatables)
			field_wrapper.each(function() {

				var section_repeatable_index = $(this).attr('data-repeatable-index');
				var section_repeatable_suffix = (section_repeatable_index > 0) ? '[' + section_repeatable_index + ']' : '';

				if(submit_array) {

					var field_obj = $('[name="' + ws_form_settings.field_prefix + field_id + section_repeatable_suffix + '[]"]:not([data-init-validate-real-time]), [name="' + ws_form_settings.field_prefix + field_id + section_repeatable_suffix + '[]"]:not([data-init-validate-real-time])', ws_this.form_canvas_obj);

				} else {

					var field_obj = $('[name="' + ws_form_settings.field_prefix + field_id + section_repeatable_suffix + '"]:not([data-init-validate-real-time]), [name="' + ws_form_settings.field_prefix + field_id + section_repeatable_suffix + '"]:not([data-init-validate-real-time])', ws_this.form_canvas_obj);
				}

				if(field_obj.length) {

					// Flag so it only initializes once
					field_obj.attr('data-init-validate-real-time', '');

					// Check if field should be bypassed
					var event_validate_bypass = (typeof(field_type_config.event_validate_bypass) !== 'undefined') ? field_type_config.event_validate_bypass : false;

					// Create event (Also run on blur, this prevents the mask component from causing false validation results)
					field_obj.on(form_validate_event + ' blur', function(e) {

						// Form validation
						if(!event_validate_bypass) {

							// Run validate real time processing
							ws_this.form_validate_real_time_process(false);
						}

						// Run calculation
						if(e.type !== 'blur') {

							var field_obj_id = field_obj.attr('id');
							if(field_obj_id) {

								ws_this.form_calc(field_obj_id);
							}
						}
					});
				}
			});
		}

		// Initial validation fire
		this.form_validate_real_time_process(false);
	}

	$.WS_Form.prototype.form_validate_real_time_process = function(conditional_initiated) {

		// Validate
		this.form_valid = this.form_validate_silent(this.form_obj);

		// Run conditional logic
		if(!conditional_initiated) { this.form_canvas_obj.trigger('wsf-validate-silent'); }

		// Check for form validation changes
		if(
			(this.form_valid_old === null) ||
			(this.form_valid_old != this.form_valid)
		) {

			// Run conditional logic
			if(!conditional_initiated) { this.form_canvas_obj.trigger('wsf-validate'); }
		}

		this.form_valid_old = this.form_valid;

		// Execute hooks and pass form_valid to them
		for(var hook_index in this.form_validation_real_time_hooks) {

			if(!this.form_validation_real_time_hooks.hasOwnProperty(hook_index)) { continue; }

			var hook = this.form_validation_real_time_hooks[hook_index];

			if(typeof(hook) === 'undefined') {

				delete(this.form_validation_real_time_hooks[hook_index]);

			} else {

				hook(this.form_valid, this.form, this.form_id, this.form_instance_id, this.form_obj, this.form_canvas_obj);
			}
		}

		return this.form_valid;
	}

	$.WS_Form.prototype.form_validate_real_time_register_hook = function(hook) {

		this.form_validation_real_time_hooks.push(hook);
	}

	// Form - Validate - Silent
	$.WS_Form.prototype.form_validate_silent = function(form) {

		// Get form as element
		var form_el = form[0];

		// aria-invalid="true"
		$(':valid[aria-invalid="true"]:not(fieldset)', form).removeAttr('aria-invalid');
		$(':invalid:not([aria-invalid="true"]):not(fieldset)', form).attr('aria-invalid', 'true');

		// Execute browser validation
		var form_validated = form_el.checkValidity();
		if(!form_validated) { return false; }

		// Validate reCAPTCHA
		if(this.recaptchas_v2_default.length > 0) {

			// Run through each reCAPTCHA for this form
			for(var recaptchas_index in this.recaptchas_v2_default) {

				if(!this.recaptchas_v2_default.hasOwnProperty(recaptchas_index)) { continue; }

				var recaptcha = this.recaptchas_v2_default[recaptchas_index];

				if(recaptcha.id === false) { return false; }

				// If reCaptcha is hidden, bypass this reCaptcha
				var recaptcha_id = recaptcha.recaptcha_id;
				var recaptcha_obj = $('#' + recaptcha_id, this.form_canvas_obj);
				if(
					(recaptcha_obj.attr('data-required-bypass') !== undefined) ||
					(recaptcha_obj.attr('data-required-bypass-section') !== undefined) ||
					(recaptcha_obj.attr('data-required-bypass-group') !== undefined)

				) { continue; };

				// Execute
				if(grecaptcha.getResponse(recaptcha.id) == '') { return false; }
			}
		}

		return true;
	}

	// Validate any form object
	$.WS_Form.prototype.object_validate = function(obj) {

		var radio_field_processed = [];		// This ensures correct progress numbers of radios

		if(typeof(obj) === 'undefined') { return false; }

		var ws_this = this;

		var valid = true;

		// Get fields
		$('input,select,textarea', obj).filter(':not([data-hidden],[data-hidden-section],[data-hidden-group],[disabled],[type="hidden"])').each(function() {

			// Get field
			var field = ws_this.get_field($(this));
			var field_type = field.type;

			// Get repeatable suffix
			var section_repeatable_index = ws_this.get_section_repeatable_index($(this));
			var section_repeatable_suffix = (section_repeatable_index > 0) ? '[' + section_repeatable_index + ']' : '';

			// Build field name
			var field_name = ws_form_settings.field_prefix + ws_this.get_field_id($(this)) + section_repeatable_suffix;

			// Determine field validity based on field type
			var validity = false;
			switch(field_type) {

				case 'radio' :
				case 'price_radio' :

					if(typeof(radio_field_processed[field_name]) === 'undefined') { 

						validity = $(this)[0].checkValidity();

					} else {

						return;
					}
					break;

				case 'email' :

					var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					validity = re.test($(this).val());
					break;

				default :

					validity = $(this)[0].checkValidity();
			}

			radio_field_processed[field_name] = true;

			if(!validity) { valid = false; return false; }
		});

		return valid;
	}
	// Form - Initialize client side form conditions
	$.WS_Form.prototype.form_conditional = function(initial) {

		var ws_this = this;

		if(typeof(initial) === 'undefined') { initial = false; }

		if(this.conditional_cache === false) {

			// Run through the form conditions
			var conditionals = this.get_object_meta_value(this.form, 'conditional', false);

			if(typeof(conditionals.groups) === 'undefined') { return false; }
			if(typeof(conditionals.groups[0]) === 'undefined') { return false; }
			if(typeof(conditionals.groups[0].rows) === 'undefined') { return false; }

			for(var conditional_index in conditionals.groups[0].rows) {

				if(!conditionals.groups[0].rows.hasOwnProperty(conditional_index)) { continue; }

				var row = conditionals.groups[0].rows[conditional_index];

				// Disabled?
				if((typeof(row.disabled) !== 'undefined') && row.disabled) { continue; }

				// Check for data
				if(typeof(row.data) === 'undefined') { continue; }
				if(typeof(row.data[1]) === 'undefined') { continue; }

				// Read data
				var conditional = row.data[1];

				// Attempt to JSON decode it
				try {

					var conditional = JSON.parse(conditional);

				} catch(e) {

					var conditional = false;
				}

				// If conditional found, set up events for it
				if(conditional !== false) {

					conditional.last_state = [];
					this.conditional_events(conditional, initial);
					if(this.conditional_cache === false) { this.conditional_cache = []; }
					this.conditional_cache.push(conditional);
				}
			}

		} else {

			// Use cache (Ensure same conditional objects are used if this function is called again)
			for(var conditional_index in this.conditional_cache) {

				if(!this.conditional_cache.hasOwnProperty(conditional_index)) { continue; }

				var conditional = this.conditional_cache[conditional_index];
				conditional.last_state = [];
				this.conditional_events(conditional, initial);
			}
		}

		// Create events
		for(var conditional_selector in this.conditional_event_selector_to_condition) {

			if(!this.conditional_event_selector_to_condition.hasOwnProperty(conditional_selector)) { continue; }

			var events = this.conditional_event_selector_to_condition[conditional_selector];

			for(var conditional_event in events) {

				if(!events.hasOwnProperty(conditional_event)) { continue; }

				var selector_event_config = events[conditional_event];

				var object_event_selector = selector_event_config.object_event_selector;
				var object_event_obj = selector_event_config.object_event_obj;
				var conditionals = selector_event_config.conditionals;

				// Initialize events?
				if(initial) {

					if(conditional_selector === 'null') { conditional_selector = null; }

					// Create missing events
					var conditional_event_added = false;
					object_event_obj.each(function() {

						$(this).on(conditional_event, conditional_selector, { conditionals : conditionals }, function(event, form, form_id, form_instance_id) {

							// If this is a $(document) level trigger, check if it came from the current form
							if(
								(typeof(form_id) !== 'undefined') &&
								(typeof(form_instance_id) !== 'undefined') &&
								(ws_this.form_id !== form_id) &&
								(ws_this.form_instance_id !== form_instance_id)
							) {
								return;
							}

							var wrapper_obj = $(this).closest('[data-type]');
							var repeatable_index = wrapper_obj.attr('data-repeatable-index') ? wrapper_obj.attr('data-repeatable-index') : 0;

							for(var conditional_index in event.data.conditionals) {

								if(!event.data.conditionals.hasOwnProperty(conditional_index)) { continue; }

								var conditional = event.data.conditionals[conditional_index];

								ws_this.conditional_process(conditional, false, $(this), repeatable_index, event);
							}
						});
					});

					if($.WS_Form.debug_rendered) {

						this.log('log_conditional_event', ((conditional_selector === null) ? this.language('debug_form') : conditional_selector) + ' (' + conditional_event + ')', 'conditional');
					}
				}

				// Fire conditionals initially
				$(object_event_selector, this.form_canvas_obj).each(function() {

					// This prevent conditional_process running repeatedly for checkbox and radio fields
					if(typeof($(this).attr('data-fired-conditional')) !== 'undefined') { return; }

					var wrapper_obj = $(this).closest('[data-type]');
					var repeatable_index = wrapper_obj.attr('data-repeatable-index') ? wrapper_obj.attr('data-repeatable-index') : 0;

					for(var conditional_index in conditionals) {

						if(!conditionals.hasOwnProperty(conditional_index)) { continue; }

						var conditional = conditionals[conditional_index];

						ws_this.conditional_process(conditional, true, $(this), repeatable_index, false);
					}

					// Mark all fields matching this name inititalized
					var name = $(this).attr('name');
					$('[name="' + name + '"]', this.form_canvas_obj).attr('data-fired-conditional', '');
				});

				// Reset data-fired-conditional on all fields
				$('[data-fired-conditional]', this.form_canvas_obj).removeAttr('data-fired-conditional');
			}
		}
	}

	// Form - Conditional - Events
	$.WS_Form.prototype.conditional_events = function(conditional, initial) {

		if(typeof(initial) === 'undefined') { initial = true; }

		var ws_this = this;

		// Get selector href
		var selector_href = (typeof(this.framework.tabs.public.selector_href) !== 'undefined') ? this.framework.tabs.public.selector_href : 'href';

		// Run through if groups
		for(var group_index in conditional.if) {

			if(!conditional.if.hasOwnProperty(group_index)) { continue; }

			var group = conditional.if[group_index];

			// Error check group
			if(typeof(group['conditions']) === 'undefined') { continue; }

			// Process conditions
			for(var condition_index in group['conditions']) {

				if(!group['conditions'].hasOwnProperty(condition_index)) { continue; }

				var condition = group['conditions'][condition_index];

				// Check integrity of condition
				if(!this.conditional_condition_check(condition)) { continue; }

				// Read condition
				var object = condition.object;
				var object_id = condition.object_id;
				var object_row_id = condition.object_row_id ? parseInt(condition.object_row_id, 10) : false;
				var logic = condition.logic;
				var value = condition.value;

				// Create events
				var object_events = [];

				switch(object) {

					case 'form' :

						// Create event
						object_events.push(this.conditional_event_get(object, this.form_id, 0, this.form, logic));

						break;

					case 'group' :

						// Get group
						if(typeof(this.group_data_cache[object_id]) === 'undefined') { break; }
						var object_data = this.group_data_cache[object_id];

						// Create event
						object_events.push(this.conditional_event_get(object, object_id, object_row_id, object_data, logic));

						break;

					case 'section' :

						// Get section
						if(typeof(this.section_data_cache[object_id]) === 'undefined') { break; }
						var object_data = this.section_data_cache[object_id];

						// Create event
						object_events.push(this.conditional_event_get(object, object_id, object_row_id, object_data, logic));

						break;

					case 'field' :

						// Get field
						if(typeof(this.field_data_cache[object_id]) === 'undefined') { break; }
						var object_data = this.field_data_cache[object_id];
						var field_type = $.WS_Form.field_type_cache[object_data.type];

						// Determine if field is repeatable
						var field_repeatable = (typeof(object_data.section_repeatable_section_id) !== 'undefined');

						// Create event
						object_events.push(this.conditional_event_get(object, object_id, object_row_id, object_data, logic, field_repeatable));

						// Logic specific events
						var field_attribute_values = [];
						switch(logic) {

							case 'field_match' :
							case 'field_match_not' :

								// Find matching field
								var field_match_id = value;
								if(parseInt(field_match_id, 10) == 0) { break; }
								if(typeof(this.field_data_cache[field_match_id]) === 'undefined') { break; }
								var field_match = this.field_data_cache[field_match_id];

								// Determine if field is repeatable
								var field_repeatable = (typeof(field_match.section_repeatable_section_id) !== 'undefined');

								// Create event for matching field
								object_events.push(this.conditional_event_get('field', field_match_id, false, field_match, logic, field_repeatable));

								field_attribute_values['field_match_id'] = this.form_id_prefix + 'field-' + field_match_id;

								break;
						}

						// Check to see if any logic specific attributes should be added to the field
						var field_attributes = this.get_field_value_fallback(field_type, false, 'attribute_' + logic, false);
						if(typeof(field_attributes) === 'object') {

							var object_event_selector = '#' + this.form_id_prefix + object + '-' + object_id;

							for(var field_attribute_index in field_attributes) {

								if(!field_attributes.hasOwnProperty(field_attribute_index)) { continue; }

								var field_attribute_value = field_attributes[field_attribute_index];

								// Parse field_attribute_value
								field_attribute_value = this.mask_parse(field_attribute_value, field_attribute_values);

								// Set attribute in object
								$(object_event_selector, this.form_canvas_obj).attr(field_attribute_index, field_attribute_value);
							}
						}

						break;

					case 'submit' :

						// Create event
						object_events.push(this.conditional_event_get(object, 0, 0, this.submit, logic));

						break;

					case 'user' :

						// Create event
						object_events.push(this.conditional_event_get(object, 0, 0, false, logic));

						break;
				}

				// Process events
				for(var object_event_index in object_events) {

					if(!object_events.hasOwnProperty(object_event_index)) { continue; }

					var object_event = object_events[object_event_index];

					var object_event_selector = null;
					var object_event_repeatable = object_event.repeatable;

					// Build event selector
					if(
						(object_event.event == 'wsf-validate') ||
						(object_event.event == 'wsf-validate-silent') ||
						(object_event.event == 'wsf-section-repeatable')
					) {

						if(!initial) { continue; }

						if(object_event.event == 'wsf-section-repeatable') {

							object_event.event = 'wsf-section-repeatable-' + object_id;
						}

						var object_event_obj = this.form_canvas_obj
						var object_event_selector = null;

					} else if(

						(object_event.event == 'wsf-rendered') ||
						(object_event.event == 'wsf-submit') ||
						(object_event.event == 'wsf-save') ||
						(object_event.event == 'wsf-submit wsf-save') ||
						(object_event.event == 'wsf-submit-complete') ||
						(object_event.event == 'wsf-save-complete') ||
						(object_event.event == 'wsf-complete') ||
						(object_event.event == 'wsf-submit-error') ||
						(object_event.event == 'wsf-save-error') ||
						(object_event.event == 'wsf-error') ||
						(object_event.event == 'wsf-submit-success') ||
						(object_event.event == 'wsf-save-success') ||
						(object_event.event == 'wsf-success')
					) {

						var object_event_obj = $(document);
						var object_event_selector = null;

					} else {

						var object_event_obj = this.form_canvas_obj

						switch(object_event.object) {

							case 'form' :

								var object_event_selector = null;
								break;

							case 'group' :

								var object_event_selector = '[' + selector_href + '="#' + this.form_id_prefix + 'group-' + object_id + '"]';
								break;

							case 'section' :

								var object_event_selector = '[id^="' + this.form_id_prefix + object_event.object + '-' + object_event.object_id + '"][data-id="' + object_event.object_id + '"]';
								break;

							case 'field' :

								// Get field type
								var field = this.field_data_cache[object_id];

								switch(field.type) {

									case 'radio' :
									case 'price_radio' :
									case 'checkbox' :
									case 'price_checkbox' :

										var object_event_selector = '[name^="' + ws_form_settings.field_prefix + object_id + '["]';
										break;

									case 'select' :
									case 'price_select' :

										if(object_event_repeatable) {

											var object_event_selector = '[id^="' + this.form_id_prefix + object_event.object + '-' + object_event.object_id + '-repeat-"]';

										} else {

											var object_event_selector = '#' + this.form_id_prefix + object_event.object + '-' + object_event.object_id;
										}
										break;

									default :

										if(object_event_repeatable) {

											var object_event_selector = '[id^="' + this.form_id_prefix + object_event.object + '-' + object_event.object_id + ((object_event.object_row_id !== false) ? '-row-' + object_event.object_row_id : '') + '-repeat-"]';

										} else {

											var object_event_selector = '#' + this.form_id_prefix + object_event.object + '-' + object_event.object_id + ((object_event.object_row_id !== false) ? '-row-' + object_event.object_row_id : '');
										}
										break;
								}
								break;
						}
					}

					// Create event for this condition?
					if(
						object_event.create && 
						(object_event.event !== false) && 
						(object_event_selector !== false)
					) {

						if(($(object_event_selector + '[data-init-conditional]', this.form_canvas_obj).length == 0)) {

							// Process event
							switch(object_event.event) {

								case 'recaptcha' :

									// Create reCAPTCHA event
									this.recaptchas_conditions.push(function() {

										ws_this.conditional_process(conditional, false, false, 0, false);
									});
									break;

								default :

									if(object_event_selector === null) { object_event_selector = 'null'; }

									if(typeof(this.conditional_event_selector_to_condition[object_event_selector]) === 'undefined') {

										this.conditional_event_selector_to_condition[object_event_selector] = [];
									}

									if(typeof(this.conditional_event_selector_to_condition[object_event_selector][object_event.event]) === 'undefined') {

										this.conditional_event_selector_to_condition[object_event_selector][object_event.event] = {

											object_event_selector: object_event_selector,
											object_event_obj: object_event_obj,
											conditionals: [],
											event_processed: false
										};
									}

									if(this.conditional_event_selector_to_condition[object_event_selector][object_event.event].conditionals.indexOf(conditional) === -1) {

										this.conditional_event_selector_to_condition[object_event_selector][object_event.event].conditionals.push(conditional);
									}

									// Add to object (For debug)
									if(ws_form_settings.debug) {

										var data_populate_event = $(object_event_selector, this.form_canvas_obj).attr('data-populate-event');
										var data_populate_event_array = data_populate_event ? data_populate_event.split(' ') : [];
										data_populate_event_array.push(object_event.event);
										data_populate_event_array = data_populate_event_array.filter(function(value, index, self) { 
											return self.indexOf(value) === index;
										});
										data_populate_event = data_populate_event_array.join(' ');
										$(object_event_selector, this.form_canvas_obj).attr('data-populate-event', data_populate_event);
									}
							}
						}
					}
				}
			}
		}
	}

	// Form - Get conditional event
	$.WS_Form.prototype.conditional_event_get = function(object, object_id, object_row_id, field, logic, repeatable) {

		if(typeof(repeatable) === 'undefined') { repeatable = false; }

		var object_event = {

			'object':			object,
			'object_id':		object_id,
			'object_row_id':	object_row_id,
			'create':			true,
			'event':			false,
			'row':				false,
			'repeatable':		repeatable, 
		};

		switch(object) {

			case 'field' :

				var field_type = $.WS_Form.field_type_cache[field.type];

				// Are there conditional settings?
				if(typeof(field_type['conditional']) !== 'undefined') {

					// Should this field type be excluded?
					if(typeof(field_type['conditional']['exclude_condition']) !== 'undefined') {

						object_event.create = !field_type['conditional']['exclude_condition'];
					}

					// Which event type should be created?
					if(typeof(field_type['conditional']['condition_event']) !== 'undefined') {

						object_event.event = field_type['conditional']['condition_event'];
					}

					// Should event occur on row?
					if(typeof(field_type['conditional']['object_event.row']) !== 'undefined') {

						if(field_type['conditional']['object_event.row'] && object_row_id !== false) {

							object_event.row = true;
						};
					}
				}

				break;
		}

		// Check for logic event
		var conditional_settings = $.WS_Form.settings_form.conditional;
		var conditional_settings_objects = conditional_settings.objects;
		var conditional_settings_logics = conditional_settings_objects[object]['logic'];

		if(typeof(conditional_settings_logics[logic]) !== 'undefined') {

			if(typeof(conditional_settings_logics[logic]['event']) !== 'undefined') {

				object_event.event = conditional_settings_logics[logic]['event'];
			}
		}

		return object_event;
	}

	// Form - Process client side conditional
	$.WS_Form.prototype.conditional_process = function(conditional, initial, source_obj, source_repeatable_index, event) {

	    // Check conditional
	    if(typeof(conditional.if) === 'undefined') { return false; }
	    if(typeof(conditional.then) === 'undefined') { return false; }
	    if(typeof(conditional.else) === 'undefined') { return false; }

		// Process groups
		var result_conditions = false;
		for(var group_index in conditional.if) {

			if(!conditional.if.hasOwnProperty(group_index)) { continue; }

			var group = conditional.if[group_index];

			// Error check group
			if(typeof(group['conditions']) === 'undefined') { continue; }

			// Process conditions
			var result_group = false;
			var conditional_description = '';
			for(var condition_index in group['conditions']) {

				if(!group['conditions'].hasOwnProperty(condition_index)) { continue; }

				var condition = group['conditions'][condition_index];

				// Check integrity of condition
				if(!this.conditional_condition_check(condition)) { continue; }

				// Read condition data
				var object = condition.object;
				var object_id = condition.object_id;
				var object_row_id = (typeof(condition.object_row_id) === 'undefined') ? false : condition.object_row_id;
	
				// Process object_id so values are integers
				if(typeof(object_row_id) === 'object') {

					var object_row_id = object_row_id.map(function(id) { return parseInt(id, 10); });
					if(!object_row_id.length) { object_row_id = false; }

				} else {

					var object_row_id = (object_row_id !== '') ? [parseInt(object_row_id, 10)] : false;
				}

				var logic = condition.logic;
				var value = condition.value;
				var case_sensitive = (typeof(condition.case_sensitive) === 'undefined') ? true : condition.case_sensitive;
				var logic_previous = (condition_index > 0) ? ((typeof(condition.logic_previous) === 'undefined') ? '||' : condition.logic_previous) : '||';
				var field_name = ws_form_settings.field_prefix + object_id;
				var force_result = (typeof(condition.force_result) === 'undefined') ? null : condition.force_result;

				// Debug
				if($.WS_Form.debug_rendered) {

					// Build conditional description for debug
					switch(object) {

						case 'form' :

							var object_single = this.form_obj;
							break;

						case 'group' :

							var object_single = this.group_data_cache[object_id];
							break;

						case 'section' :

							var object_single = this.section_data_cache[object_id];
							break;

						case 'field' :

							var object_single = this.field_data_cache[object_id];
							break;
					}

					if(typeof(object_single) !== 'undefined') {

						var conditional_settings = $.WS_Form.settings_form.conditional;
						var conditional_settings_logic_previous = conditional_settings.logic_previous;

						var conditional_settings_objects = conditional_settings.objects;
						var conditional_settings_logics = conditional_settings_objects[object]['logic'];

						// Get logic description
						if(typeof(conditional_settings_logics[logic]) !== 'undefined') {

							var logic_description = conditional_settings_logics[logic].text.toUpperCase();

						} else {

							var logic_description = '';
						}

						// Get logic previous description
						if(typeof(conditional_settings_logic_previous[logic_previous]) !== 'undefined') {

							var logic_previous_description = conditional_settings_logic_previous[logic_previous].text.toUpperCase();

						} else {

							var logic_previous_description = '';
						}

						var conditional_description = '<strong>' + (condition_index > 0 ? logic_previous_description + ' ' : '') + 'IF [' + this.html_encode(object_single.label) + '] ' + logic_description + ((value != '') ? " '" + value + "'" : '') + '</strong> (' + ((object_single.type !== undefined) ? ('Type: ' + object_single.type + ' | ') : '') + 'ID: ' + object_id + (object_row_id ? ' | Row ID: ' + object_row_id.join(', ') : '') + ') ';
					}
				}

				// Get object(s) to check
				var section_repeatable_index = false;
				switch(object) {

					case 'form' :

						var object_event_selector = '#' + this.form_obj_id;
						break;

					case 'group' :

						var object_event_selector = '#' + this.form_id_prefix + 'group-' + object_id;
						break;

					case 'section' :

						var object_event_selector = '#' + this.form_id_prefix + object + '-' + object_id;
						break;

					case 'field' :

						// Get repeatable suffix
						var repeatable_suffix = (source_repeatable_index > 0) ? '-repeat-' + source_repeatable_index : '';

						var object_event_selector = '#' + this.form_id_prefix + object + '-' + object_id + repeatable_suffix;
						var object_wrapper = $('[data-type][data-id="' + object_id + '"]' + ((source_repeatable_index > 0) ? '[data-repeatable-index="' + source_repeatable_index + '"]' : ''), this.form_canvas_obj);
				}

				// Get value
				var object_value = $(object_event_selector, this.form_canvas_obj).val();

				// Case sensitive
				if(!case_sensitive && object_value) {

					object_value = object_value.toLowerCase();
					value = value.toLowerCase();
				}

				// Section repeatable row count
				var logic_section_repeatable = ['r==', 'r!=', 'r>', 'r<', 'r>=', 'r<='];
				if(logic_section_repeatable.indexOf(logic) !== -1) {

					// Set object value to the section count
					var sections = $('[data-repeatable][data-id="' + object_id + '"]', this.form_canvas_obj);
					if(!sections.length) { continue; }
					object_value = sections.length;
				}

				// Parse value
				var value = this.parse_variables_process(value).output;

				// Date processing
				switch(logic) {

					case 'd>' :
					case 'd<' :
					case 'd==' :
					case 'd!=' :

						// Convert input to JS date
						var field_from = (typeof(this.field_data_cache[object_id]) !== 'undefined') ? this.field_data_cache[object_id] : false;
						if(field_from !== false) {

							var input_type_datetime = this.get_object_meta_value(field_from, 'input_type_datetime', 'date');
							var format_date = this.get_object_meta_value(field_from, 'format_date', ws_form_settings.date_format);

							var value = this.get_date(value, input_type_datetime, format_date);
							var object_value = this.get_date(object_value, input_type_datetime, format_date);
						}

						break;
				}

				var result_condition = false; 

				switch(logic) {

					// Number equals (Exact)
					case '==' :

						result_condition = (this.get_number(object_value) == this.get_number(value));
						break;

					// Number does not equal
					case '!=' :

						result_condition = (this.get_number(object_value) != this.get_number(value));
						break;

					// Greater than
					case '>' :

						if(object_value != '') {

							result_condition = (this.get_number(object_value) > this.get_number(value));
						}
						break;

					// Less than
					case '<' :

						if(object_value != '') {

							result_condition = (this.get_number(object_value) < this.get_number(value));
						}
						break;

					// Greater than or equal to
					case '>=' :

						if(object_value != '') {

							result_condition = (this.get_number(object_value) >= this.get_number(value));
						}
						break;

					// Less than or equal to
					case '<=' :

						if(object_value != '') {

							result_condition = (this.get_number(object_value) <= this.get_number(value));
						}
						break;

					// Equals (Date)
					case 'd==' :

						if((object_value != '') && (value != '')) {

							result_condition = (Date.parse(object_value) == Date.parse(value));
						}
						break;

					// Not equals (Date)
					case 'd!=' :

						if((object_value != '') && (value != '')) {

							result_condition = (Date.parse(object_value) != Date.parse(value));
						}
						break;

					// Greater than (Date)
					case 'd>' :

						if((object_value != '') && (value != '')) {

							result_condition = (Date.parse(object_value) > Date.parse(value));
						}
						break;

					// Less than (Date)
					case 'd<' :

						if((object_value != '') && (value != '')) {

							result_condition = (Date.parse(object_value) < Date.parse(value));
						}
						break;

					// Greater than or equal to (Date)
					case 'd>=' :

						if((object_value != '') && (value != '')) {

							result_condition = (Date.parse(object_value) >= Date.parse(value));
						}
						break;

					// Less than or equal to (Date)
					case 'd<=' :

						if((object_value != '') && (value != '')) {

							result_condition = (Date.parse(object_value) <= Date.parse(value));
						}
						break;

					// Checkbox count equals / not equals
					case 'rc==' :
					case 'rc!=' :

						var object_value = $('input[type="checkbox"]:not([data-wsf-select-all]):checked', object_wrapper).length;
						result_condition = (object_value == this.get_number(value));
						if(logic == 'rc!=') { result_condition = !result_condition; }
						break;

					// Checkbox count greater than
					case 'rc>' :

						var object_value = $('input[type="checkbox"]:not([data-wsf-select-all]):checked', object_wrapper).length;
						result_condition = (object_value > this.get_number(value));
						break;

					// Checkbox count less than
					case 'rc<' :

						var object_value = $('input[type="checkbox"]:not([data-wsf-select-all]):checked', object_wrapper).length;
						result_condition = (object_value < this.get_number(value));
						break;

					// Selected count equals / not equals
					case 'rs==' :
					case 'rs!=' :

						var object_value = $('option:not([data-placeholder]):selected', object_wrapper).length;
						result_condition = (object_value == this.get_number(value));
						if(logic == 'rc!=') { result_condition = !result_condition; }
						break;

					// Selected count greater than
					case 'rs>' :

						var object_value = $('option:not([data-placeholder]):selected', object_wrapper).length;
						result_condition = (object_value > this.get_number(value));
						break;

					// Selected count less than
					case 'rs<' :

						var object_value = $('option:not([data-placeholder]):selected', object_wrapper).length;
						result_condition = (object_value < this.get_number(value));
						break;

					// Section row count equals
					case 'r==' :

						result_condition = (this.get_number(object_value) == this.get_number(value));
						break;

					// Section row count does not equal
					case 'r!=' :

						result_condition = (this.get_number(object_value) != this.get_number(value));
						break;

					// Section row count greater than
					case 'r>' :

						if(object_value != '') {
							result_condition = (this.get_number(object_value) > this.get_number(value));
						}
						break;

					// Section row count less than
					case 'r<' :

						if(object_value != '') {
							result_condition = (this.get_number(object_value) < this.get_number(value));
						}
						break;

					// Section row count greater than or equal to
					case 'r>=' :

						if(object_value != '') {
							result_condition = (this.get_number(object_value) >= this.get_number(value));
						}
						break;

					// Section row count less than or equal to
					case 'r<=' :

						if(object_value != '') {
							result_condition = (this.get_number(object_value) <= this.get_number(value));
						}
						break;

					// Section repeatable changes
					case 'section_repeatable' :

						conditional.last_state[source_repeatable_index] = '';
						result_condition = (event.type == 'wsf-section-repeatable-' + object_id);
						break;

					// String equals
					case 'equals' :
					case 'c==' :

						result_condition = (object_value == value);
						break;

					// String does not equal
					case 'equals_not' :
					case 'c!=' :

						result_condition = (object_value != value);
						break;

					// Contains
					case 'contains' :
					case 'contains_not' :

						result_condition = (object_value.indexOf(value) != -1);
						if(logic == 'contains_not') { result_condition = !result_condition; }
						break;

					// Starts with
					case 'starts' :
					case 'starts_not' :

						result_condition = object_value.startsWith(value);
						if(logic == 'starts_not') { result_condition = !result_condition; }
						break;

					// Ends with
					case 'ends' :
					case 'ends_not' :

						result_condition = object_value.endsWith(value);
						if(logic == 'ends_not') { result_condition = !result_condition; }
						break;

					// Is blank
					case 'blank' :
					case 'blank_not' :

						result_condition = (object_value == '');
						if(logic == 'blank_not') { result_condition = !result_condition; }
						break;

					// Checked
					case 'checked' :
					case 'checked_not' :

						var result_condition = false;

						for(var object_row_id_index in object_row_id) {

							if(!object_row_id.hasOwnProperty(object_row_id_index)) { continue; }

							var object_row_id_single = object_row_id[object_row_id_index];

							var object_event_selector_obj = '#' + this.form_id_prefix + object + '-' + object_id + '-row-' + object_row_id_single + repeatable_suffix;

							var object_row_id_selected = $(object_event_selector_obj, this.form_canvas_obj).is(':checked');

							result_condition = result_condition | object_row_id_selected;
						}

						if(logic == 'checked_not') { result_condition = !result_condition; }

						break;

					// Checked - Any
					case 'checked_any' :
					case 'checked_any_not' :

						result_condition = ($('input:checked', object_wrapper).length > 0);
						if(logic == 'checked_any_not') { result_condition = !result_condition; }
						break;

					// Checked value
					case 'checked_value_equals' :
					case 'checked_value_equals_not' :

						var result_condition = $('input[value="' + value + '"]:checked', object_wrapper).length;
						if(logic == 'checked_value_equals_not') { result_condition = !result_condition; }
						break;

					// Selected
					case 'selected' :
					case 'selected_not' :

						var result_condition = false;

						for(var object_row_id_index in object_row_id) {

							if(!object_row_id.hasOwnProperty(object_row_id_index)) { continue; }

							var object_row_id_single = object_row_id[object_row_id_index];

							var object_row_id_selected = $('option[data-id="' + object_row_id_single + '"]', $(object_event_selector, this.form_canvas_obj)).prop('selected');

							result_condition = result_condition | object_row_id_selected;
						}

						if(logic == 'selected_not') { result_condition = !result_condition; }

						break;

					// Selected - Any
					case 'selected_any' :
					case 'selected_any_not' :

						var result_condition = ($('option:not([data-placeholder]):selected', $(object_event_selector, this.form_canvas_obj)).length > 0);
						if(logic == 'selected_any_not') { result_condition = !result_condition; }
						break;

					// Selected value
					case 'selected_value_equals' :
					case 'selected_value_equals_not' :

						var result_condition = $('option[value="' + value + '"]', $(object_event_selector, this.form_canvas_obj)).prop('selected');
						if(logic == 'selected_value_equals_not') { result_condition = !result_condition; }
						break;

					// Regex - Email
					case 'regex_email' :
					case 'regex_email_not' :

						var pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
						result_condition = pattern.test(object_value);
						if(logic == 'regex_email_not') { result_condition = !result_condition; }
						break;

					// Regex - URL
					case 'regex_url' :
					case 'regex_url_not' :

						var pattern = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
						result_condition = pattern.test(object_value);
						if(logic == 'regex_url_not') { result_condition = !result_condition; }
						break;

					// Matches regex
					case 'regex' :
					case 'regex_not' :

						var pattern = new RegExp(value);
						result_condition = pattern.test(object_value);
						if(logic == 'regex_not') { result_condition = !result_condition; }
						break;

					// Events
					case 'wsf-rendered' :

					case 'wsf-submit' :
					case 'wsf-save' :
					case 'wsf-submit-save' :

					case 'wsf-submit-complete' :
					case 'wsf-save-complete' :
					case 'wsf-complete' :

					case 'wsf-submit-error' :
					case 'wsf-save-error' :
					case 'wsf-error' :

					case 'wsf-submit-success' :
					case 'wsf-save-success' :
					case 'wsf-success' :

					case 'click' :

					case 'mousedown' :
					case 'mouseup' :
					case 'mouseover' :
					case 'mouseout' :

					case 'touchstart' :
					case 'touchmove' :
					case 'touchend' :
					case 'touchcancel' :

					case 'focus' :
					case 'blur' :
					case 'change' :
					case 'change_input' :
					case 'input' :

					case 'keyup' :
					case 'keydown' :

						conditional.last_state[source_repeatable_index] = '';
						result_condition = (

							(logic == event.type) ||			// User triggered events
							('wsf-' + logic == event.type) ||	// WS Form triggered events

							// Multi-event triggers
							((logic == 'change_input') && (['change', 'input'].indexOf(event.type) != -1)) ||
							((logic == 'wsf-submit-save') && (['wsf-submit', 'wsf-save'].indexOf(event.type) != -1))
						);
						break;

					// Token validation
					case 'token_validated' :
					case 'token_validated_not' :

						result_condition = (this.submit !== false) && (typeof(this.submit.token_validated) !== 'undefined') && this.submit.token_validated;
						if(logic == 'token_validated_not') { result_condition = !result_condition; }
						break;

					// User
					case 'user_logged_in' :
					case 'user_logged_in_not' :
					case 'user_role' :
					case 'user_role_not' :
					case 'user_capability' :
					case 'user_capability_not' :

						result_condition = force_result;
						break;

					// Color - Hue greater than
					case 'ch>' :

						var hsl = this.hex_to_hsl(object_value);
						result_condition = ((hsl.h * 360) > value);
						break;

					// Color - Hue less than
					case 'ch<' :

						var hsl = this.hex_to_hsl(object_value);
						result_condition = ((hsl.h * 360) < value);
						break;

					// Color - Saturation greater than
					case 'cs>' :

						var hsl = this.hex_to_hsl(object_value);
						result_condition = ((hsl.s * 100) > value);
						break;

					// Color - Saturation less than
					case 'cs<' :

						var hsl = this.hex_to_hsl(object_value);
						result_condition = ((hsl.s * 100) < value);
						break;

					// Color - Lightness greater than
					case 'cl>' :

						var hsl = this.hex_to_hsl(object_value);
						result_condition = ((hsl.l * 100) > value);
						break;

					// Color - Lightness less than
					case 'cl<' :

						var hsl = this.hex_to_hsl(object_value);
						result_condition = ((hsl.l * 100) < value);
						break;

					// Check recaptcha is valid
					case 'recaptcha' :
					case 'recaptcha_not' :

						result_condition = (this.recaptcha_get_response_by_name(field_name) != '');
						if(logic == 'recaptcha_not') { result_condition = !result_condition; }
						break;

					// Check signature is valid
					case 'signature' :
					case 'signature_not' :

						result_condition = this.signature_get_response_by_name(field_name);
						if(logic == 'signature_not') { result_condition = !result_condition; }
						break;

					// Check file is valid
					case 'file' :
					case 'file_not' :

						result_condition = (this.file_get_count_by_field_id(object_id) > 0);
						if(logic == 'file_not') { result_condition = !result_condition; }
						break;

					// File count greater than
					case 'f>' :

						result_condition = (this.file_get_count_by_field_id(object_id) > value);
						break;

					// Files count less than
					case 'f<' :

						result_condition = (this.file_get_count_by_field_id(object_id) < value);
						break;

					// Files less than
					case 'f==' :
					case 'f!=' :

						result_condition = (this.file_get_count_by_field_id(object_id) == value);
						if(logic == 'f!=') { result_condition = !result_condition; }
						break;

					// Check fields match
					case 'field_match' :
					case 'field_match_not' :

						var field_id = parseInt(value, 10);
						if(field_id > 0) {

							var field_selector = '#' + this.form_id_prefix + 'field-' + field_id;
							var field_value = $(field_selector, this.form_canvas_obj).val();

							result_condition = (field_value == object_value);
							if(logic == 'field_match_not') { result_condition = !result_condition; }
						}
						break;

					// Character count equals (Exact)
					case 'cc==' :

						result_condition = (object_value.length == parseInt(value, 10));
						break;

					// Character count does not equal
					case 'cc!=' :

						result_condition = (object_value.length != parseInt(value, 10));
						break;

					// Character count greater than
					case 'cc>' :

						result_condition = (object_value.length > parseInt(value, 10));
						break;

					// Character count less than
					case 'cc<' :

						result_condition = (object_value.length < parseInt(value, 10));
						break;

					// Word count equals (Exact)
					case 'cw==' :

						result_condition = (this.get_word_count(object_value) == parseInt(value, 10));
						break;

					// Word count does not equal
					case 'cw!=' :

						result_condition = (this.get_word_count(object_value) != parseInt(value, 10));
						break;

					// Word count greater than
					case 'cw>' :

						result_condition = (this.get_word_count(object_value) > parseInt(value, 10));
						break;

					// Word count less than
					case 'cw<' :

						result_condition = (this.get_word_count(object_value) < parseInt(value, 10));
						break;

					// Form - Validates
					case 'validate' :
					case 'validate_not' :

						switch(object) {

							case 'form' :

								result_condition = this.form_valid;
								break;

							case 'group' :

								result_condition = this.object_validate($(object_event_selector, this.form_canvas_obj));
								break;

							case 'section' :

								result_condition = this.object_validate($(object_event_selector, this.form_canvas_obj));
								break;

							case 'field' :

								result_condition = this.object_validate(object_wrapper);
								break;
						}

						if(logic == 'validate_not') { result_condition = !result_condition; }
						break;
				}

				// Add condition result to group result
				result_group = this.conditional_logic_previous(result_group, result_condition, logic_previous);
			}

			// Group logic
			var logic_previous = (group_index > 0) ? ((typeof(group.logic_previous) === 'undefined') ? '||' : group.logic_previous) : '||';

			// Add group result to conditions result
			result_conditions = this.conditional_logic_previous(result_conditions, result_group, logic_previous);
		}

		var condition_process_thenelse = false;
		if(result_conditions) {

			// Ensure 'then' fires once
			if(
				(conditional.last_state[source_repeatable_index] !== true) ||
				(typeof(conditional.last_state[source_repeatable_index]) === 'undefined')
			) {

				condition_process_thenelse = 'then';
				conditional.last_state[source_repeatable_index] = true;
			}

		} else {

			// Ensure 'else' fires once
			if(
				(conditional.last_state[source_repeatable_index] !== false) ||
				(typeof(conditional.last_state[source_repeatable_index]) === 'undefined')
			) {

				condition_process_thenelse = 'else';
				conditional.last_state[source_repeatable_index] = false;
			}
		}

		if(condition_process_thenelse !== false) {

			var actions = conditional[condition_process_thenelse];

			if(actions.length) {

				if($.WS_Form.debug_rendered) {

					this.log('log_conditional_fired_' + condition_process_thenelse, conditional_description, 'conditional');
				}

				// Process action
				this.conditional_process_actions(actions, condition_process_thenelse, source_obj, source_repeatable_index);
			}
		}

		// Recalculate e-commerce
		if(!initial && this.has_ecommerce) { this.form_ecommerce_calculate(); }
	}

	$.WS_Form.prototype.conditional_process_actions = function(actions, action_then_else, source_obj, source_repeatable_index) {

		var actions_processed = 0;
		var process_required = false;
		var process_bypass = false;
		var process_navigation = false;
		var ws_this = this;

		for(var action_index in actions) {

			if(!actions.hasOwnProperty(action_index)) { continue; }

			var action_single = actions[action_index];

			// Check integrity of action
			if(!this.conditional_action_check(action_single)) { continue; }

			// Read action data
			var destination_object = action_single['object'];
			var destination_object_id = action_single['object_id'];
			var destination_object_row_id = (typeof(action_single['object_row_id']) === 'undefined') ? false : action_single['object_row_id'];
			var destination_action = action_single['action'];

			// Process by object type
			switch(destination_object) {

				case 'form' :

					// Get object wrapper
					var destination_obj_wrapper = ws_this.form_obj;

					// Get object
					var destination_obj = ws_this.form_obj;

					// Get value parsed
					var destination_value = (typeof(action_single['value']) === 'undefined') ? false : this.parse_variables_process(action_single['value'], false, false, false, false, false).output;

					// Process action
					var conditional_process_action_return = this.conditional_process_action(action_then_else, destination_action, destination_obj_wrapper, destination_obj, destination_object, destination_object_id, destination_object_row_id, destination_value, false);
					process_required = process_required || conditional_process_action_return.process_required;
					process_bypass = process_bypass || conditional_process_action_return.process_bypass;
					process_navigation = process_navigation || conditional_process_action_return.process_navigation;

					break;

				case 'group' :

					// Build group selector
					var destination_selector = '#' + this.form_id_prefix + 'group-' + destination_object_id;

					// Get object wrapper and object
					var destination_obj_wrapper = destination_obj = $(destination_selector, this.form_canvas_obj);

					// Get value parsed
					var destination_value = (typeof(action_single['value']) === 'undefined') ? false : this.parse_variables_process(action_single['value'], false, false, false, false, false).output;

					// Process action
					var conditional_process_action_return =  this.conditional_process_action(action_then_else, destination_action, destination_obj_wrapper, destination_obj, destination_object, destination_object_id, destination_object_row_id, destination_value, false);
					process_required = process_required || conditional_process_action_return.process_required;
					process_bypass = process_bypass || conditional_process_action_return.process_bypass;
					process_navigation = process_navigation || conditional_process_action_return.process_navigation;

					break;

				case 'section' :

					// Get source section ID
					var source_section_id = this.get_section_id(source_obj);

					// Get all instances of the destination section
					var destination_wrappers = $('[id^="' + this.form_id_prefix + 'section-"][data-id="' + destination_object_id + '"]', this.form_canvas_obj);
					if(!destination_wrappers.length) { break; }
					var destination_wrapper_first = destination_wrappers.first();

					// Same section?
					if(source_section_id === parseInt(destination_object_id, 10)) {

						// Section is repeatable?
						if(destination_wrapper_first.attr('data-repeatable-index')) {

							// Filter by repeatable index
							destination_wrappers = destination_wrappers.filter('[data-repeatable-index="' + source_repeatable_index + '"]');
						}
					}					

					destination_wrappers.each(function() {

						// Get destination repeatable index (This is used to localize the conditional_process_action)
						var destination_repeatable_index = ((typeof($(this).attr('data-repeatable-index')) !== 'undefined') ? $(this).attr('data-repeatable-index') : false);

						// Get value parsed
						var destination_value = (typeof(action_single['value']) === 'undefined') ? false : ws_this.parse_variables_process(action_single['value'], destination_repeatable_index, false, false, false, false, false).output;

						// Process action
						var conditional_process_action_return = ws_this.conditional_process_action(action_then_else, destination_action, $(this), $(this), destination_object, destination_object_id, destination_object_row_id, destination_value, destination_repeatable_index);
						process_required = process_required || conditional_process_action_return.process_required;
						process_bypass = process_bypass || conditional_process_action_return.process_bypass;
						process_navigation = process_navigation || conditional_process_action_return.process_navigation;
					});

					break;

				case 'field' :

					// Get source section ID
					var source_section_id = this.get_section_id(source_obj);

					// Get all instances of the destination field
					var destination_wrappers = $('[id^="' + this.form_id_prefix + 'field-wrapper-"][data-id="' + destination_object_id + '"],input[type="hidden"][data-id-hidden="' + destination_object_id + '"]', this.form_canvas_obj);
					if(!destination_wrappers.length) { break; }
					var destination_wrapper_first = destination_wrappers.first();

					// Get destination section ID
					var destination_section_id = this.get_section_id(destination_wrapper_first.first());

					// Same section?
					if(source_section_id === destination_section_id) {

						// Section is repeatable?
						if(destination_wrapper_first.attr('data-repeatable-index')) {

							// Filter by repeatable index
							destination_wrappers = destination_wrappers.filter('[data-repeatable-index="' + source_repeatable_index + '"]');
						}
					}					

					destination_wrappers.each(function() {

						// Get destination repeatable index (This is used to localize the conditional_process_action)
						var destination_repeatable_index = ((typeof($(this).attr('data-repeatable-index')) !== 'undefined') ? $(this).attr('data-repeatable-index') : false);

						// Get destination repeatable suffix
						var destination_repeatable_suffix = (destination_repeatable_index !== false) ? '-repeat-' + destination_repeatable_index : '';

						// Get destination obj
						var destination_selector = '#' + ws_this.form_id_prefix + 'field-' + destination_object_id + (destination_object_row_id ? '-row-' + destination_object_row_id : '') + destination_repeatable_suffix;
						var destination_obj = $(destination_selector, ws_this.form_canvas_obj);

						// Get field_to
						var field_to = (typeof(ws_this.field_data_cache[destination_object_id]) !== 'undefined') ? ws_this.field_data_cache[destination_object_id] : false;

						// Get value parsed
						var destination_value = (typeof(action_single['value']) === 'undefined') ? false : ws_this.parse_variables_process(action_single['value'], destination_repeatable_index, false, false, field_to, false, false).output;

						// Process action
						var conditional_process_action_return = ws_this.conditional_process_action(action_then_else, destination_action, $(this), destination_obj, destination_object, destination_object_id, destination_object_row_id, destination_value, destination_repeatable_index);
						process_required = process_required || conditional_process_action_return.process_required;
						process_bypass = process_bypass || conditional_process_action_return.process_bypass;
						process_navigation = process_navigation || conditional_process_action_return.process_navigation;
					});

					break;

				case 'action' :

					// Get value parsed
					var destination_value = (typeof(action_single['value']) === 'undefined') ? false : ws_this.parse_variables_process(action_single['value'], false, false, false, false, false).output;

					// Process action
					var conditional_process_action_return = ws_this.conditional_process_action(action_then_else, destination_action, $(this), false, destination_object, destination_object_id, destination_object_row_id, destination_value, false);
					process_required = process_required || conditional_process_action_return.process_required;
					process_bypass = process_bypass || conditional_process_action_return.process_bypass;
					process_navigation = process_navigation || conditional_process_action_return.process_navigation;

					break;
			}

			// Increment number of actions processed
			actions_processed++;
		}

		// Process required?
		if(process_required) {

			this.form_progress();
			this.form_required();
		}

		// Process bypass?
		if(process_bypass) {

			this.form_bypass(true);
			this.form_tab_validation_process();
		}

		// Process navigation?
		if(process_navigation) {

			this.form_navigation();
		}

		return actions_processed;
	}

	$.WS_Form.prototype.conditional_process_action = function(action_then_else, action, obj_wrapper, obj, object, object_id, object_row_id, value, section_repeatable_index) {

		if(typeof(value) === 'undefined') { value = ''; }

		// Get selector href
		var selector_href = (typeof(this.framework.tabs.public.selector_href) !== 'undefined') ? this.framework.tabs.public.selector_href : 'href';

		// Build field name
		var field_name = ws_form_settings.field_prefix + object_id + (section_repeatable_index ? '[' + section_repeatable_index + ']' : '');

		// Set debug action value
		var debug_action_value = value;
		var debug_action_language_id = false;

		// Process required?
		var process_required = false;

		// Process bypass?
		var process_bypass = false;

		// Process navigation?
		var process_navigation = false;

		switch(action) {

			// Set value
			case 'value' :
			case 'value_number' :
			case 'value_datetime' :
			case 'value_tel' :
			case 'value_email' :
			case 'value_textarea' :

				// Price formatting (Ensure correctly foratted price is injected into price fields for the currency input mask)
				switch(obj_wrapper.attr('data-type')) {

					case 'price' :
					case 'cart_price' :

						// Check for blank values
						if(value === '') { value = '0'; }

						// Check if value is a number, if not, try to convert it using current website currency format
						if(isNaN(value)) { 

							var value = this.get_number(value);
						}

						// Convert to price in website currency format (Expects value to be in regular 12.345 format)
						value = this.get_price(value);
						break;
				}

				// Set value
				obj.attr('data-value-old', function() { return $(this).val(); }).val(value).filter(function() { return $(this).val() !== $(this).attr('data-value-old') }).trigger('change').removeAttr('data-value-old');

				// Text area
				if(action === 'value_textarea') {

					this.textarea_set_value(obj, value);
				}

				break;

			case 'value_range' : 
			case 'value_rating' :

				obj.attr('data-value-old', function() { return $(this).val(); }).val(value).filter(function() { return $(this).val() !== $(this).attr('data-value-old') }).trigger('change').removeAttr('data-value-old');
				break;

			case 'value_color' :

				if(obj.hasClass('minicolors-input')) {

					obj.attr('data-value-old', function() { return $(this).val(); }).minicolors('value', {color: value}).filter(function() { return $(this).val() !== $(this).attr('data-value-old') }).trigger('change').removeAttr('data-value-old');

				} else {

					obj.attr('data-value-old', function() { return $(this).val(); }).val(value).filter(function() { return $(this).val() !== $(this).attr('data-value-old') }).trigger('change').removeAttr('data-value-old');
				}
				break;

			// Set HTML
			case 'html' :

				$('[data-html],[data-text-editor]', obj_wrapper).html(value);
				break;

			// Set text editor
			case 'text_editor' :

				$('[data-text-editor]', obj_wrapper).html(value);
				break;

			// Set button label
			case 'button_html' :

				obj.html(value);
				break;

			// Add class (Wrapper)
			case 'class_add_wrapper' :

				obj_wrapper.addClass(value);
				debug_action_language_id = 'debug_action_added';
				break;

			// Remove class
			case 'class_remove_wrapper' :

				obj_wrapper.removeClass(value);
				debug_action_language_id = 'debug_action_removed';
				break;

			// Add class (Wrapper)
			case 'class_add_field' :

				obj.addClass(value);
				debug_action_language_id = 'debug_action_added';
				break;

			// Remove class
			case 'class_remove_field' :

				obj.removeClass(value);
				debug_action_language_id = 'debug_action_removed';
				break;

			// Reset file input
			case 'reset_file' :

				obj.attr('data-value-old', function() { return $(this).val(); }).val('').filter(function() { return $(this).val() !== $(this).attr('data-value-old') }).trigger('change').removeAttr('data-value-old');
				debug_action_language_id = 'debug_action_reset';
				break;

			// Reset signature
			case 'reset_signature' :

				this.signature_clear_by_name(field_name);
				debug_action_language_id = 'debug_action_reset';
				break;

			// Select an option
			case 'value_row_select' :
			case 'value_row_deselect' :

				if(!obj.is(':enabled')) { break; }
				var trigger = (obj.prop('selected') !== (action == 'value_row_select'));
				obj.prop('selected', false).prop('selected', (action == 'value_row_select'));
				if(trigger) { obj.closest('select').trigger('change'); }
				debug_action_language_id = 'debug_action_' + ((action == 'value_row_select') ? 'selected' : 'deselected');
				break;

			// Select an option by value
			case 'value_row_select_value' :
			case 'value_row_deselect_value' :

				var trigger = ($('option[value="' + this.html_encode(value) + '"]', obj).prop('selected') !== (action == 'value_row_select_value'));
				$('option[value="' + this.html_encode(value) + '"]', obj).prop('selected', (action == 'value_row_select_value'));
				if(trigger) { obj.trigger('change'); }
				debug_action_language_id = 'debug_action_' + ((action == 'value_row_select_value') ? 'selected_value' : 'deselected_value');
				break;

			// Unselect all options (Clear)
			case 'value_row_reset' :

				obj_wrapper.find('option:enabled').prop('selected', true).prop('selected', false).trigger('change');
				debug_action_language_id = 'debug_action_reset';
				break;

			// Check/uncheck a checkbox or radio
			case 'value_row_check' :
			case 'value_row_uncheck' :

				if(!obj.is(':enabled')) { break; }
				var trigger = (obj.prop('checked') !== (action == 'value_row_check'));
				obj.prop('checked', (action == 'value_row_check'));
				if(trigger) { obj.trigger('change'); }
				debug_action_language_id = 'debug_action_' + ((action == 'value_row_check') ? 'checked' : 'unchecked');
				break;

			// Check/uncheck a checkbox or radio. by value
			case 'value_row_check_value' :
			case 'value_row_uncheck_value' :

				var trigger = ($('input[value="' + this.html_encode(value) + '"]', obj_wrapper).prop('checked') !== (action == 'value_row_check_value'));
				$('input[value="' + this.html_encode(value) + '"]', obj_wrapper).prop('checked', (action == 'value_row_check_value'));
				if(trigger) { $('input[value="' + this.html_encode(value) + '"]', obj_wrapper).trigger('change'); }
				debug_action_language_id = 'debug_action_' + ((action == 'value_row_check_value') ? 'checked' : 'unchecked');
				break;

			// Set required on a checkbox or radio
			case 'value_row_required' :
			case 'value_row_not_required' :

				// Set required attribute
				obj.prop('required', (action == 'value_row_required')).removeAttr('data-init-required');

				if(action == 'value_row_required') {

					// Set ARIA required
					obj.attr('data-required', '').attr('aria-required', 'true').removeAttr('data-conditional-logic-bypass');

				} else {

					// Set ARIA not required
					obj.removeAttr('data-required').removeAttr('aria-required').attr('data-conditional-logic-bypass', '');
				}

				debug_action_language_id = 'debug_action_' + ((action == 'value_row_required') ? 'required' : 'not_required');

				process_required = true;
				process_bypass = true;

				break;

			// Set disabled on a checkbox or radio
			case 'value_row_disabled' :
			case 'value_row_not_disabled' :

				obj.attr('disabled', (action == 'value_row_disabled'));

				// Re-render select2 (Fixes select2 bug where disable attribute is not updated)
				if(typeof(obj.parent().attr('data-wsf-select2')) !== 'undefined') {

					this.form_select_ajax(obj.parent());
				}

				debug_action_language_id = 'debug_action_' + ((action == 'value_row_disabled') ? 'disabled' : 'enabled');
				break;

			// Set visible on a checkbox or radio
			case 'value_row_visible' :
			case 'value_row_not_visible' :

				if(action === 'value_row_not_visible') { obj.parent().hide(); } else { obj.parent().show(); }
				debug_action_language_id = 'debug_action_' + ((action == 'value_row_not_visible') ? 'hide' : 'show');
				break;

			// Focus checkbox or radio
			case 'value_row_focus' :

				obj.trigger('focus');
				debug_action_language_id = 'debug_action_focussed';
				break;

			// Add class
			case 'value_row_class_add' :

				obj.addClass(value);
				debug_action_language_id = 'debug_action_added';
				break;

			// Remove class
			case 'value_row_class_remove' :

				obj.removeClass(value);
				debug_action_language_id = 'debug_action_removed';
				break;

			// Set custom validity
			case 'value_row_set_custom_validity' :

				// Set invalid feedback
				this.set_invalid_feedback(obj, value, object_row_id);

				// Process bypass
				process_bypass = true;

				break;

			// Set min / max / step (Floating point)
			case 'min' :
			case 'max' :
			case 'step' :

				value = (value != '') ? this.get_float(value, 0) : false;

				this.obj_set_attribute(obj, action, value);

				break;

			// Set min / max / step (Integer)
			case 'min_int' :
			case 'max_int' :
			case 'step_int' :

				var action_int = action.replace('_int', '');

				value = (value != '') ? this.get_number(value, 0, false) : false;

				this.obj_set_attribute(obj, action_int, value);

				break;

			// Set e-commerce min / max
			case 'ecommerce_price_min' :
			case 'ecommerce_price_max' :

				value = (value != '') ? this.get_float(value, 0) : false;

				// Get old value before change
				var obj_value_old = obj.val();

				// Set attribute
				this.obj_set_attribute(obj, 'data-ecommerce-' + ((action === 'ecommerce_price_min') ? 'min' : 'max'), value);

				// Re-process currency input mask
				this.form_ecommerce_input_mask_currency(obj);

				// Trigger change if value changes due to min / max being applied
				if(obj.val() !== obj_value_old) { obj.trigger('change'); }

				break;

			// Set select min / max
			case 'select_min' :
			case 'select_max' :

				var min_max = (action === 'select_min') ? 'min' : 'max';

				value = (value != '') ? this.get_number(value, 0, false) : false;

				var form_select_min_max_process = (typeof(obj_wrapper.attr('data-select-min-max-init')) === 'undefined');

				if(value !== false) {

					obj_wrapper.attr('data-select-' + min_max, value);

				} else {

					obj_wrapper.removeAttr('data-select-' + min_max);
				}

				if(form_select_min_max_process) {

					this.form_select_min_max();

				} else {

					var input_number = $('input[type="number"]', obj_wrapper); 

					this.obj_set_attribute(input_number, min_max, value);
				}

				break;

			// Set checkbox min / max
			case 'checkbox_min' :
			case 'checkbox_max' :

				var min_max = (action === 'checkbox_min') ? 'min' : 'max';

				value = (value != '') ? this.get_number(value, 0, false) : false;

				var form_checkbox_min_max_process = (typeof(obj_wrapper.attr('data-checkbox-min-max-init')) === 'undefined');

				if(value !== false) {

					obj_wrapper.attr('data-checkbox-' + min_max, value);

				} else {

					obj_wrapper.removeAttr('data-checkbox-' + min_max);
				}

				if(form_checkbox_min_max_process) {

					this.form_checkbox_min_max();

				} else {

					var input_number = $('input[type="number"]', obj_wrapper); 

					this.obj_set_attribute(input_number, min_max, value);
				}

				break;

			// Set visibility
			case 'visibility' :

				switch(object) {

					// Tab
					case 'group' :

						var group_tab_obj = $('[' + selector_href + '="#' + this.form_id_prefix + 'group-' + object_id + '"]', this.form_canvas_obj).parent();

						if(value === 'off') {

							// Is tab being hidden currently visible?
							var obj_visible = obj_wrapper.is(':visible');

							if(obj_visible) {

								// Attempt to find first hidden tab and show it
								var groups_visible = $('[id^="' + this.form_id_prefix + 'group-"]:not([data-wsf-group-hidden])');

								if(groups_visible.length) {

									var group_id = groups_visible.first().attr('id');

									$('[' + selector_href + '="#' + group_id + '"]').trigger('click');
								}
							}

							// Hide tab
							group_tab_obj.attr('data-wsf-group-hidden', '').hide().attr('aria-live', 'polite').attr('aria-hidden', 'true');

							// Hide tab content
							obj_wrapper.attr('data-wsf-group-hidden', '').attr('aria-live', 'polite').attr('aria-hidden', 'true');

							debug_action_language_id = 'debug_action_hide';

						} else {

							// Show tab
							group_tab_obj.removeAttr('data-wsf-group-hidden').show().removeAttr('aria-hidden');

							// Show tab content
							obj_wrapper.removeAttr('data-wsf-group-hidden').removeAttr('aria-hidden');

							debug_action_language_id = 'debug_action_show';
						}

						// Process bypass
						process_bypass = true;

						// Process navigation
						process_navigation = true;

						break;

					// Field / section visibility
					case 'section' :
					case 'field' :

						if(value === 'off') {

							// Hide object
							obj_wrapper.hide().attr('aria-live', 'polite').attr('aria-hidden', 'true');

							// Process bypass
							process_bypass = true;

							debug_action_language_id = 'debug_action_hide';

						} else {

							// Show object
							obj_wrapper.show().removeAttr('aria-hidden');

							// Process bypass
							process_bypass = true;

							// Redraw signatures
							if(object == 'section') { this.signatures_redraw(false, object_id); }
							if(object == 'field') { this.signatures_redraw(false, false, object_id); }

							debug_action_language_id = 'debug_action_show';
						}

						break;
				}

				break;

			// Set row count
			case 'set_row_count' :

				// Get sections
				var sections = $('[data-repeatable][data-id="' + object_id + '"]', this.form_canvas_obj);
				if(!sections.length) { break; }
				var section_count = sections.length;
				if(isNaN(value)) { break; }
				var section_count_required = parseInt(value, 10);

				// Get section data
				var section = this.section_data_cache[object_id];

				// Section repeat - Min
				var section_repeat_min = this.get_object_meta_value(section, 'section_repeat_min', 1);
				if(
					(section_repeat_min == '') ||
					isNaN(section_repeat_min)

				) { section_repeat_min = 1; } else { section_repeat_min = parseInt(section_repeat_min, 10); }
				if(section_repeat_min < 1) { section_repeat_min = 1; }

				// Section repeat - Max
				var section_repeat_max = this.get_object_meta_value(section, 'section_repeat_max', false);
				if(
					(section_repeat_max == '') ||
					isNaN(section_repeat_min)

				) { section_repeat_max = false; } else { section_repeat_max = parseInt(section_repeat_max, 10); }

				// Checks
				if(section_count_required < section_repeat_min) { section_count_required = section_repeat_min; }
				if((section_repeat_max !== false) && (section_count_required > section_repeat_max)) {

					section_count_required = section_repeat_max;
				}

				// Add rows
				if(section_count < section_count_required) {

					// Get section obj to clone
					var section_clone_this = sections.last();

					// Calculate number of rows to add
					var rows_to_add = (section_count_required - section_count);
					for(var add_count = 0; add_count < rows_to_add; add_count++) {

						// Clone
						this.section_clone(section_clone_this);
					}

					// Initialize added section
					this.section_add_init(object_id);

					// Trigger event
					this.form_canvas_obj.trigger('wsf-section-repeatable').trigger('wsf-section-repeatable-' + object_id);
				}

				// Delete rows
				if(section_count > section_count_required) {

					// Calculate number of rows to delete
					var rows_to_delete = (section_count - section_count_required);
					for(var delete_count = 0; delete_count < rows_to_delete; delete_count++) {

						var sections = $('[data-repeatable][data-id="' + object_id + '"]', this.form_canvas_obj);
						sections.last().remove();
					}

					// Initialize removed section
					this.section_remove_init(object_id);

					// Trigger event
					this.form_canvas_obj.trigger('wsf-section-repeatable').trigger('wsf-section-repeatable-' + object_id);
				}

				break;

			// Disable
			case 'disabled' :

				switch(object) {

					case 'section' :

						// For sections, we need to look for a fieldset
						obj_wrapper.prop('disabled', (value == 'on'));

						if(value == 'on') {

							obj_wrapper.attr('aria-disabled', 'true');

						} else {

							obj_wrapper.removeAttr('aria-disabled');
						}

						var obj_array = $('[name]', obj_wrapper);

						break;

					case 'field' :

						var obj_array = obj;

						break;
				}

				var ws_this = this;

				$(obj_array).each(function() {

					$(this).prop('disabled', (value == 'on'));

					if(value == 'on') {

						$(this).attr('aria-disabled', 'true');

					} else {

						$(this).removeAttr('aria-disabled');
					}

					var obj_wrapper = $(this).closest('[data-type]');

					var class_disabled_array = ws_this.get_field_value_fallback(obj_wrapper.attr('data-type'), false, 'class_disabled', false);

					if(value == 'on') {

						if(class_disabled_array !== false) { $(this).addClass(class_disabled_array.join(' ')); }
						$(this).css({'pointer-events': 'none'}).attr('data-conditional-logic-bypass', '');

					} else {

						if(class_disabled_array !== false) { $(this).removeClass(class_disabled_array.join(' ')); }
						$(this).css({'pointer-events': 'auto'}).removeAttr('data-conditional-logic-bypass');
					}

					switch(obj_wrapper.attr('data-type')) {

						case 'file' :

							switch($(this).attr('data-file-type')) {

								case 'dropzonejs' :

									if(value == 'on') {

										$('.dropzone', obj_wrapper)[0].dropzone.disable();

									} else {

										$('.dropzone', obj_wrapper)[0].dropzone.enable();
									}

									break;
							}

							break;
					}
				})

				// Process navigation
				process_navigation = true;

				debug_action_language_id = 'debug_action_' + ((value == 'on') ? 'disabled' : 'enabled');
				break;

			// Required
			case 'required' :

				// Get field data
				var field = this.field_data_cache[object_id];
				switch(field.type) {

					case 'radio' :
					case 'price_radio' :

						obj = $('[name="' + field_name + '[]"]', obj_wrapper);
						break;
				}

				// Set required attribute
				obj.prop('required', (value == 'on')).removeAttr('data-init-required');

				if(value == 'on') {

					// Set ARIA required
					obj.attr('data-required', '').attr('aria-required', 'true').removeAttr('data-conditional-logic-bypass');

				} else {

					// Set ARIA not required
					obj.removeAttr('data-required').removeAttr('aria-required').attr('data-conditional-logic-bypass', '');
				}

				debug_action_language_id = 'debug_action_' + ((value == 'on') ? 'required' : 'not_required');

				process_required = true;
				process_bypass = true;

				break;

			// Required - Signature
			case 'required_signature' :

				// Set required attribute
				obj.prop('required', (value == 'on')).removeAttr('data-init-required');

				if(value == 'on') {

					// Set ARIA required
					obj.attr('data-required', '').attr('aria-required', 'true').removeAttr('data-conditional-logic-bypass');

				} else {

					// Set ARIA not required
					obj.removeAttr('data-required').removeAttr('aria-required').attr('data-conditional-logic-bypass', '');
				}

				debug_action_language_id = 'debug_action_' + ((value == 'on') ? 'required' : 'not_required');

				process_required = true;
				process_bypass = true;

				break;

			// Read only
			case 'readonly' :

				obj.prop('readonly', (value == 'on'));

				if(value == 'on') {

					obj.attr('aria-readonly', 'true');

				} else {

					obj.removeAttr('aria-readonly');
				}

				debug_action_language_id = 'debug_action_' + ((value == 'on') ? 'read_only' : 'not_read_only');

				this.form_date();	// Destroy jQuery component if readonly

				break;

			// Set custom validity
			case 'set_custom_validity' :

				// Check for invalid_feedback_last_row
				var invalid_feedback_last_row = false;
				if(typeof(this.field_data_cache[object_id]) !== 'undefined') {

					var field = this.field_data_cache[object_id];

					if(typeof($.WS_Form.field_type_cache[field.type]) !== 'undefined') {

						var field_type_config = $.WS_Form.field_type_cache[field.type];

						invalid_feedback_last_row = (typeof(field_type_config.invalid_feedback_last_row) !== 'undefined') ? field_type_config.invalid_feedback_last_row : false
					}
				}

				// Get the invalid feedback object
				var invalid_feedback_obj = $('[id^="' + this.form_id_prefix + 'invalid-feedback-' + object_id + '"]', obj_wrapper);

				// If invalid feedback is only available on the last row, then set obj to sibling input
				if(invalid_feedback_last_row) {

					var obj = invalid_feedback_obj.siblings('[id^="' + this.form_id_prefix + 'field-' + object_id + '"]');
				}

				// Set invalid feedback
				this.set_invalid_feedback(obj, value, object_row_id);

				// Process bypass
				process_bypass = true;

				break;

			// Click
			case 'click' :

				switch(object) {

					// Tab click
					case 'group' :

						$('[' + selector_href + '="#' + this.form_id_prefix + 'group-' + object_id + '"]:not([data-wsf-tab-disabled])', this.form_canvas_obj).trigger('click');
						break;

					// Field click
					case 'field' :

						obj.trigger('click');
						break;
				}

				debug_action_language_id = 'debug_action_clicked';
				break;

			// Focus
			case 'focus' :

				if(this.conversational) {

					// Focus without scrolling
					this.conversational_scroll_start_x = this.form_obj.scrollLeft();
					this.conversational_scroll_start_y = this.form_obj.scrollTop();
				}

				obj.trigger('focus');

				debug_action_language_id = 'debug_action_focussed';

				break;

			// Action - Run
			case 'action_run' :

				if(this.conditional_actions_run_action.indexOf(object_id) !== -1) {

					this.form_post('action', object_id);
				}
				break;

			// Action - Enable on save
			case 'action_run_on_save' :

				if(this.conditional_actions_run_save.indexOf(object_id) === -1) {
					this.conditional_actions_run_save.push(object_id);
					this.conditional_actions_changed = true;
				}
				break;

			// Action - Enable on submit
			case 'action_run_on_submit' :

				if(this.conditional_actions_run_submit.indexOf(object_id) === -1) {
					this.conditional_actions_run_submit.push(object_id);
					this.conditional_actions_changed = true;
				}
				break;

			// Action - Disable on save
			case 'action_do_not_run_on_save' :

				var object_id_index = this.conditional_actions_run_save.indexOf(object_id);
				if (object_id_index !== -1) {
					this.conditional_actions_run_save.splice(object_id_index, 1);
					this.conditional_actions_changed = true;
				}
				break;

			// Action - Disable on submit
			case 'action_do_not_run_on_submit' :

				var object_id_index = this.conditional_actions_run_submit.indexOf(object_id);
				if (object_id_index !== -1) {
					this.conditional_actions_run_submit.splice(object_id_index, 1);
					this.conditional_actions_changed = true;
				}
				break;

			// Run JavaScript
			case 'javascript' :

				try {

					$.globalEval('(function($) {' + value + '})(jQuery);');

				} catch(e) {

					this.error('error_js', value);
				}
				break;

			// Form - Show validation
			case 'validate_show' :

				this.form_obj.addClass(this.class_validated);
				break;

			// Form - Hide validation
			case 'validate_hide' :

				this.form_obj.removeClass(this.class_validated);
				break;

			// Form - Save
			case 'form_save' :

				this.form_post('save');
				break;

			// Form - Save if validated
			case 'form_save_validate' :

				this.form_post_if_validated('save');
				break;

			// Form - Submit
			case 'form_submit' :

				this.form_obj.submit();
				break;

			// Form - Clear
			case 'form_clear' :

				this.form_clear();
				break;

			// Form - Reset
			case 'form_reset' :

				this.form_reset();
				break;

			// Reset
			// Clear
			case 'reset' :
			case 'clear' :

				var field_clear = (action === 'clear');

				switch(object) {

					case 'group' :

						this.group_fields_reset(object_id, field_clear);

						break;

					case 'section' :

						this.section_fields_reset(object_id, field_clear, section_repeatable_index);

						break;

					case 'field' :

						this.field_reset(object_id, field_clear, obj_wrapper);

						break;
				}

				break;
		}

		if($.WS_Form.debug_rendered) {

			var object_single_type = false;

			// Build action description for debug
			switch(object) {

				case 'form' :

					var object_single_type = this.language('debug_action_form');
					var object_single_label = this.language('debug_action_form');
					break;

				case 'group' :

					if(typeof(this.group_data_cache[object_id]) !== 'undefined') {

						var object_single = this.group_data_cache[object_id];
						var object_single_type = this.language('debug_action_group');
						var object_single_label = object_single.label;
					}
					break;

				case 'section' :

					if(typeof(this.section_data_cache[object_id]) !== 'undefined') {

						var object_single = this.section_data_cache[object_id];
						var object_single_type = this.language('debug_action_section');
						var object_single_label = object_single.label;
					}
					break;

				case 'field' :

					if(typeof(this.field_data_cache[object_id]) !== 'undefined') {

						var object_single = this.field_data_cache[object_id];						
						var object_single_type = object_single.type;
						var object_single_label = object_single.label;
					}
					break;

				case 'action' :

					if(typeof(this.action_data_cache[object_id]) !== 'undefined') {

						var object_single = this.action_data_cache[object_id];
						var object_single_type = this.language('debug_action_action');
						var object_single_label = object_single.label;
					}
					break;
			}

			if(object_single_type !== false) {

				if(debug_action_language_id !== false) { debug_action_value = this.language(debug_action_language_id); }

				var conditional_settings = $.WS_Form.settings_form.conditional;
				var conditional_settings_objects = conditional_settings.objects;
				var conditional_settings_actions = conditional_settings_objects[object]['action'];
				var conditional_settings_action = conditional_settings_actions[action];

				var action_description = conditional_settings_action.text.toUpperCase();
				if(typeof(conditional_settings_action.values) !== 'undefined') {

					if(typeof(conditional_settings_action.values) === 'object') {

						if(typeof(conditional_settings_action.values[value]) !== 'undefined') {

							debug_action_value = conditional_settings_action.values[value].text;
						}
					}
				}

				var log_description = '<strong>[' + this.html_encode(object_single_label) + '] ' + action_description + (((debug_action_value !== false) && (debug_action_value != '')) ? " '" + this.html_encode(debug_action_value) + "'" : '') + '</strong> (' + this.language('debug_action_type') + ': ' + object_single_type + ' | ID: ' + object_id + (object_row_id ? ' | ' + this.language('debug_action_row') + ' ID: ' + object_row_id : '') + ')';

				this.log('log_conditional_action_' + action_then_else, log_description, 'conditional');
			}
		}

		return { process_required: process_required, process_bypass: process_bypass, process_navigation: process_navigation };
	}

	// Convert hex color to RGB values
	$.WS_Form.prototype.hex_to_hsl = function(color) {

		// Get RGB of hex color
		var rgb = this.hex_to_rgb(color);
		if(rgb === false) { return false; }

		// Get HSL of RGB
		var hsl = this.rgb_to_hsl(rgb);

		return hsl;
	}

	// Convert hex color to RGB values
	$.WS_Form.prototype.hex_to_rgb = function(color) {

		// If empty, return false
		if(color == '') { return false; }

		// Does color have a hash?
		var color_has_hash = (color[0] == '#');

		// Check
		if(color_has_hash && (color.length != 7)) { return false; }
		if(!color_has_hash && (color.length != 6)) { return false; }

		// Strip hash
		var color = color_has_hash ? color.substr(1) : color;

		// Get RGB values
		var r = parseInt(color.substr(0,2), 16);
		var g = parseInt(color.substr(2,2), 16);
		var b = parseInt(color.substr(4,2), 16);

		return {'r': r, 'g': g, 'b': b};
	}

	// Convert RGB to HSL
	$.WS_Form.prototype.rgb_to_hsl = function(rgb) {

		if(typeof(rgb.r) === 'undefined') { return false; }
		if(typeof(rgb.g) === 'undefined') { return false; }
		if(typeof(rgb.b) === 'undefined') { return false; }

		var r = rgb.r;
		var g = rgb.g;
		var b = rgb.b;

		r /= 255, g /= 255, b /= 255;

		var max = Math.max(r, g, b), min = Math.min(r, g, b);
		var h, s, l = (max + min) / 2;

		if(max == min){
	
			h = s = 0;
	
		} else {
	
			var d = max - min;
			s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

			switch(max){
				case r: h = (g - b) / d + (g < b ? 6 : 0); break;
				case g: h = (b - r) / d + 2; break;
				case b: h = (r - g) / d + 4; break;
			}

			h /= 6;
		}

		return {'h': h, 's': s, 'l': l};
	}

	// Set object attribute (if false, remove the attribute)
	$.WS_Form.prototype.obj_set_attribute = function(obj, attribute, value) {

		if(typeof(obj.attr('data-' + attribute + '-bypass')) !== 'undefined') {

			if(value !== false) {

				obj.attr('data-' + attribute + '-bypass', value).trigger('change');

			} else {

				obj.removeAttr('data-' + attribute + '-bypass').trigger('change');
			}

		} else {

			if(value !== false) {

				obj.attr(attribute, value).trigger('change');

			} else {

				obj.removeAttr(attribute).trigger('change');
			}
		}
	}

	$.WS_Form.prototype.group_fields_reset = function(group_id, field_clear) {

		if(typeof(this.group_data_cache[group_id]) === 'undefined') { return false; }

		// Get group
		var group = this.group_data_cache[group_id];
		if(typeof(group.sections) === 'undefined') { return false; }

		// Get all fields in group
		var sections = group.sections;

		for(var section_index in sections) {

			if(!sections.hasOwnProperty(section_index)) { continue; }

			var section = sections[section_index];

			this.section_fields_reset(section.id, field_clear, false);
		}
	}

	$.WS_Form.prototype.section_fields_reset = function(section_id, field_clear, section_repeatable_index) {

		if(typeof(this.section_data_cache[section_id]) === 'undefined') { return false; }

		// Get section
		var section = this.section_data_cache[section_id];
		if(typeof(section.fields) === 'undefined') { return false; }

		// Get all fields in section
		var fields = section.fields;

		for(var field_index in fields) {

			if(!fields.hasOwnProperty(field_index)) { continue; }

			var field = fields[field_index];
			var field_id = field.id;

			if(section_repeatable_index === false) {

				var object_selector_wrapper = '[id^="' + this.form_id_prefix + 'field-wrapper-' + field_id + '"][data-id="' + field.id + '"]';

			} else {

				var object_selector_wrapper = '#' + this.form_id_prefix + 'field-wrapper-' + field_id + '-repeat-' + section_repeatable_index;
			}

			var obj_wrapper = $(object_selector_wrapper, this.form_canvas_obj);

			this.field_reset(field_id, field_clear, obj_wrapper);
		}
	}

	$.WS_Form.prototype.field_reset = function(field_id, field_clear, obj_wrapper) {

		var ws_this = this;

		if(typeof(obj_wrapper) === 'undefined') { obj_wrapper = false; }

		if(typeof(this.field_data_cache[field_id]) === 'undefined') { return; }

		var field = this.field_data_cache[field_id];

		var field_type_config = $.WS_Form.field_type_cache[field.type];
		var trigger_action = (typeof(field_type_config.trigger) !== 'undefined') ? field_type_config.trigger : 'change';

		switch(field.type) {

			case 'select' :

				$('option', obj_wrapper).each(function() {

					var selected_new = field_clear ? false : $(this).prop('defaultSelected');
					var trigger = $(this).prop('selected') !== selected_new;
					$(this).prop('selected', selected_new);
					if(trigger) { $(this).trigger(trigger_action); }
				});
				break;

			case 'checkbox' :

				$('input[type="checkbox"]', obj_wrapper).each(function() {

					var checked_new = field_clear ? false : $(this).prop('defaultChecked');
					var trigger = $(this).prop('checked') !== checked_new;
					$(this).prop('checked', checked_new);
					if(trigger) { $(this).trigger(trigger_action); }
				});
				break;

			case 'radio' :

				$('input[type="radio"]', obj_wrapper).each(function() {

					var checked_new = field_clear ? false : $(this).prop('defaultChecked');
					var trigger = $(this).prop('checked') !== checked_new;
					$(this).prop('checked', checked_new);
					if(trigger) { $(this).trigger(trigger_action); }
				});
				break;

			case 'textarea' :

				$('textarea', obj_wrapper).each(function() {

					var val_new = field_clear ? '' : $(this).prop('defaultValue');
					var trigger = $(this).val() !== val_new;
					$(this).val(val_new);
					ws_this.textarea_set_value($(this), val_new);
					if(trigger) { $(this).trigger('change'); }
				});
				break;

			case 'color' :

				$('input', obj_wrapper).each(function() {

					var val_new = field_clear ? '' : $(this).prop('defaultValue');
					var trigger = $(this).val() !== val_new;
					$(this).val(val_new);
					if($(this).hasClass('minicolors-input')) {
						$(this).minicolors('value', {color: val_new});
					}
					if(trigger) { $(this).trigger('change'); }
				});
				break;

			case 'hidden' :

				// Hidden fields don't have a wrapper so the obj_wrapper is the field. You cannot use the defaultValue property on hidden fields as it gets update when val() is used, so we use data-default-value attribute instead.
				var val_new = field_clear ? '' : obj_wrapper.attr('data-default-value');
				var trigger = obj_wrapper.val() !== val_new;
				obj_wrapper.val(val_new);
				if(trigger) { obj_wrapper.trigger(trigger_action); }
				break;

			case 'googlemap' :

				$('input', obj_wrapper).each(function() {

					var val_new = field_clear ? '' : $(this).attr('data-default-value');
					var trigger = $(this).val() !== val_new;
					$(this).val(val_new);
					if(trigger) { $(this).trigger(trigger_action); }
				});
				break;

			default :

				$('input', obj_wrapper).each(function() {

					var val_new = field_clear ? '' : $(this).prop('defaultValue');
					var trigger = $(this).val() !== val_new;
					$(this).val(val_new);
					if(trigger) { $(this).trigger(trigger_action); }
				});
		}
	}

	$.WS_Form.prototype.conditional_logic_previous = function(accumulator, value, logic_previous) {

		switch(logic_previous) {

			// OR
			case '||' :

				accumulator |= value;
				break;

			// AND
			case '&&' :

				accumulator &= value;
				break;
		}

		return accumulator;
	}

	// Check integrity of a condition
	$.WS_Form.prototype.conditional_condition_check = function(condition) {

		return !(

			(condition === null) ||
			(typeof(condition) !== 'object') ||
			(typeof(condition.id) === 'undefined') ||
			(typeof(condition.object) === 'undefined') ||
			(typeof(condition.object_id) === 'undefined') ||
			(typeof(condition.object_row_id) === 'undefined') ||
			(typeof(condition.logic) === 'undefined') ||
			(typeof(condition.value) === 'undefined') ||
			(typeof(condition.case_sensitive) === 'undefined') ||
			(typeof(condition.logic_previous) === 'undefined') ||
			(condition.id == '') ||
			(condition.id == 0) ||
			(condition.object == '') ||
			(condition.object_id == '') ||
			(condition.logic == '')
		);
	}

	// Check integrity of an action
	$.WS_Form.prototype.conditional_action_check = function(action) {

		return !(

			(action === null) ||
			(typeof(action) !== 'object') ||
			(typeof(action.object) === 'undefined') ||
			(typeof(action.object_id) === 'undefined') ||
			(typeof(action.action) === 'undefined') ||
			(action.object == '') ||
			(action.object_id == '') ||
			(action.action == '')
		);
	}

	// Group - Tabs - Init
	$.WS_Form.prototype.form_tabs = function() {

		if(this.form.groups.length <= 1) { return false; }

		var ws_this = this;

		// Get selector href
		var selector_href = (typeof(this.framework.tabs.public.selector_href) !== 'undefined') ? this.framework.tabs.public.selector_href : 'href';

		// Get tab index cookie if settings require it
		var index = parseInt((this.get_object_meta_value(this.form, 'cookie_tab_index')) ? this.cookie_get('tab_index', 0) : 0);

		// Check index is valid
		var tabs_obj = $('.wsf-group-tabs', this.form_canvas_obj);
		var li_obj = tabs_obj.children();
		if(
			(typeof(li_obj[index]) === 'undefined') ||
			(typeof($(li_obj[index]).attr('data-wsf-group-hidden')) !== 'undefined')
		) {

			index = 0;

			var li_obj_visible = $(':not([data-wsf-group-hidden])', li_obj);

			if(li_obj_visible.length) {

				index = li_obj_visible.first().index();
			}

			// Save current tab index to cookie
			if(ws_this.get_object_meta_value(ws_this.form, 'cookie_tab_index')) {

				ws_this.cookie_set('tab_index', index);
			}
		}

		// Progress for tabs
		this.form_progress_tabs(index);
		// If we are using the WS Form framework, then we need to run our own tabs script
		if($.WS_Form.settings_plugin.framework == ws_form_settings.framework_admin) {

			// Destroy tabs (Ensures subsequent calls work)
			if(tabs_obj.hasClass('wsf-tabs')) { this.tabs_destroy(); }

			// Init tabs
			this.tabs(tabs_obj, { active: index });

		} else {

			// Set active tab
			this.group_index_set(index);
		}

		var framework_tabs = this.framework['tabs']['public'];

		if(typeof(framework_tabs.event_js) !== 'undefined') {

			var event_js = framework_tabs.event_js;
			var event_type_js = (typeof(framework_tabs.event_type_js) !== 'undefined') ? framework_tabs.event_type_js : false;
			var event_selector_wrapper_js = (typeof(framework_tabs.event_selector_wrapper_js) !== 'undefined') ? framework_tabs.event_selector_wrapper_js : false;
			var event_selector_active_js = (typeof(framework_tabs.event_selector_active_js) !== 'undefined') ? framework_tabs.event_selector_active_js : false;

			switch(event_type_js) {

				case 'wrapper' :

					var event_selector = $(event_selector_wrapper_js, this.form_canvas_obj);
					break;

				default :

					var event_selector = $('[' + selector_href + '^="#' + this.form_id_prefix + 'group-"]', this.form_canvas_obj);
			}

			// Set up on click event for each tab
			event_selector.on(event_js, function (event, ui) {

				switch(event_type_js) {

					case 'wrapper' :

						var event_active_selector = $(event_selector_active_js, event_selector);
						var tab_index = event_active_selector.index();
						break;

					default :

						var tab_index = $(this).parent().index();
				}

				// Save current tab index to cookie
				if(ws_this.get_object_meta_value(ws_this.form, 'cookie_tab_index')) {

					ws_this.cookie_set('tab_index', tab_index);
				}

				// Progress for tabs
				ws_this.form_progress_tabs(tab_index);

				// Redraw signatures
				ws_this.signatures_redraw(tab_index);

				// Re-render text editors
				ws_this.form_textarea();
				// Object focus
				if(ws_this.object_focus !== false) {

					ws_this.object_focus.trigger('focus');
					ws_this.object_focus = false;
				}
			});
		}
	}

	// Tab validation
	$.WS_Form.prototype.form_tab_validation = function() {

		var ws_this = this;

		var tab_validation = this.get_object_meta_value(this.form, 'tab_validation');
		if(tab_validation) {

			this.form_canvas_obj.on('wsf-validate-silent', function() {

				ws_this.form_tab_validation_process();
			});

			this.form_tab_validation_process();
		}
	}

	// Tab validation
	$.WS_Form.prototype.form_tab_validation_process = function() {

		var tab_validation = this.get_object_meta_value(this.form, 'tab_validation');
		if(!tab_validation) { return; }

		var ws_this = this;

		var tab_validated_previous = true;

		// Get selector href
		var selector_href = (typeof(this.framework.tabs.public.selector_href) !== 'undefined') ? this.framework.tabs.public.selector_href : 'href';

		// Get tabs
		var tabs = $('.wsf-group-tabs > :not([data-wsf-group-hidden]) > [' + selector_href + ']', this.form_canvas_obj);

		// Get tab count
		var tab_count = tabs.length;

		// Get tab_index_current
		var tab_index_current = 0;
		tabs.each(function(tab_index) {

			var tab_visible = $($(this).attr(selector_href)).is(':visible');
			if(tab_visible) {

				tab_index_current = tab_index;
				return false;
			}
		});

		tabs.each(function(tab_index) {

			// Render validation for previous tab
			ws_this.tab_validation_previous($(this), tab_validated_previous);

			// Validate tab
			if(tab_index < (tab_count - 1)) {

				if(tab_validated_previous === true) {

					var tab_validated_current = ws_this.object_validate($($(this).attr(selector_href)));

				} else {

					var tab_validated_current = false;
				}

				// Render validation for current tab
				ws_this.tab_validation_current($(this), tab_validated_current);

				tab_validated_previous = tab_validated_current;
			}

			// If we are on a tab that is beyond the current invalidated tab, change tab to first invalidated tab
			if( !tab_validated_current &&
				(tab_index_current > tab_index)
			) {

				// Activate tab
				ws_this.group_index_set(tab_index);
			}
		});

		// Form navigation
		this.form_navigation();
	}

	// Tab validation - Current
	$.WS_Form.prototype.tab_validation_current = function(obj, tab_validated) {

		// Get selector href
		var selector_href = (typeof(this.framework.tabs.public.selector_href) !== 'undefined') ? this.framework.tabs.public.selector_href : 'href';

		var tab_id = obj.attr(selector_href);
		var tab_content_obj = $(tab_id, this.form_canvas_obj);
		var button_next_obj = $('button[data-action="wsf-tab_next"]', tab_content_obj);

		if(tab_validated) {

			button_next_obj.removeAttr('disabled');

		} else {

			button_next_obj.attr('disabled', '');
		}
	}

	// Tab validation - Previous
	$.WS_Form.prototype.tab_validation_previous = function(obj, tab_validated) {

		var framework_tabs = this.framework.tabs.public;

		if(typeof(framework_tabs.class_disabled) !== 'undefined') {

			if(tab_validated) {

				obj.removeClass(framework_tabs.class_disabled).removeAttr('data-wsf-tab-disabled').removeAttr('tabindex');

			} else {

				obj.addClass(framework_tabs.class_disabled).attr('data-wsf-tab-disabled', '').attr('tabindex', '-1');
			}
		}

		if(typeof(framework_tabs.class_parent_disabled) !== 'undefined') {

			if(tab_validated) {

				obj.parent().removeClass(framework_tabs.class_parent_disabled);

			} else {

				obj.parent().addClass(framework_tabs.class_parent_disabled);
			}
		}
	}

	// Form - Post
	$.WS_Form.prototype.form_post = function(post_mode, action_id) {

		if(typeof(post_mode) == 'undefined') { post_mode = 'save'; }
		if(typeof(action_id) == 'undefined') { action_id = 0; }

		// Determine if this is a submit
		var submit = (post_mode == 'submit');

		// Trigger post mode event
		this.trigger(post_mode);

		var ws_this = this;

		// Lock form
		this.form_post_lock();

		// Build form data
		this.form_add_hidden_input('wsf_form_id', this.form_id);
		this.form_add_hidden_input('wsf_hash', this.hash);
		this.form_add_hidden_input(ws_form_settings.wsf_nonce_field_name, ws_form_settings.wsf_nonce);

		// Tracking
		if(this.get_object_meta_value(this.form, 'tracking_duration', 'on') == 'on') {

			this.form_add_hidden_input('wsf_duration', Math.round((new Date().getTime() - this.date_start) / 1000));
		}

		// Repeatable section hidden field
		this.section_repeatable_hidden_field();

		// Reset date start
		if(post_mode == 'submit') {

			this.date_start = false;
			this.cookie_set('date_start', false, false);
			this.form_timer();
		}

		if((typeof(ws_form_settings.post_id) !== 'undefined') && (ws_form_settings.post_id > 0)) {

			this.form_add_hidden_input('wsf_post_id', ws_form_settings.post_id);
		}

		// Post mode
		this.form_add_hidden_input('wsf_post_mode', post_mode);

		// Work out which fields are hidden
		var hidden_array = $('[data-hidden],[data-hidden-section],[data-hidden-group]', ws_this.form_canvas_obj).map(function() {

			// Get name
			var name = $(this).attr('name');
			if(typeof(name) === 'undefined') {

				var name = $(this).attr('data-name');
				if(typeof(name) === 'undefined') {

					return '';
				}
			}

			// Strip brackets (For select, radio and checkboxes)
			name = name.replace('[]', '');

			return name;

		}).get();
		hidden_array = hidden_array.filter(function(value, index, self) { 

			return self.indexOf(value) === index;
		});
		var hidden = hidden_array.join();
		this.form_add_hidden_input('wsf_hidden', hidden);

		// Work out which required fields to bypass (because they are hidden) or no longer required because of conditional logic
		var bypass_required_array = $('[data-required-bypass],[data-required-bypass-section],[data-required-bypass-group],[data-conditional-logic-bypass]', this.form_canvas_obj).map(function() {

			// Get name
			var name = $(this).attr('name');

			// Strip brackets (For select, radio and checkboxes)
			name = name.replace('[]', '');

			return name;

		}).get();
		bypass_required_array = bypass_required_array.filter(function(value, index, self) { 

			return self.indexOf(value) === index;
		});
		var bypass_required = bypass_required_array.join();
		this.form_add_hidden_input('wsf_bypass_required', bypass_required);

		// Signatures
		for(var signature_index in this.signatures) {

			if(!this.signatures.hasOwnProperty(signature_index)) { continue; }

			var signature = this.signatures[signature_index];

			// Check for blank signature
			if(
				signature.signature.isEmpty() ||
				(signature.canvas_element.width == 0) ||
				(signature.canvas_element.height == 0)
			) {

				// Add signature image to form data
				$('[name="' + signature.name + '"]', this.form_canvas_obj).val('');
				continue;
			}

			// Crop signature?
			if(signature.crop) {

				if(signature.mime == 'image/jpeg') {

					var rgb = this.hex_to_rgb(signature.background_color);
				}

	            var signature_cropped			= document.createElement('canvas'),
	                signature_cropped_context	= signature_cropped.getContext('2d');

	                signature_cropped.width 	= signature.canvas_element.width;
	                signature_cropped.height	= signature.canvas_element.height;
	                signature_cropped_context.drawImage(signature.canvas_element, 0, 0);

	            var w         = signature_cropped.width,
	                h         = signature_cropped.height,
	                pix       = {x:[], y:[]},
	                imageData = signature_cropped_context.getImageData(0,0,signature_cropped.width,signature_cropped.height),
	                x, y, index;

	            for (y = 0; y < h; y++) {

	                for (x = 0; x < w; x++) {

	                    index = (y * w + x) * 4;

	                    if(signature.mime == 'image/jpeg') {

	                	// Use background color
		                    if(!(
		                	(imageData.data[index] == rgb.r) &&
		                	(imageData.data[index+1] == rgb.g) &&
		                	(imageData.data[index+2] == rgb.b)
		                    )) {

		                        pix.x.push(x);
		                        pix.y.push(y);
		                    }

	                    } else {

	                	// Use alpha channel
		                    if (imageData.data[index+3] > 0) {

		                        pix.x.push(x);
		                        pix.y.push(y);
		                    }
		                }
	                }
	            }

	            pix.x.sort(function(a,b){return a-b});
	            pix.y.sort(function(a,b){return a-b});
	            var n = pix.x.length-1;

	            w = pix.x[n] - pix.x[0];
	            h = pix.y[n] - pix.y[0];

	            if(
	        	(w > 0) &&
	        	(h > 0)
				) {

		            var cut = signature_cropped_context.getImageData(pix.x[0], pix.y[0], w, h);

		            signature_cropped.width = w;
		            signature_cropped.height = h;
		            signature_cropped_context.putImageData(cut, 0, 0);

					var signature_data = signature_cropped.toDataURL(signature.mime);

				} else {

					var signature_data = signature.signature.toDataURL(signature.mime);
				}

			} else {

				var signature_data = signature.signature.toDataURL(signature.mime);
			}

			// Add signature image to form data
			$('[name="' + signature.name + '"]', this.form_canvas_obj).val(signature_data);
		}

		// Action processing (Conditional)
		var actions_run = [];
		if(this.conditional_actions_changed) {

			if(!submit && (this.conditional_actions_run_save.length > 0)) { actions_run = this.conditional_actions_run_save; }
			if(submit && (this.conditional_actions_run_submit.length > 0)) { actions_run = this.conditional_actions_run_submit; }
			for(var actions_run_index in actions_run) {

				if(!actions_run.hasOwnProperty(actions_run_index)) { continue; }

				var action_run_id = actions_run[actions_run_index];
				if(actions_run.indexOf(action_run_id) == actions_run_index) { this.form_add_hidden_input('wsf_actions_run[]', action_run_id); }
			}
		}

		// POST form
		this.log(submit ? 'log_form_submit' : 'log_form_save');

		// Do not run AJAX
		if(
			(action_id == 0) &&
			(this.form_ajax === false)
		) {

			// We're done!
			ws_this.trigger(post_mode + '-complete');
			ws_this.trigger('complete');
			return;
		}

		// Trigger
		ws_this.trigger(post_mode + '-before-ajax');

		// Build form data
		var form_data = new FormData(this.form_obj[0]);

		// Action ID (Inject into form_data so that it doesn't stay on the form)
		if(action_id > 0) {

			form_data.append('wsf_action_id', action_id);
		}

		// Call API
		this.api_call('submit', 'POST', form_data, function(response) {

			// Success

			// Reset reCaptcha
			ws_this.recaptcha_reset();
			// Check for validation errors
			var error_validation = (typeof(response.error_validation) !== 'undefined') && response.error_validation;

			// Check for errors
			var errors = (

				(typeof(response.data) !== 'undefined') &&
				(typeof(response.data.errors) !== 'undefined') &&
				response.data.errors.length
			);

			// If response is invalid or form is being saved, force unlock it
			var form_post_unlock_force = (

				(typeof(response.data) === 'undefined') ||
				(post_mode == 'save') ||
				error_validation ||
				errors
			);

			// Unlock form
			ws_this.form_post_unlock('progress', !form_post_unlock_force, form_post_unlock_force);

			// Trigger error event
			if(errors || error_validation) {

				// Trigger error
				ws_this.trigger(post_mode + '-error');
				ws_this.trigger('error');

			} else {

				// Trigger success
				ws_this.trigger(post_mode + '-success');
				ws_this.trigger('success');
			}

			// Check for form reload on submit
			if(
				(submit && !error_validation && !errors)
			) {

				// Clear hash
				ws_this.form_hash_clear();

				if(ws_this.get_object_meta_value(ws_this.form, 'submit_reload', true)) {

					// Reload
					ws_this.form_reload();
				}
			}

			// Show error messages
			if(errors && ws_this.get_object_meta_value(ws_this.form, 'submit_show_errors', true)) {

				for(var error_index in response.data.errors) {

					if(!response.data.errors.hasOwnProperty(error_index)) { continue; }

					var error_message = response.data.errors[error_index];
					ws_this.action_message(error_message);
				}
			}

			ws_this.trigger(post_mode + '-complete');
			ws_this.trigger('complete');

			return !errors;

		}, function(response) {

			// Error
			ws_this.form_post_unlock('progress', true, true);

			// Reset reCaptcha
			ws_this.recaptcha_reset();

			// Show error message
			if(typeof(response.error_message) !== 'undefined') {

				ws_this.action_message(response.error_message);
			}

			// Trigger post most complete event
			ws_this.trigger(post_mode + '-error');
			ws_this.trigger('error');

		}, (action_id > 0));
	}

	// Form lock
	$.WS_Form.prototype.form_post_lock = function(cursor, force, ecommerce_calculate_disable) {

		if(typeof(cursor) === 'undefined') { cursor = 'progress'; }
		if(typeof(force) === 'undefined') { force = false; }
		if(typeof(ecommerce_calculate_disable) === 'undefined') { ecommerce_calculate_disable = false; }

		if(this.form_obj.hasClass('wsf-form-post-lock')) { return; }

		if(force || this.get_object_meta_value(this.form, 'submit_lock', false)) {

			// Stop further calculations
			if(ecommerce_calculate_disable) {

				this.form_ecommerce_calculate_enabled = false;
			}

			// Add locked class to form
			this.form_obj.addClass('wsf-form-post-lock' + (cursor ? ' wsf-form-post-lock-' + cursor : ''));

			// Disable submit buttons
			$('button[type="submit"].wsf-button, input[type="submit"].wsf-button, button[data-action="wsf-save"].wsf-button, button[data-ecommerce-payment].wsf-button, [data-post-lock]', this.form_canvas_obj).attr('disabled', '');
			this.form_post_locked = true;

			// Trigger lock event
			this.trigger('lock');

			// Add to log
			this.log('log_submit_lock', '', 'duplicate-protect');
		}
	}

	// Form unlock
	$.WS_Form.prototype.form_post_unlock = function(cursor, timeout, force) {

		if(typeof(cursor) === 'undefined') { cursor = 'progress'; }
		if(typeof(timeout) === 'undefined') { timeout = true; }
		if(typeof(force) === 'undefined') { force = false; }

		if(!this.form_obj.hasClass('wsf-form-post-lock')) { return; }

		var ws_this = this;

		var unlock_fn = function() {

			// Re-enable cart calculations
			ws_this.form_ecommerce_calculate_enabled = true;

			// Remove locked class from form
			ws_this.form_obj.removeClass('wsf-form-post-lock' + (cursor ? ' wsf-form-post-lock-' + cursor : ''));

			// Enable submit buttons
			$('button[type="submit"].wsf-button, input[type="submit"].wsf-button, button[data-action="wsf-save"].wsf-button, button[data-ecommerce-payment].wsf-button, [data-post-lock]', ws_this.form_canvas_obj).removeAttr('disabled');
			ws_this.form_post_locked = false;

			// Reset post upload progress indicators
			ws_this.api_call_progress_reset();

			// Trigger unlock event
			ws_this.trigger('unlock');

			// Add to log
			ws_this.log('log_submit_unlock', '', 'duplicate-protect');
		}

		if(force || this.get_object_meta_value(this.form, 'submit_unlock', false)) {

			// Enable post buttons
			timeout ? setTimeout(function() { unlock_fn(); }, 1000) : unlock_fn();
		}
	}

	// API Call
	$.WS_Form.prototype.api_call = function(ajax_path, method, params, success_callback, error_callback, force_ajax_path) {

		// Defaults
		if(typeof(method) === 'undefined') { method = 'POST'; }
		if(!params) { params = new FormData(); }
		if(typeof(force_ajax_path) === 'undefined') { force_ajax_path = false; }

		var ws_this = this;

		// Debug
		if($.WS_Form.debug_rendered) {

			// Timer - Start
			var timer_start = new Date();
		}

		// Make AJAX request
		var url = force_ajax_path ? (ws_form_settings.url + ajax_path) : ((ajax_path == 'submit') ? this.form_obj.attr('action') : (ws_form_settings.url + ajax_path));

		// Check for custom action URL
		if(
			!force_ajax_path &&
			this.form_action_custom &&
			((ajax_path == 'submit') || (ajax_path == 'save'))
		) {

			// Custom action submit
			this.form_obj.off('submit');
			this.form_obj.submit();
			return true;
		}

		// NONCE
		if(
			(typeof(params.get) === 'undefined') || // Do it anyway for IE 11
			(params.get(ws_form_settings.wsf_nonce_field_name) === null)
		) {

			params.append(ws_form_settings.wsf_nonce_field_name, ws_form_settings.wsf_nonce);
		}

		// Convert FormData to object if making GET request (IE11 friendly code so not that elegant)
		if(method === 'GET') {

			var params_object = {};

			var form_data_entries = params.entries();
			var form_data_entry = form_data_entries.next();

			while (!form_data_entry.done) {

				var pair = form_data_entry.value;
				params_object[pair[0]] = pair[1];
				form_data_entry = form_data_entries.next();
			}

			params = params_object;
		}

		// Process validation focus
		this.action_js_process_validation_focus = true;

		// Call AJAX
		var ajax_request = {

			method: method,
			url: url,
			beforeSend: function(xhr) {

				// Nonce (X-WP-Nonce)
				xhr.setRequestHeader('X-WP-Nonce', ws_form_settings.x_wp_nonce);
			},
			contentType: false,
			processData: (method === 'GET'),
 			statusCode: {

				// Success
				200: function(response) {

					// Handle hash response
					var hash_ok = ws_this.api_call_hash(response);

					// Debug
					if(hash_ok && $.WS_Form.debug_rendered) {

						// Timer - Duration
						var timer_duration = new Date() - timer_start;

						ws_this.debug_info('debug_info_submit_count', response.data.count);
						ws_this.debug_info('debug_info_submit_duration_user', ws_this.get_nice_duration(response.data.submit_duration_user));
						ws_this.debug_info('debug_info_submit_duration_client', timer_duration + ' ms');
						ws_this.debug_info('debug_info_submit_duration_server', response.data.submit_duration_server + ' ms');
					}

					// Check for action logs and errors (These are returned from the action system to tell the debugger to log the message)
					if($.WS_Form.debug_rendered) {

						if(typeof(response.data) !== 'undefined') {

							if(typeof(response.data.logs) === 'object') {

								for(var logs_index in response.data.logs) {

									if(!response.data.logs.hasOwnProperty(logs_index)) { continue; }

									ws_this.log('log_action', response.data.logs[logs_index], 'action');
								}
							}

							if(typeof(response.data.errors) === 'object') {

								for(var errors_index in response.data.errors) {

									if(!response.data.errors.hasOwnProperty(errors_index)) { continue; }
									ws_this.error('error_action', response.data.errors[errors_index], 'action');
								}
							}
						}
					}
					// Check for new nonce values
					if(typeof(response.data) !== 'undefined') {

						if(typeof(response.data.x_wp_nonce) !== 'undefined') { ws_form_settings.x_wp_nonce = response.data.x_wp_nonce; }
						if(typeof(response.data.wsf_nonce) !== 'undefined') { ws_form_settings.wsf_nonce = response.data.wsf_nonce; }
					}

					// Call success function
					var success_callback_result = (typeof(success_callback) === 'function') ? success_callback(response) : true;

					// Check for data to process
					if(
						(typeof(response.data) !== 'undefined') &&
						success_callback_result
					) {

						// Check for action_js (These are returned from the action system to tell the browser to do something)
						if(typeof(response.data.js) === 'object') { ws_this.action_js_init(response.data.js); }
					}
				},

				// Bad request
				400: function(response) {

					// Process error
					ws_this.api_call_error_handler(response, 400, url, error_callback);
				},

				// Unauthorized
				401: function(response) {

					// Process error
					ws_this.api_call_error_handler(response, 401, url, error_callback);
				},

				// Forbidden
				403: function(response) {

					// Process error
					ws_this.api_call_error_handler(response, 403, url, error_callback);
				},

				// Not found
				404: function(response) {

					// Process error
					ws_this.api_call_error_handler(response, 404, url, error_callback);
				},

				// Server error
				500: function(response) {

					// Process error
					ws_this.api_call_error_handler(response, 500, url, error_callback);
				}
			},

			complete: function() {

				this.api_call_handle = false;
			}
		};

		// Data
		if(params !== false) { ajax_request.data = params; }

		// Progress
		var progress_objs = $('[data-source="post_progress"]', this.form_canvas_obj);
		if(progress_objs.length) {

			ajax_request.xhr = function() {

				var xhr = new window.XMLHttpRequest();
				xhr.upload.addEventListener("progress", function(e) { ws_this.api_call_progress(progress_objs, e); }, false);
				xhr.addEventListener("progress", function(e) { ws_this.api_call_progress(progress_objs, e); }, false);
				return xhr;
			};
		}

		return $.ajax(ajax_request);
	};

	// API call - Process error
	$.WS_Form.prototype.api_call_error_handler = function(response, status, url, error_callback) {

		// Get response data
		var data = (typeof(response.responseJSON) !== 'undefined') ? response.responseJSON : false;

		// Process WS Form API error message
		if(data && data.error) {

			if(data.error_message) {

				this.error('error_api_call_' + status, data.error_message);

			} else {

				this.error('error_api_call_' + status, url);
			}

		} else {

			// Fallback
			this.error('error_api_call_' + status, url);
		}

		// Call error call back
		if(typeof(error_callback) === 'function') {

			// Run error callback
			error_callback(data);

		}
	}

	// API Call - Progress
	$.WS_Form.prototype.api_call_progress = function(progress_objs, e) {

		if(!e.lengthComputable) { return; }

		var ws_this = this;

		progress_objs.each(function() {

			// Get progress value
			var progress_percentage = (e.loaded / e.total) * 100;

			// Set progress fields
			ws_this.form_progress_set_value($(this), Math.round(progress_percentage));
		});
	}

	// API Call - Progress
	$.WS_Form.prototype.api_call_progress_reset = function() {

		var ws_this = this;

		var progress_obj = $('[data-progress-bar][data-source="post_progress"]', this.form_canvas_obj);
		progress_obj.each(function() {

			ws_this.form_progress_set_value($(this), 0);
		});
	}

	// JS Actions - Init
	$.WS_Form.prototype.action_js_init = function(action_js) {

		// Trigger actions start event
		this.trigger('actions-start');

		this.action_js = action_js;

		this.action_js_process_next();
	};

	$.WS_Form.prototype.action_js_process_next = function() {

		if(this.action_js.length == 0) {

			// Trigger actions finish event
			this.trigger('actions-finish');

			return false;
		}

		var js_action = this.action_js.shift();

		var action = this.js_action_get_parameter(js_action, 'action');

		switch(action) {

			// Redirect
			case 'redirect' :

				var url = this.js_action_get_parameter(js_action, 'url');
				if(url !== false) { location.href = js_action['url']; }

				// Actions end at this point because of the redirect
				return true;

				break;

			// Message
			case 'message' :

				var message = this.js_action_get_parameter(js_action, 'message');
				var type = this.js_action_get_parameter(js_action, 'type');
				var method = this.js_action_get_parameter(js_action, 'method');
				var duration = this.js_action_get_parameter(js_action, 'duration');
				var form_hide = this.js_action_get_parameter(js_action, 'form_hide');
				var clear = this.js_action_get_parameter(js_action, 'clear');
				var scroll_top = this.js_action_get_parameter(js_action, 'scroll_top');
				var scroll_top_offset = this.js_action_get_parameter(js_action, 'scroll_top_offset');
				var scroll_top_duration = this.js_action_get_parameter(js_action, 'scroll_top_duration');
				var form_show = this.js_action_get_parameter(js_action, 'form_show');
				var message_hide = this.js_action_get_parameter(js_action, 'message_hide');

				this.action_message(message, type, method, duration, form_hide, clear, scroll_top, scroll_top_offset, scroll_top_duration, form_show, message_hide);

				break;
			// Conversion
			case 'conversion' :

				var type = this.js_action_get_parameter(js_action, 'type');
				var parse_values = this.js_action_get_parameter(js_action, 'parse_values');

				this.action_conversion(type, parse_values);

				break;

			// JavaScript
			case 'javascript' :

				var javascript = this.js_action_get_parameter(js_action, 'javascript');

				this.action_javascript(javascript);

				break;
			// Field invalid feedback
			case 'field_invalid_feedback' :

				var field_id = parseInt(this.js_action_get_parameter(js_action, 'field_id'));
				var section_repeatable_index = parseInt(this.js_action_get_parameter(js_action, 'section_repeatable_index'));
				var section_repeatable_suffix = section_repeatable_index ? '-repeat-' + section_repeatable_index : '';
				var message = this.js_action_get_parameter(js_action, 'message');

				// Field object
				var field_obj = $('#' + this.form_id_prefix + 'field-' + field_id + section_repeatable_suffix, this.form_canvas_obj);

				// Set invalid feedback
				this.set_invalid_feedback(field_obj, message);

				// Log event
				this.log('error_invalid_feedback', field_id + ' (' + this.html_encode(message) + ')');

				var ws_this = this;

				// Reset if field modified
				field_obj.one('change input keyup paste', function() {

					// Reset invalid feedback
					ws_this.set_invalid_feedback($(this), '');
				});

				// Process focus?
				if(
					this.get_object_meta_value(this.form, 'invalid_field_focus', true) &&
					this.action_js_process_validation_focus
				) {

					// Get group index
					var group_index_focus = this.get_group_index(field_obj);

					// Focus object
					if(group_index_focus !== false) { 

						this.object_focus = field_obj;

					} else {

						field_obj.trigger('focus');
					}

					// Focus tab
					if(group_index_focus !== false) { this.group_index_set(group_index_focus); }

					// Prevent further focus
					this.action_js_process_validation_focus = false;
				}

				this.action_js_process_next();

				break;

			case 'trigger' :

				var event = this.js_action_get_parameter(js_action, 'event');
				var params = this.js_action_get_parameter(js_action, 'params');

				$(document).trigger(event, params);

				this.action_js_process_next();

				break;
		}
	}

	// JS Actions - Get js_action config parameter from AJAX return
	$.WS_Form.prototype.js_action_get_parameter = function(js_action_parameters, meta_key) {

		return typeof(js_action_parameters[meta_key]) !== 'undefined' ? js_action_parameters[meta_key] : false;
	}

	// JS Actions - Get framework config value
	$.WS_Form.prototype.get_framework_config_value = function(object, meta_key) {

		if(typeof(this.framework[object]) === 'undefined') {
			this.error('error_api_call_framework_invalid');
			return false;
		}
		if(typeof(this.framework[object]['public']) === 'undefined') {
			this.error('error_api_call_framework_invalid');
			return false;
		}
		if(typeof(this.framework[object]['public'][meta_key]) === 'undefined') { return false; }

		return this.framework[object]['public'][meta_key];
	}

	// JS Action - Message
	$.WS_Form.prototype.action_message = function(message, type, method, duration, form_hide, clear, scroll_top, scroll_top_offset, scroll_top_duration, form_show, message_hide) {

		// Error message setting defaults
		if(typeof(type) === 'undefined') { type = this.get_object_meta_value(this.form, 'error_type', 'danger'); }
		if(typeof(method) === 'undefined') { method = this.get_object_meta_value(this.form, 'error_method', 'after'); }
		if(typeof(duration) === 'undefined') { duration = parseInt(this.get_object_meta_value(this.form, 'error_duration', '4000')); }
		if(typeof(form_hide) === 'undefined') { form_hide = (this.get_object_meta_value(this.form, 'error_form_hide', '') == 'on'); }
		if(typeof(clear) === 'undefined') { clear = (this.get_object_meta_value(this.form, 'error_clear', '') == 'on'); }
		if(typeof(scroll_top) === 'undefined') { scroll_top = (this.get_object_meta_value(this.form, 'error_scroll_top', '') == 'on'); }
		if(typeof(scroll_top_offset) === 'undefined') { scroll_top_offset = parseInt(this.get_object_meta_value(this.form, 'error_scroll_top_offset', '0')); }
		scroll_top_offset = (scroll_top_offset == '') ? 0 : parseInt(scroll_top_offset, 10);
		if(typeof(scroll_top_duration) === 'undefined') { scroll_top_duration = parseInt(this.get_object_meta_value(this.form, 'error_scroll_top_duration', '400')); }
		if(typeof(form_show) === 'undefined') { form_show = (this.get_object_meta_value(this.form, 'error_form_show', '') == 'on'); }
		if(typeof(message_hide) === 'undefined') { message_hide = (this.get_object_meta_value(this.form, 'error_message_hide', 'on') == 'on'); }

		var scroll_position = this.form_canvas_obj.offset().top - scroll_top_offset;

		// Parse duration
		duration = parseInt(duration, 10);
		if(duration < 0) { duration = 0; }

		// Get config
		var mask_wrapper = this.get_framework_config_value('message', 'mask_wrapper');
		var types = this.get_framework_config_value('message', 'types');

		var type = (typeof(types[type]) !== 'undefined') ? types[type] : false;
		var mask_wrapper_class = (typeof(type['mask_wrapper_class']) !== 'undefined') ? type['mask_wrapper_class'] : '';

		// Clear other messages
		if(clear) {

			$('[data-wsf-message][data-wsf-instance-id="' + this.form_instance_id + '"]').remove();
		}

		// Scroll top
		switch(scroll_top) {

			case 'instant' :
			case 'on' :			// Legacy

				$('html,body').scrollTop(scroll_position);

				break;

			// Smooth
			case 'smooth' :

				scroll_top_duration = (scroll_top_duration == '') ? 0 : parseInt(scroll_top_duration, 10);

				$('html,body').animate({

					scrollTop: scroll_position

				}, scroll_top_duration);

				break;
		}

		var mask_wrapper_values = {

			'message':				message,
			'mask_wrapper_class':	mask_wrapper_class 
		};

		var message_div = $('<div/>', { html: this.mask_parse(mask_wrapper, mask_wrapper_values) });
		message_div.attr('role', 'alert');
		message_div.attr('data-wsf-message', '');
		message_div.attr('data-wsf-instance-id', this.form_instance_id);

		// Hide form?
		if(form_hide) { this.form_obj.hide(); }

		// Render message
		switch(method) {

			// Before
			case 'before' :

				message_div.insertBefore(this.form_obj);
				break;

			// After
			case 'after' :

				message_div.insertAfter(this.form_obj);
				break;
		}

		// Process next action
		var ws_this = this;

		duration = parseInt(duration, 10);

		if(duration > 0) {

			setTimeout(function() {

				// Should this message be removed?
				if(message_hide) { message_div.remove(); }

				// Should the form be shown?
				if(form_show) { ws_this.form_canvas_obj.show(); }

				// Process next js_action
				ws_this.action_js_process_next();

			}, duration);

		} else {

			// Process next js_action
			ws_this.action_js_process_next();
		}
	}
	// JS Action - Conversion
	$.WS_Form.prototype.action_conversion = function(type, parse_values) {

		// Check analytics type exists in config
		if(typeof(type) === 'undefined') { return false; }
		if(typeof($.WS_Form.analytics[type]) === 'undefined') { return false; }
		if(typeof($.WS_Form.analytics[type].functions) === 'undefined') { return false; }

		// Get type_function
		if(typeof(this.analytics_function[type]) !== 'undefined') {

			var type_function = this.analytics_function[type];

		} else {

			// Get first function
			var type_function = Object.keys($.WS_Form.analytics[type].functions)[0];
		}

		// Fire event
		this.form_analytics_event_fire(

			type,
			type_function,
			parse_values
		);

		// Process next js_action
		this.action_js_process_next();
	}


	// JS Action - Run JavaScript
	$.WS_Form.prototype.action_javascript = function(action_javascript) {

		try {

			// Run JavaScript
			$.globalEval('(function($) {' + action_javascript + '})(jQuery);');

			// Log event
			this.log('log_javascript', 'action');

		} catch(e) {

			this.error('error_js', action_javascript);
		}

		// Process next js_action
		this.action_js_process_next();
	}
	// Text input and textarea character and word count
	$.WS_Form.prototype.form_character_word_count = function(obj) {

		var ws_this = this;
		if(typeof(obj) === 'undefined') { obj = this.form_canvas_obj; }

		// Run through each input that accepts text
		for(var field_id in this.field_data_cache) {

			if(!this.field_data_cache.hasOwnProperty(field_id)) { continue; }

			var field = this.field_data_cache[field_id];

			// Process help?
			var help = this.get_object_meta_value(field, 'help', '', false, true);
			var process_help = (

				(help.indexOf('#character_') !== -1) ||
				(help.indexOf('#word_') !== -1)
			);

			// Skip if help is blank
			if(help === '') { continue; }

			// Process min or max?
			var process_min_max = (

				this.has_object_meta_key(field, 'min_length') ||
				this.has_object_meta_key(field, 'max_length') ||
				this.has_object_meta_key(field, 'min_length_words') ||
				this.has_object_meta_key(field, 'max_length_words')
			);

			if(process_min_max || process_help) {

				// Process count functionality on field
				var field_obj = $('#' + this.form_id_prefix + 'field-' + field_id, obj);
				if(!field_obj.length) { field_obj = $('[id^="' + this.form_id_prefix + 'field-' + field_id + '-"]:not([data-init-char-word-count]):not(iframe)', obj); }

				field_obj.each(function() {

					// Flag so it only initializes once
					$(this).attr('data-init-char-word-count', '');

					if(ws_this.form_character_word_count_process($(this))) {

						$(this).on('keyup change paste', function() { ws_this.form_character_word_count_process($(this)); });
					}
				});
			}
		}
	}

	// Text input and textarea character and word count - Process
	$.WS_Form.prototype.form_character_word_count_process = function(obj) {

		// Get minimum and maximum character count
		var field = this.get_field(obj);

		var min_length = this.get_object_meta_value(field, 'min_length', '');
		min_length = (parseInt(min_length, 10) > 0) ? parseInt(min_length, 10) : false;

		var max_length = this.get_object_meta_value(field, 'max_length', '');
		max_length = (parseInt(max_length, 10) > 0) ? parseInt(max_length, 10) : false;

		// Get minimum and maximum word length
		var min_length_words = this.get_object_meta_value(field, 'min_length_words', '');
		min_length_words = (parseInt(min_length_words, 10) > 0) ? parseInt(min_length_words, 10) : false;

		var max_length_words = this.get_object_meta_value(field, 'max_length_words', '');
		max_length_words = (parseInt(max_length_words, 10) > 0) ? parseInt(max_length_words, 10) : false;

		// Calculate sizes
		var val = obj.val();

		// Check value is a string
		if(typeof(val) !== 'string') { return; }

		var character_count = val.length;
		var character_remaining = (max_length !== false) ? max_length - character_count : false;
		if(character_remaining < 0) { character_remaining = 0; }

		var word_count = this.get_word_count(val);
		var word_remaining = (max_length_words !== false) ? max_length_words - word_count : false;
		if(word_remaining < 0) { word_remaining = 0; }

		// Check minimum and maximums counts
		var count_invalid = false;
		var count_invalid_message_array = [];

		if((min_length !== false) && (character_count < min_length)) {

			count_invalid_message_array.push(this.language('error_min_length', min_length));
			count_invalid = true;
		}
		if((max_length !== false) && (character_count > max_length)) {

			count_invalid_message_array.push(this.language('error_max_length', max_length));
			count_invalid = true;
		}
		if((min_length_words !== false) && (word_count < min_length_words)) {

			count_invalid_message_array.push(this.language('error_min_length_words', min_length_words));
			count_invalid = true;
		}
		if((max_length_words !== false) && (word_count > max_length_words)) {

			count_invalid_message_array.push(this.language('error_max_length_words', max_length_words));
			count_invalid = true;
		}

		// Check if required
		if(
			(typeof(obj.attr('required')) !== 'undefined') ||
			(val.length > 0)
		) {

			// Check if count_invalid
			if(count_invalid) {

				// Set invalid feedback
				this.set_invalid_feedback(obj, count_invalid_message_array.join(' / '));

			} else {

				// Reset invalid feedback
				this.set_invalid_feedback(obj, '');
			}

		} else {

			// Reset invalid feedback
			this.set_invalid_feedback(obj, '');
		}

		// Process help
		var help = this.get_object_meta_value(field, 'help', '', false, true);

		// If #character_ and #word_ not present, don't bother processing
		if(
			(help.indexOf('#character_') === -1) &&
			(help.indexOf('#word_') === -1)
		) {
			return true;
		}

		// Get language
		var character_singular = this.language('character_singular');
		var character_plural = this.language('character_plural');
		var word_singular = this.language('word_singular');
		var word_plural = this.language('word_plural');

		// Set mask values
		var mask_values_help = {

			// Characters
			'character_count':				character_count,
			'character_count_label':		(character_count == 1 ? character_singular : character_plural),
			'character_remaining':			(character_remaining !== false) ? character_remaining : '',
			'character_remaining_label':	(character_remaining == 1 ? character_singular : character_plural),
			'character_min':				(min_length !== false) ? min_length : '',
			'character_min_label':			(min_length !== false) ? (min_length == 1 ? character_singular : character_plural) : '',
			'character_max':				(max_length !== false) ? max_length : '',
			'character_max_label':			(max_length !== false) ? (max_length == 1 ? character_singular : character_plural) : '',

			// Words
			'word_count':			word_count,
			'word_count_label':		(word_count == 1 ? word_singular : word_plural),
			'word_remaining':		(word_remaining !== false) ? word_remaining : '',
			'word_remaining_label': (word_remaining == 1 ? word_singular : word_plural),
			'word_min':				(min_length_words !== false) ? min_length_words : '',
			'word_min_label':		(min_length_words !== false) ? (min_length_words == 1 ? word_singular : word_plural) : '',
			'word_max':				(max_length_words !== false) ? max_length_words : '',
			'word_max_label':		(max_length_words !== false) ? (max_length_words == 1 ? word_singular : word_plural) : ''
		};

		// Parse help mask
		var help_parsed = this.mask_parse(help, mask_values_help);

		// Update help HTML
		var help_obj = this.get_help_obj(obj);
		help_obj.html(help_parsed);

		return true;
	}

	// Get word count of a string
	$.WS_Form.prototype.get_word_count = function(input_string) {

		// Trim input string
		input_string = input_string.trim();

		// If string is empty, return 0
		if(input_string.length == 0) { return 0; }

		// Return word count
		return input_string.trim().replace(/\s+/gi, ' ').split(' ').length;
	}

	// API Call
	$.WS_Form.prototype.api_call_hash = function(response) {

		var hash_ok = true;
		if(typeof(response.hash) === 'undefined') { hash_ok = false; }
		if(hash_ok && (response.hash.length != 32)) { hash_ok = false; }
		if(hash_ok) {

			// Set hash
			this.hash_set(response.hash)
		}

		return hash_ok;
	}

	// Hash - Set
	$.WS_Form.prototype.hash_set = function(hash, token, cookie_set) {

		if(typeof(token) === 'undefined') { token = false; }
		if(typeof(cookie_set) === 'undefined') { cookie_set = false; }

		if(hash != this.hash) {

			// Set hash
			this.hash = hash;

			// Set hash cookie
			cookie_set = true;

			// Add to log
			this.log('log_hash_set', this.hash);

			// Debug
			if($.WS_Form.debug_rendered) { this.debug_info('debug_info_hash', this.hash, 'clear_hash'); }
		}

		if(token) {

			// Set token
			this.token = token;

			// Add to log
			this.log('log_token_set', this.token);
		}

		if(cookie_set) {

			var cookie_hash = this.get_object_value($.WS_Form.settings_plugin, 'cookie_hash');

			if(cookie_hash) {

				this.cookie_set('hash', this.hash);
			}
		}
	}

	// Generate password
	$.WS_Form.prototype.generate_password = function(length) {

		var password = '';
		var characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+~`|}{[]\\:;?><,./-=';
		
		for(var i = 0; i < length; ++i) { password += characters.charAt(Math.floor(Math.random() * characters.length)); }

		return password;
	}

	// Form - Statistics
	$.WS_Form.prototype.form_stat = function() {

		// Add view
		if(ws_form_settings.stat) { this.form_stat_add_view(); }
	}

	// Add view statistic
	$.WS_Form.prototype.form_stat_add_view = function() {

		// Call AJAX
		$.ajax({ method: 'POST', url: ws_form_settings.add_view_url, data: { wsffid: this.form_id } });
	}

	// Initialize forms function
	window.wsf_form_instances = [];

	window.wsf_form_init = function(force_reload, reset_events, container) {

		if(typeof(force_reload) === 'undefined') { force_reload = false; }
		if(typeof(reset_events) === 'undefined') { reset_events = false; }
		if(typeof(container) === 'undefined') {

			var forms = $('.wsf-form');

		} else {

			var forms = $('.wsf-form', container);
		}

		if(!$('.wsf-form').length) { return; }

		// Get highest instance ID
		var set_instance_id = 0;
		var instance_id_array = [];

		$('.wsf-form').each(function() {

			if(typeof($(this).attr('data-instance-id')) === 'undefined') { return; }

			// Get instance ID
			var instance_id_single = parseInt($(this).attr('data-instance-id'));

			// Check for duplicate instance ID
			if(instance_id_array.indexOf(instance_id_single) !== -1) {

				// If duplicate, remove the data-instance-id so it is reset
				$(this).removeAttr('data-instance-id');

			} else {

				// Check if this is the highest instance ID
				if(instance_id_single > set_instance_id) { set_instance_id = instance_id_single; }
			}

			instance_id_array.push(instance_id_single);
		});

		// Increment to next instance ID
		set_instance_id++;

		// Render each form
		forms.each(function() {

			// Skip forms already initialized
			if(!force_reload && (typeof($(this).attr('data-wsf-rendered')) !== 'undefined')) { return; }

			// Reset events
			if(reset_events) { $(this).off(); }

			// Set instance ID
			if(typeof($(this).attr('data-instance-id')) === 'undefined') {

				// Set ID (Only if custom ID not set)
				if(typeof($(this).attr('data-wsf-custom-id')) === 'undefined') {

					$(this).attr('id', 'ws-form-' + set_instance_id);
				}

				// Set instance ID
				$(this).attr('data-instance-id', set_instance_id);

				set_instance_id++;
			}

			// Get attributes
			var id = $(this).attr('id');
			var form_id = $(this).attr('data-id');
			var instance_id = $(this).attr('data-instance-id');

			if(id && form_id && instance_id) {

				// Initiate new WS Form object
				var ws_form = new $.WS_Form();

				// Save to wsf_form_instances array
				window.wsf_form_instances[instance_id] = ws_form;

				// Render
				ws_form.render({

					'obj' :			'#' + id,
					'form_id':		form_id
				});
			}
		});
	}

	// On load
	$(function() { wsf_form_init(); });

})(jQuery);


